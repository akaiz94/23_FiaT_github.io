var page_param = {
    totalCount: 5,
    currentPage: 1,
    pageSize: 1000,
    startIndex: 0,
}
$(document).ready(function () {
    console.log('index page start -> ')
});
