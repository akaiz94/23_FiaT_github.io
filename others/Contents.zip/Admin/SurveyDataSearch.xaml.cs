﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using IOPE_LAB_CONTROLS.Base;
using System.Data;
using IOPE_LAB.Common;

namespace IOPE_LAB.Contents.Admin
{
    /// <summary>
    /// SurveyDataSearch.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class SurveyDataSearch : UserControl
    {
        public SurveyDataSearch()
        {
            InitializeComponent();
            InitEvent();
        }

        private void InitEvent()
        {
            this.Loaded += new RoutedEventHandler(CouponListSearch_Loaded);
            this.btn_search.Click += new RoutedEventHandler(btn_search_Click);
            this.btn_excel.Click += new RoutedEventHandler(btn_excel_Click);

            //this.KeyDown += new KeyEventHandler(CouponListSearch_KeyDown);

        }

        void CouponListSearch_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.E:
                    if (btn_excel.Visibility == System.Windows.Visibility.Collapsed)
                        btn_excel.Visibility = System.Windows.Visibility.Visible;
                    else
                        btn_excel.Visibility = System.Windows.Visibility.Collapsed;
                    break;
            }
        }

        void btn_excel_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = GetSearchData();
            CommonBiz.CreateCSVFile(dt);
        }

        void btn_search_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = GetSearchData();
            rgvCouponList.ItemsSource = dt;
        }

        private DataTable GetSearchData()
        {
            try
            {
                DataTable result = null;

                SurveyService.SurveyServiceClient ssc = new SurveyService.SurveyServiceClient();

                result = ssc.SP_getSurveyResultList(first_date.DateTimeText.Replace("-", "/"), end_date.DateTimeText.Replace("-", "/"), tb_search.Text);

                if (ssc.State != System.ServiceModel.CommunicationState.Closed)
                {
                    ssc.Close();
                }

                string sLogs = string.Empty;

                if (!string.IsNullOrWhiteSpace(tb_search.Text))
                {
                    sLogs = string.Format("검색조건 : 검색어 - ''{0}''", tb_search.Text);
                }
                else
                {
                    sLogs = string.Format("검색조건 : 기간검색 - ''{0}'' ~ ''{1}''", first_date.DateTimeText, end_date.DateTimeText);
                }

                ManagerService.ManagerServiceClient msc_1 = new ManagerService.ManagerServiceClient();
                msc_1.InsertLogs(IOPE_LAB_CONTROLS.Const.LogsProcessType.SER, IOPE_LAB_CONTROLS.Const.LogsProcess.SurveyListSearch, sLogs, LoginSession.LoginManagerInfo.ManagerKey);

                if (msc_1.State != System.ServiceModel.CommunicationState.Closed)
                {
                    msc_1.Close();
                }

                return result;
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

                return null;
            }
        }

        void CouponListSearch_Loaded(object sender, RoutedEventArgs e)
        {
            LoginSession.SelectedVisitSchMember = null;
            LoginSession.SelectedMember = null;
            LoginSession.SelectedSurvey = null;
            LoginSession.SelectedResult_Rpt = null;
            LoginSession.SelectedM_Antera = null;
            LoginSession.SelectedM_skintouch = null;
            LoginSession.SelectedM_Jeonan = null;
            LoginSession.SelectedCanvasImageEntity = null;

            first_date.SelectedDate = DateTime.Now - TimeSpan.FromDays(8);
            end_date.SelectedDate = DateTime.Now - TimeSpan.FromDays(1);
            tb_search.Text = "";

            switch (LoginSession.LoginManagerInfo.ManagerRoleCD)
            {

                case "MR001001":    //관리자
                    btn_excel.Visibility = System.Windows.Visibility.Visible;
                    break;
                case "MR001002":    //스페셜리스트
                    btn_excel.Visibility = System.Windows.Visibility.Collapsed;
                    break;
                case "MR001003":    //연구원
                    btn_excel.Visibility = System.Windows.Visibility.Collapsed;
                    break;
            }
        }
    }
}
