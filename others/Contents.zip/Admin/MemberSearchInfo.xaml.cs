﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.IO;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;
using IOPE_LAB.Common;
using IOPE_LAB_CONTROLS.Entity;
using IOPE_LAB.Popup;
using IOPE_LAB_CONTROLS.Base;

namespace IOPE_LAB.Contents.Admin
{
    /// <summary>
    /// MemberSearchInfo.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MemberSearchInfo : UserControl
    {
        public MemberSearchInfo()
        {
            InitializeComponent();

            

            InitEvent();

            DateTime nowDate = DateTime.Now;

            switch (LoginSession.LoginManagerInfo.ManagerRoleCD)
            {

                case "MR001001":    //관리자
                    btn_excel.Visibility = System.Windows.Visibility.Collapsed;
                    break;
                case "MR001002":    //스페셜리스트
                    btn_excel.Visibility = System.Windows.Visibility.Collapsed;
                    break;
                case "MR001003":    //연구원
                    btn_excel.Visibility = System.Windows.Visibility.Collapsed;
                    break;
            }

            first_date.SelectedDate = DateTime.Now - TimeSpan.FromDays(90);
            end_date.SelectedDate = DateTime.Now - TimeSpan.FromDays(1);

            LoginSession.AdminContentFlag = true;

            if (LoginSession.SelectedMember != null)
            {
                tb_search.Text = LoginSession.SelectedMember.name;
                //SearchBind();
            }
            else
                tb_search.Text = "";
        }
        
        private void InitEvent()
        {
            this.Loaded += new RoutedEventHandler(MemberSearchInfo_Loaded);
            this.btn_search.Click += new RoutedEventHandler(btn_search_Click);
            this.btn_excel.Click += new RoutedEventHandler(btn_excel_Click);
            this.btn_reset.Click += Btn_reset_Click;
        }

        private void Btn_reset_Click(object sender, RoutedEventArgs e)
        {
            first_date.SelectedDate = DateTime.Now - TimeSpan.FromDays(90);
            end_date.SelectedDate = DateTime.Now - TimeSpan.FromDays(1);
            tb_search.Text = "";
            comboBox.SelectedIndex = 0;
            viti_comboBox.SelectedIndex = 0;
            vsh_comboBox.SelectedIndex = 0;
            rgvMemberList.ItemsSource = null;
        }

        void MemberSearchInfo_Loaded(object sender, RoutedEventArgs e)
        {
            

        }

        void btn_excel_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = GetSearchData();
            CommonBiz.CreateCSVFile(dt);
        }

        void btn_search_Click(object sender, RoutedEventArgs e)
        {
            SearchBind();
        }

        private void SearchBind()
        {
            DataTable dt = GetSearchData();

            if (dt != null && dt.Rows.Count > 0)
            {
                dt.Columns.Add("Convert_Phone");
                dt.Columns.Add("Convert_Name");
                dt.Columns.Add("Convert_Course_Flg");

                foreach (DataRow dr in dt.Rows)
                {
                    //dr["Convert_Phone"] = ConvertPhoneMask(dr["Phone"].ToString());
                    //dr["Convert_Name"] = ConvertNameMask(dr["name"].ToString());
                    dr["Convert_Phone"] = dr["Phone"].ToString();
                    dr["Convert_Name"] = dr["name"].ToString();
                    dr["Convert_Course_Flg"] = dr["course_flg"].ToString() == "I" ? "IntenSive" : dr["course_flg"].ToString() == "B" ? "Basic" : "코스없음";
                }
            }
            else
            {
                CommonMessageBox.ShowAlertMessage("검색 결과가 없습니다.");
            }

            rgvMemberList.ItemsSource = dt;
        }

        private string ConvertNameMask(string name)
        {
            string result = "";

            result = name.Remove(1, 1).Insert(1, "*");

            return result;
        }

        private string ConvertPhoneMask(string phone)
        {
            string result = phone;
            string resultHypen = string.Empty;

            if (phone.Length == 11)
            {
                resultHypen = phone.Insert(3, "-");
                resultHypen = resultHypen.Insert(8, "-");

                int start = resultHypen.IndexOf('-');
                int last = resultHypen.LastIndexOf('-');

                resultHypen = resultHypen.Substring(0, start + 1) + "****" +
                  resultHypen.Substring(last);

            }
            else if (phone.Length == 10)
            {
                resultHypen = phone.Insert(3, "-");
                resultHypen = resultHypen.Insert(7, "-");

                int start = resultHypen.IndexOf('-');
                int last = resultHypen.LastIndexOf('-');

                resultHypen = resultHypen.Substring(0, start + 1) + "***" +
                  resultHypen.Substring(last);
            }
            return resultHypen;
        }

        private DataTable GetSearchData()
        {
            DataTable result = null;
            string str_start_date = first_date.SelectedDate.Value.ToString("yyyy/MM/dd").Replace("-", "/");
            string str_end_date = end_date.SelectedDate.Value.ToString("yyyy/MM/dd").Replace("-", "/");
            string str_name = tb_search.Text == ""? "" : tb_search.Text;
            string vdCombomText = "";
            string viti_comboText = "";
            string vsh_comboBoxText = "";
            string brandCourse = "IC";
            if (comboBox.Text.Equals("예약/직접"))
            {
                CommonMessageBox.ShowAlertMessage("예약/직접 중 하나를 선택 해주세요!");
            }
            else
            {
                if (comboBox.Text.Equals("예약"))
                {
                    vdCombomText = "예약";
                }
                else if (comboBox.Text.Equals("직접"))
                {
                    vdCombomText = "직접";
                }
                if (comboBox.Text.Equals("전체"))
                {
                    vdCombomText = "전체";
                }

                switch (viti_comboBox.Text)
                {
                    case "홈페이지":
                    case "IOPE官网":
                        viti_comboText = "1";
                        break;
                    case "지인추천":
                    case "熟人推荐":
                        viti_comboText = "2";
                        break;
                    case "인터넷 검색":
                    case "网上搜索":
                        viti_comboText = "3";
                        break;
                    case "SNS":
                    case "SNS（博客，网络社区等）":
                        viti_comboText = "4";
                        break;
                    case "재방문":
                    case "再访问":
                        viti_comboText = "5";
                        break;
                    case "기타":
                    case "其他":
                        viti_comboText = "6";
                        break;

                    case "가족":
                    case "家庭":
                        viti_comboText = "7";
                        break;

                    case "사내직원":
                    case "员工之家":
                        viti_comboText = "8";
                        break;
                    default:
                         viti_comboText = "";
                        break;
                }


                if (vsh_comboBox.Text.Equals("비고/고객명"))
                {
                    vsh_comboBoxText = "";
                }
                else if (vsh_comboBox.Text.Equals("비고"))
                {
                    vsh_comboBoxText = "비고";
                }
                else if (vsh_comboBox.Text.Equals("고객명"))
                {
                    vsh_comboBoxText = "고객명";
                }

                ResultService.ResultServiceClient rsc = new ResultService.ResultServiceClient();

                result = rsc.Select_C_ResultMemberSearch(str_start_date, str_end_date, str_name, vdCombomText, viti_comboText, vsh_comboBoxText, brandCourse);

                if (rsc.State != System.ServiceModel.CommunicationState.Closed)
                {
                    rsc.Close();
                }

            }
            return result;         
        }


        private void btn_SurveySearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var senderElement = e.OriginalSource as FrameworkElement;
                GridViewRowItem ri = (senderElement.Parent as Telerik.Windows.Controls.GridView.GridViewCell).ParentRow as GridViewRowItem;
                DataRow dr = ri.DataContext as DataRow;
                rgvMemberList.SelectedItem = dr;

                Member _Member = new Member();
                _Member.userkey = Convert.ToInt32(dr["userKey"].ToString());
                _Member.surveyNo = Convert.ToInt32(dr["surveyNo"].ToString());
                _Member.rsvn_date = Convert.ToDateTime(dr["surveyDate"].ToString());
                _Member.phone = dr["Phone"].ToString();
                _Member.name = dr["name"].ToString();
                _Member.sex = dr["Sex"].ToString();
                _Member.course_flg = dr["course_flg"].ToString();
                _Member.birthdate = dr["birthdate"].ToString();

                string prog_cd = dr.ItemArray[8].ToString();         

                if (prog_cd.Equals("PC001001"))
                {
                    _Member.PCCD_NAME = "SKIN FUTURE PROGRAM";
                }
                else if (prog_cd.Equals("PC001006"))
                {
                    _Member.PCCD_NAME = "SKIN COUNSELING PROGRAM";
                }
                else if (prog_cd.Equals("PC001010"))
                {
                    _Member.PCCD_NAME = "SCALP PROGRAM";
                }
                else if (prog_cd.Equals("PC001011"))
                {
                    _Member.PCCD_NAME = "GENE PROGRAM";
                }

                _Member.PCCD = prog_cd;

                LoginSession.SelectedMember = _Member;

                SetMemberData(_Member);


                CommonBiz.SetMemberTopText(LoginSession.SelectedMember);

                CommonBiz.SelectMenu(MainWindow.Menus.SurveyMain);
        
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }
        }

        private void btn_ResultSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var senderElement = e.OriginalSource as FrameworkElement;
                GridViewRowItem ri = (senderElement.Parent as Telerik.Windows.Controls.GridView.GridViewCell).ParentRow as GridViewRowItem;
                DataRow dr = ri.DataContext as DataRow;
                rgvMemberList.SelectedItem = dr;

                Member _Member = new Member();
                _Member.userkey = Convert.ToInt32(dr["userKey"].ToString());
                _Member.surveyNo = Convert.ToInt32(dr["surveyNo"].ToString());
                _Member.rsvn_date = Convert.ToDateTime(dr["surveyDate"].ToString());
                _Member.phone = dr["Phone"].ToString();
                _Member.name = dr["name"].ToString();
                _Member.sex = dr["Sex"].ToString();
                _Member.course_flg = dr["course_flg"].ToString();
                _Member.birthdate = dr["birthdate"].ToString();

                string prog_cd = dr.ItemArray[8].ToString();

                if (prog_cd.Equals("PC001001"))
                {
                    _Member.PCCD_NAME = "SKIN FUTURE PROGRAM";
                }
                else if (prog_cd.Equals("PC001006"))
                {
                    _Member.PCCD_NAME = "SKIN COUNSELING PROGRAM";
                }
                else if (prog_cd.Equals("PC001010"))
                {
                    _Member.PCCD_NAME = "SCALP PROGRAM";
                }
                else if (prog_cd.Equals("PC001011"))
                {
                    _Member.PCCD_NAME = "GENE PROGRAM";
                }

                _Member.PCCD = prog_cd;


                LoginSession.SelectedMember = _Member;
                LoginSession.SelectedM_Markvu_Capture = null;

                SetMemberData(_Member);

                CommonBiz.SetMemberTopText(LoginSession.SelectedMember);
                CommonBiz.SelectMenu(MainWindow.Menus.ResultPage);
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }
        }

        private void SetMemberData(Member _Member)
        {
            try
            {             
                //문진 데이터 조회
                SurveyService.SurveyServiceClient ssc = new SurveyService.SurveyServiceClient();
                    LoginSession.SelectedSurvey = ssc.Get_C_SurveyResult_surveyNo(_Member.surveyNo);
                    if (ssc.State != System.ServiceModel.CommunicationState.Closed)
                    {
                        ssc.Close();
                    }

                    //기기 데이터 조회
                    DeviceService.DeviceServiceClient dsc = new DeviceService.DeviceServiceClient();
                    LoginSession.SelectedM_Markvu_ResultData = dsc.Get_C_ResultMarkVu(_Member.surveyNo);

                    DataTable dv = dsc.SelectVapometer(_Member.surveyNo, _Member.userkey);
                    if (dv != null && dv.Rows.Count > 0)
                    {
                        M_Vapometer Data = new M_Vapometer();

                        foreach (DataRow dr in dv.Rows)
                        {
                            Data.surveyNo = Convert.ToInt32(dr["surveyNo"].ToString());
                            Data.userkey = Convert.ToInt32(dr["userkey"].ToString());
                            Data.C_Left = dr["C_Left"].ToString();
                            Data.C_Right = dr["C_Right"].ToString();
                        }

                        LoginSession.SelectedM_Vapometer = Data;
                    }

                //LoginSession.ProgramCourseflg == "I"

                if (LoginSession.SelectedMember.course_flg == "I")
                {
                        DataTable dt = dsc.Select_CNK_Cutometer(_Member.surveyNo, _Member.userkey);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            M_CNK_Cutometer Data = new M_CNK_Cutometer();

                            foreach (DataRow dr in dt.Rows)
                            {
                                Data.surveyNo = Convert.ToInt32(dr["surveyNo"].ToString());
                                Data.userkey = Convert.ToInt32(dr["userkey"].ToString());
                                Data.eye_area = dr["eye_area"].ToString();
                                Data.cheek = dr["cheek"].ToString();
                            }

                            LoginSession.SelectedM_CNK_Customer = Data;
                        }
                    }

                    if (dsc.State != System.ServiceModel.CommunicationState.Closed)
                    {
                        dsc.Close();
                    }

                    //결과 데이터 조회
                    ResultService.ResultServiceClient rsc = new ResultService.ResultServiceClient();
                    LoginSession.Selected_C_ResultPageData = rsc.Get_C_Result_Rpt(_Member.surveyNo, _Member.userkey.ToString());
                    if (rsc.State != System.ServiceModel.CommunicationState.Closed)
                    {
                        rsc.Close();
                    }
                    
                    //CommonBiz.SetMemberTopText(member);
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }
        }

        private void btn_Security_UserData_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var senderElement = e.OriginalSource as FrameworkElement;
                GridViewRowItem ri = (senderElement.Parent as Telerik.Windows.Controls.GridView.GridViewCell).ParentRow as GridViewRowItem;
                DataRow dr = ri.DataContext as DataRow;
                rgvMemberList.SelectedItem = dr;

                Member _Member = new Member();
                _Member.userkey = Convert.ToInt32(dr["userKey"].ToString());
                _Member.surveyNo = Convert.ToInt32(dr["surveyNo"].ToString());
                _Member.rsvn_date = Convert.ToDateTime(dr["surveyDate"].ToString());
                _Member.phone = dr["Phone"].ToString();
                _Member.name = dr["name"].ToString();
                _Member.sex = dr["Sex"].ToString();

                if (CommonMessageBox.ShowConfirmMessage(string.Format("{0}님의 모든 정보가 삭제됩니다.\n\n해당 삭제는 고객님의 모든 데이터를 삭제 함으로 복구가 불가능 합니다.\n\n 삭제 하시겠습니까?", _Member.name), 500 , 300) == MessageBoxResult.Yes)
                {
                    MemberService.MemberServiceClient msc = new MemberService.MemberServiceClient();
                    if (msc.Member_Security_UserData_Delete(_Member.name, _Member.phone) == true)
                    {
                        string sLogs = string.Format("고객정보삭제 : 사용자 - ''{0}'' | {1}[{2}] ", LoginSession.LoginManagerInfo.ManagerName, _Member.name , _Member.userkey);

                        ManagerService.ManagerServiceClient msc_1 = new ManagerService.ManagerServiceClient();
                        msc_1.InsertLogs(IOPE_LAB_CONTROLS.Const.LogsProcessType.USER_DELETE, IOPE_LAB_CONTROLS.Const.LogsProcess.UserDataDelete, sLogs, LoginSession.LoginManagerInfo.ManagerKey);

                        if (msc_1.State != System.ServiceModel.CommunicationState.Closed)
                        {
                            msc_1.Close();
                        }
                        CommonMessageBox.ShowAlertMessage("삭제 되었습니다.");
                    }
                    else
                    {
                        CommonMessageBox.ShowAlertMessage("삭제에 실패 하였습니다.\n\n 다시시도 하여 주십시오.");
                    }
                }

                //LoginSession.SelectedMember = _Member;
                //SetMemberData(_Member);
                //CommonBiz.SetMemberTopText(LoginSession.SelectedMember);
                //CommonBiz.SelectMenu(MainWindow.Menus.ResultPage);
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }

            
        }
    }
}
