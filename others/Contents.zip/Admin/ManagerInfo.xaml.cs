﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS;
using IOPE_LAB.Common;
using Microsoft.Win32;
using System.Windows.Forms;
using System.IO;
using IOPE_LAB_CONTROLS.Entity;
using Telerik.Windows.Controls;
using System.Text.RegularExpressions;

namespace IOPE_LAB.Contents.Admin
{
    /// <summary>
    /// ManagerInfo.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ManagerInfo : System.Windows.Controls.UserControl
    {
        #region =============================== Member ===================================
        public enum ViewMode
        {
            List, View, Add, Modify
        }
        public ViewMode ViewStatus = ViewMode.List;
        private byte[] m_Image = null;

        Manager SelectedManager = null;

        public int SelectedRoadFL = 1;
        public string SelectedRoadCode = string.Empty;
        #endregion


        #region ============================ Constructor =================================
        public ManagerInfo()
        {
            InitializeComponent();
            InitEvent();
        }
        
        #endregion


        private void InitEvent()
        {
            this.btnAdd.Click += new RoutedEventHandler(btnAdd_Click);
            this.btnModify.Click += new RoutedEventHandler(btnModify_Click);
            this.btnSave.Click += new RoutedEventHandler(btnSave_Click);
            //this.btnView.Click += new RoutedEventHandler(btnView_Click);
            this.rgvMemberList.SelectionChanged += new EventHandler<Telerik.Windows.Controls.SelectionChangeEventArgs>(rgvMemberList_SelectionChanged);
            this.rgvMemberList.RowLoaded += new EventHandler<Telerik.Windows.Controls.GridView.RowLoadedEventArgs>(rgvMemberList_RowLoaded);
            this.Loaded += new RoutedEventHandler(ManagerInfo_Loaded);
            this.btnPwdClear.Click += new RoutedEventHandler(btnPwdClear_Click);
            this.btn_SelectPhoto.Click+=new RoutedEventHandler(btn_SelectPhoto_Click);
        }

        void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (CheckValidate())
                {
                    //string sSSN = txtSSN1.Text + txtSSN2.Password;
                    //string sZipCode = txtZip1.Text + "-" + txtZip2.Text;

                    Manager manager = null;

                    // 수정 모드일때는 현재 선택된 직원객체를 불러온다.
                    if (this.ViewStatus == ViewMode.Modify)
                        manager = this.SelectedManager;
                    else
                        manager = new Manager();

                    if (CommonClass.GetComboBoxSelectedValue(cbWorkStatus) == "MS001002")
                    {
                        //ManagerSvc.ManagerServiceClient managerSvc = new ManagerSvc.ManagerServiceClient();

                        if (LoginSession.LoginManagerInfo.ManagerKey == manager.ManagerKey)
                            Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_32);
                        //else if (managerSvc.GetMemberCntByManager(manager.ManagerCD, manager.ManagerKey) > 0)
                        //    Common.CommonMessageBox.ShowAlertMessage("담당하고 있는 회원이 있습니다. 다른 매니저로 이관을 먼저 해주십시오");
                        else
                            SaveManagerInfo(manager);

                        //if (managerSvc.State != System.ServiceModel.CommunicationState.Closed)
                        //    managerSvc.Close();
                    }
                    else
                    {
                        SaveManagerInfo(manager);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        private void SaveManagerInfo(Manager manager)
        {
            manager.ManagerID = txtManagerID.Text.ToString();
            manager.ManagerName = txtManagerName.Text.ToString();
            manager.CenterCode = "CT100001"; //CommonClass.GetComboBoxSelectedValue(cboCenter);
            manager.ManagerRoleCD = CommonClass.GetComboBoxSelectedValue(cbRoleCD);

            GP.Common.Helper.Crypt.SetCryptKey("IOPEBIOL");
            if (string.IsNullOrWhiteSpace(manager.Password))
                manager.Password = GP.Common.Helper.Crypt.SHA512Hash(Common.CommonBiz.ClearPassword);

            manager.ManagerName = txtManagerName.Text;
            //manager.ResidNo = sSSN;

            if ((txtPhone1.Text != string.Empty) && (txtPhone2.Text != string.Empty) && (txtPhone3.Text != string.Empty))
                manager.Phone = string.Format("{0}-{1}-{2}", txtPhone1.Text, txtPhone2.Text, txtPhone3.Text);

            if ((txtMobile1.Text != string.Empty) && (txtMobile2.Text != string.Empty) && (txtMobile3.Text != string.Empty))
                manager.Mobile = string.Format("{0}-{1}-{2}", txtMobile1.Text, txtMobile2.Text, txtMobile3.Text);

            manager.Email = txtEmail.Text;

            byte[] bPhoto;
            if (mPhoto.Source != null)
                bPhoto = m_Image;
            else
                bPhoto = new byte[0];

            if (mPhoto.Source == null)
                manager.Photo = new byte[0];
            else
                manager.Photo = CommonClass.ConvertBitmapImageToBytestream(mPhoto.Source as BitmapImage);
              
            manager.ManagerCD = "MG001000";
            manager.ManagerRoleCD = CommonClass.GetComboBoxSelectedValue(cbRoleCD);


            manager.IsWorkStatusCode = CommonClass.GetComboBoxSelectedValue(cbWorkStatus);

            manager.RoadFL = SelectedRoadFL;
            manager.RoadCode = SelectedRoadCode;

            manager.PasswordLock = Convert.ToInt32(txtMissPasswordCnt.Text);

            ManagerService.ManagerServiceClient managerSvc = new ManagerService.ManagerServiceClient();

            int iResult = -1;
            string sMsg = string.Empty;
            string sLogs = string.Empty;
            IOPE_LAB_CONTROLS.Const.LogsProcessType processType = IOPE_LAB_CONTROLS.Const.LogsProcessType.ADD;

            if (ViewStatus == ViewMode.Add)
            {
                sMsg = "직원등록";
                iResult = managerSvc.AddManager(manager);
                sLogs = string.Format("직원등록 : 이름 - ''{0}''", manager.ManagerName);
                processType = IOPE_LAB_CONTROLS.Const.LogsProcessType.ADD;
            }
            else
            {
                sMsg = "직원수정";
                iResult = managerSvc.ModifyManager(manager);
                sLogs = string.Format("직원수정 : 이름 - ''{0}''", manager.ManagerName);
                processType = IOPE_LAB_CONTROLS.Const.LogsProcessType.MOD;
            }

            if (managerSvc.State != System.ServiceModel.CommunicationState.Closed)
                managerSvc.Close();


            ManagerService.ManagerServiceClient msc_1 = new ManagerService.ManagerServiceClient();

            msc_1.InsertLogs(processType, IOPE_LAB_CONTROLS.Const.LogsProcess.ManagerInfo, sLogs, LoginSession.LoginManagerInfo.ManagerKey);

            if (msc_1.State != System.ServiceModel.CommunicationState.Closed)
            {
                msc_1.Close();
            }

            if (iResult > 0)
            {
                Common.CommonMessageBox.ShowAlertMessage(string.Format(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_33, sMsg));
                BindList();
            }
            else
                Common.CommonMessageBox.ShowErrorMessage(string.Format(IOPE_LAB_LOCALIZATION.Properties.Resources.showError_04, sMsg));

            InitializeControls(ViewMode.List);
        }

        private bool CheckValidate()
        {
            bool bResult = true;
            if (string.IsNullOrWhiteSpace(txtManagerName.Text))
            {
                Common.CommonMessageBox.ShowErrorMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showError_05);
                txtManagerName.Focus();
                bResult = false;
            }
            //else if (string.IsNullOrWhiteSpace(CommonClass.GetComboBoxSelectedValue(cboCenter)))
            //{
            //    Common.CommonMessageBox.ShowErrorMessage("직원 담당센터를 선택하세요");
            //    cboCenter.Focus();
            //    bResult = false;
            //}
            else if (string.IsNullOrWhiteSpace(txtManagerID.Text))
            {
                Common.CommonMessageBox.ShowErrorMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showError_06);
                txtManagerID.Focus();
                bResult = false;
            }
            else if (string.IsNullOrWhiteSpace(txtMobile1.Text) || string.IsNullOrWhiteSpace(txtMobile2.Text) || string.IsNullOrWhiteSpace(txtMobile3.Text))
            {
                Common.CommonMessageBox.ShowErrorMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showError_07);
                txtMobile1.Focus();
                bResult = false;
            }
            else if (!string.IsNullOrWhiteSpace(txtEmail.Text) && !CheckEmail(txtEmail.Text))
            {
                Common.CommonMessageBox.ShowErrorMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showError_08);
                txtEmail.Focus();
                bResult = false;
            }
            else if (string.IsNullOrWhiteSpace(CommonClass.GetComboBoxSelectedValue(cbRoleCD)))
            {
                Common.CommonMessageBox.ShowErrorMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showError_09);
                cbRoleCD.Focus();
                bResult = false;
            }
            else
            {
                if (ViewStatus == ViewMode.Add)
                {
                    MessageBoxResult result = Common.CommonMessageBox.ShowConfirmMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.ManagerInfo_str05);
                    bResult = (result == MessageBoxResult.Yes);
                }
                else
                {
                    MessageBoxResult result = Common.CommonMessageBox.ShowConfirmMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.ManagerInfo_str06);
                    bResult = (result == MessageBoxResult.Yes);
                }

                //string sMsg = (ViewStatus == ViewMode.Add) ? "직원등록" : "직원정보수정";
                //MessageBoxResult result = Common.CommonMessageBox.ShowConfirmMessage(sMsg + "을 하시겠습니까?");
                //bResult = (result == MessageBoxResult.Yes);
            }

            return bResult;
        }

        public static bool CheckEmail(string sEmail)
        {
            return Regex.IsMatch(sEmail,
              @"^(?("")("".+?""@)|(([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-zA-Z])@))" +
              @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,6}))$");
        }

        void btnModify_Click(object sender, RoutedEventArgs e)
        {
            InitializeControls(ViewMode.Modify);
        }

        private void InitializeControls(ViewMode vm)
        {
            this.ViewStatus = vm;
            switch (vm)
            {
                case ViewMode.List:
                    //btnView.IsEnabled = true;
                    btnSave.IsEnabled = false;
                    btnModify.IsEnabled = false;
                    btnAdd.IsEnabled = true; // (LoginSession.LoginManagerInfo.MenuWriteYN);
                    grpBasic.IsEnabled = false;
                    btn_SelectPhoto.IsEnabled = false;
                    break;
                case ViewMode.View:
                    //btnView.IsEnabled = true;
                    btnSave.IsEnabled = false;
                    btnModify.IsEnabled = true;//(LoginSession.LoginManagerInfo.MenuWriteYN);
                    btnAdd.IsEnabled = true;//(LoginSession.LoginManagerInfo.MenuWriteYN);
                    grpBasic.IsEnabled = false;
                    btn_SelectPhoto.IsEnabled = false;

                    tbPwdMsg.Visibility = System.Windows.Visibility.Collapsed;
                    btnPwdClear.Visibility = System.Windows.Visibility.Visible;
                    break;
                case ViewMode.Add:
                    //btnView.IsEnabled = true;
                    btnSave.IsEnabled = true; //(LoginSession.LoginManagerInfo.MenuWriteYN);
                    btnModify.IsEnabled = false;
                    btnAdd.IsEnabled = false;
                    grpBasic.IsEnabled = true; //(LoginSession.LoginManagerInfo.MenuWriteYN);
                    btn_SelectPhoto.IsEnabled = true; //(LoginSession.LoginManagerInfo.MenuWriteYN);

                    txtManagerID.Text =
                    txtManagerName.Text =
                    txtPhone1.Text =
                    txtPhone2.Text =
                    txtPhone3.Text =
                    txtMobile1.Text =
                    txtMobile2.Text =
                    txtMobile3.Text =
                    //txtZip1.Text =
                    //txtZip2.Text =
                    //txtAddress1.Text =
                    //txtAddress2.Text =
                    txtEmail.Text = string.Empty;


                    //cbManagerCD.SelectedIndex =
                    //cbRoleCD.SelectedIndex = 0;

                    mPhoto.Source = null;
                    m_Image = null;
                    //CommonClass.SetComboBoxSelectedValue(cbWorkStatus, "MS001001");
                    //work_start.SelectedTime = new TimeSpan(9, 0, 0);
                    //work_end.SelectedTime = new TimeSpan(18, 0, 0);

                    tbPwdMsg.Visibility = System.Windows.Visibility.Visible;
                    btnPwdClear.Visibility = System.Windows.Visibility.Collapsed;
                    break;
                case ViewMode.Modify:
                    //btnView.IsEnabled = true;
                    btnSave.IsEnabled = true;//(LoginSession.LoginManagerInfo.MenuWriteYN);
                    btnModify.IsEnabled = false;
                    btnAdd.IsEnabled = false;
                    grpBasic.IsEnabled = true;//(LoginSession.LoginManagerInfo.MenuWriteYN);
                    btn_SelectPhoto.IsEnabled = true;//(LoginSession.LoginManagerInfo.MenuWriteYN);

                    tbPwdMsg.Visibility = System.Windows.Visibility.Collapsed;
                    btnPwdClear.Visibility = System.Windows.Visibility.Visible;
                    break;
            }
        }

        void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            InitializeControls(ViewMode.Add);
        }

        void btnPwdClear_Click(object sender, RoutedEventArgs e)
        {
            if (Common.CommonMessageBox.ShowConfirmMessage(string.Format(IOPE_LAB_LOCALIZATION.Properties.Resources.showConfirm_06, Common.CommonBiz.ClearPassword)) == MessageBoxResult.Yes)
            {
                ManagerService.ManagerServiceClient msc = new ManagerService.ManagerServiceClient();
                if (msc.UpdateManagerPassword(SelectedManager.ManagerKey, Common.CommonBiz.ClearPassword) > 0)
                    Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_09);
                if (msc.State != System.ServiceModel.CommunicationState.Closed)
                    msc.Close();
            }
        }

        void ManagerInfo_Loaded(object sender, RoutedEventArgs e)
        {
            LoginSession.SelectedVisitSchMember = null;
            LoginSession.SelectedMember = null;
            LoginSession.SelectedSurvey = null;
            LoginSession.SelectedResult_Rpt = null;
            LoginSession.SelectedM_Antera = null;
            LoginSession.SelectedM_skintouch = null;
            LoginSession.SelectedM_Jeonan = null;
            LoginSession.SelectedCanvasImageEntity = null;

            try
            {
                InitializeControls(ViewMode.List);
                //BindParams();
                //BindList();
                //tbPwdMsg.Text = string.Format(IOPE_LAB_LOCALIZATION.Properties.Resources.ManagerInfo_str03 + "{0}" + IOPE_LAB_LOCALIZATION.Properties.Resources.ManagerInfo_str04, Common.CommonBiz.ClearPassword);
            }
            catch (Exception ex)
            {
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
                //Common.CommonMessageBox.ShowErrorMessage(ex.Message);
            }
        }

        private void BindList()
        {
            try
            {
                ManagerService.ManagerServiceClient managerSvc = new ManagerService.ManagerServiceClient();

                List<Manager> _managerList = null;

                var result = managerSvc.GetManagerListByEntity();
                if (result != null)
                    _managerList = result.ToList<Manager>();

                if (managerSvc.State != System.ServiceModel.CommunicationState.Closed)
                    managerSvc.Close();
                if (_managerList != null)
                    rgvMemberList.ItemsSource = _managerList;
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        private void BindParams()
        {
            CommonClass.DataBindComboBox(Common.BasicCodeList.ManagerRoleCode, cbRoleCD, "- 선택 -");
            CommonClass.DataBindComboBox(Common.BasicCodeList.ManagerStatusCode, cbWorkStatus, "- 선택 -");
        }

        void rgvMemberList_RowLoaded(object sender, Telerik.Windows.Controls.GridView.RowLoadedEventArgs e)
        {
            try
            {
                if (e.DataElement != null)
                {
                    Manager manager = e.Row.Item as Manager;

                    TextBlock tbWorkStatus = e.Row.Cells[6].Content as TextBlock;
                    //TextBlock tbWorkTime = e.Row.Cells[8].Content as TextBlock;

                    tbWorkStatus.Text = manager.IsWorkStatusName;
                    //tbWorkTime.Text = string.Format("{0} ~ {1}", manager.WorkStartTime, manager.WorkEndTime);

                    if (manager.IsWorkStatusCode == "MS001001")
                        tbWorkStatus.Foreground = Brushes.Blue;
                    else
                        tbWorkStatus.Foreground = Brushes.Red;
                }


            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        void rgvMemberList_SelectionChanged(object sender, Telerik.Windows.Controls.SelectionChangeEventArgs e)
        {
            try
            {

                RadGridView rgv = e.Source as RadGridView;

                if (rgv.SelectedItem != null)
                {
                    InitializeControls(ViewMode.View);

                    SelectedManager = rgv.SelectedItem as Manager;

                    // 담당 회원 변경 - 근무중이고 카운터 또는 다이어트플래너 또는 트레이너 또는 테라피스트만 활성화
                    //btnChangeMember.IsEnabled = (SelectedManager.IsWorkStatusCode == "MS001001")
                    //    && ((SelectedManager.ManagerCD == "MG001001") || (SelectedManager.ManagerCD == "MG001002") || (SelectedManager.ManagerCD == "MG001004") || (SelectedManager.ManagerCD == "MG001005"));
                    //btnChangeMemberSpecify.IsEnabled = (SelectedManager.IsWorkStatusCode == "MS001001")
                    //    && ((SelectedManager.ManagerCD == "MG001001") || (SelectedManager.ManagerCD == "MG001002") || (SelectedManager.ManagerCD == "MG001004") || (SelectedManager.ManagerCD == "MG001005"));



                    txtManagerName.Text = SelectedManager.ManagerName;
                    CommonClass.SetComboBoxSelectedValue(cboCenter, SelectedManager.CenterCode);
                    //if (SelectedManager.ResidNo != string.Empty && SelectedManager.ResidNo != null)
                    //{
                    //    txtSSN1.Text = SelectedManager.ResidNo.Substring(0, 6);
                    //    txtSSN2.Password = SelectedManager.ResidNo.Substring(6, 7);
                    //}
                    //else
                    //{
                    //    txtSSN1.Text = string.Empty;
                    //    txtSSN2.Password = string.Empty;
                    //}
                    txtManagerID.Text = SelectedManager.ManagerID;

                    //매니저 선택시 패스워드는 바인딩 하지 않습니다.
                    //txtPassword.Password = SelectedManager.Password;

                    if (SelectedManager.Phone != string.Empty)
                    {
                        string[] ret = SelectedManager.Phone.Split('-');
                        txtPhone1.Text = ret[0];
                        txtPhone2.Text = ret[1];
                        txtPhone3.Text = ret[2];
                    }
                    else
                    {
                        txtPhone1.Text = string.Empty;
                        txtPhone2.Text = string.Empty;
                        txtPhone3.Text = string.Empty;
                    }
                    if (SelectedManager.Mobile != string.Empty)
                    {
                        string[] ret = SelectedManager.Mobile.Split('-');
                        txtMobile1.Text = ret[0];
                        txtMobile2.Text = ret[1];
                        txtMobile3.Text = ret[2];
                    }
                    else
                    {
                        txtMobile1.Text = string.Empty;
                        txtMobile2.Text = string.Empty;
                        txtMobile3.Text = string.Empty;
                    }

                    //if ((SelectedManager.ZipCode != string.Empty) && (SelectedManager.ZipCode.Length == 7))
                    //{
                    //    string[] ret = SelectedManager.ZipCode.Split('-');
                    //    txtZip1.Text = ret[0];
                    //    txtZip2.Text = ret[1];
                    //}
                    //else
                    //{
                    //    txtZip1.Text = string.Empty;
                    //    txtZip2.Text = string.Empty;
                    //}

                    //txtAddress1.Text = SelectedManager.Address;
                    //txtAddress2.Text = SelectedManager.AddressDetail;
                    txtEmail.Text = SelectedManager.Email;
                    //txtCSNO.Text = SelectedManager.CSNO.ToString();

                    if (SelectedManager.Photo != null)
                        mPhoto.Source = CommonClass.ConvertBytesToBitmap(SelectedManager.Photo);
                    else
                    {
                        mPhoto.Source = null;
                    }

                    //CommonClass.SetComboBoxSelectedValue(cbManagerCD, SelectedManager.ManagerCD.ToString());
                    CommonClass.SetComboBoxSelectedValue(cbRoleCD, SelectedManager.ManagerRoleCD.ToString());
                    CommonClass.SetComboBoxSelectedValue(cbWorkStatus, SelectedManager.IsWorkStatusCode.ToString());

                    //if (!string.IsNullOrWhiteSpace(SelectedManager.WorkStartTime.ToString()))
                    //{
                    //    work_start.SelectedValue = DateTime.Parse(SelectedManager.WorkStartTime.ToString());
                    //}
                    //else
                    //{
                    //    work_start.SelectedValue = null;
                    //}
                    //if (!string.IsNullOrWhiteSpace(SelectedManager.WorkEndTime.ToString()))
                    //{
                    //    work_end.SelectedValue = DateTime.Parse(SelectedManager.WorkEndTime.ToString());
                    //}
                    //else
                    //{
                    //    work_end.SelectedValue = null;
                    //}

                    this.SelectedRoadFL = SelectedManager.RoadFL;
                    this.SelectedRoadCode = SelectedManager.RoadCode;

                    this.txtRegDate.Text = SelectedManager.RegDate.ToString("yyyy-MM-dd");
                    this.txtUpdDate.Text = SelectedManager.upd_dt.ToString("yyyy-MM-dd");

                    this.txtMissPasswordCnt.Text = SelectedManager.PasswordLock.ToString();
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        private void btn_SelectPhoto_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.OpenFileDialog dlg = new System.Windows.Forms.OpenFileDialog();
            dlg.Filter = "모든 이미지형식 파일|*.jpg;*.gif;*.png;*.bmp";//"txt files (*.txt)|*.txt|All files (*.*)|*.*" ;
            OpenSelectPhoto(dlg);

        }

        private void OpenSelectPhoto(System.Windows.Forms.OpenFileDialog dlg)
        {
            try
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    if (dlg.OpenFile().Length > 307200)
                    {
                        Common.CommonMessageBox.ShowErrorMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showError_10);
                        OpenSelectPhoto(dlg);
                    }
                    else
                    {
                        m_Image = File.ReadAllBytes(dlg.FileName);
                        mPhoto.Source = CommonClass.ConvertBytesToBitmap(m_Image);
                    }
                }
                else
                    Common.CommonMessageBox.ShowErrorMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showError_11);
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }
    }
}
