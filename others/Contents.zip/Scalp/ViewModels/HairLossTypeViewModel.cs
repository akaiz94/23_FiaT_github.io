﻿using IOPE_LAB.Contents.Scalp.Utils;
using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOPE_LAB.Contents.Scalp.ViewModels
{
    /// <summary>
    /// HAIR LOSS TYPE 관련 뷰모델입니다. (2가지 유형)
    /// </summary>
    public class HairLossTypeViewModel: ViewModelBase
    {
        private string _basicType;
        private string _hairLossTypeCenter;
        private string _yourLossType;

        public string BasicType {
            get { return _basicType; }
            set { _basicType = value; }
        }
        public string HairLossTypeCenter {
            get { return _hairLossTypeCenter;  }
            set { _hairLossTypeCenter = value; }
        }

        public string YourLossType {
            get { return _yourLossType; }
            set { _yourLossType = value; }
        }

        public HairLossTypeViewModel()
        {
            List<string> lossTwoType = DBManager.GetHairLossTypeList();

            this._basicType = DBManager.GetHairLossBasicType();
            this._hairLossTypeCenter = lossTwoType[1];
            this._yourLossType = string.Format("고객님의 탈모 유형은 {0}+{1}형입니다.", this._basicType, this._hairLossTypeCenter);
        }
    }
}
