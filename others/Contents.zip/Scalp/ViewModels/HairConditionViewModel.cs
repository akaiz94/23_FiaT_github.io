﻿using IOPE_LAB.Contents.Scalp.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOPE_LAB.Contents.Scalp.ViewModels
{
    public class HairConditionViewModel: ViewModelBase
    {
        private int _hairConditionRoot;
        private int _hairConditionMid;
        private int _hairConditionTips;
        private string _hairConditionRootText;
        private string _hairConditionMidText;
        private string _hairConditionTipsText;

        public int HairConditionRoot 
        {
            get { return _hairConditionRoot; }
            set { _hairConditionRoot = value; }
        }
        public int HairConditionMid 
        {
            get {return _hairConditionMid;}
            set {_hairConditionMid = value; }
        }
        public int HairConditionTips 
        {
            get {return _hairConditionTips;}
            set {_hairConditionTips = value; }
        }
        public string HairConditionRootText 
        {
            get {return _hairConditionRootText;}
            set {_hairConditionRootText = value; }
        }
        public string HairConditionMidText 
        {
            get {return _hairConditionMidText;}
            set {_hairConditionMidText = value; }
        }
        public string HairConditionTipsText 
        {
            get {return _hairConditionTipsText;}
            set {_hairConditionTipsText = value; }
        }

        public HairConditionViewModel()
        {
            this._hairConditionRoot = DBManager.GetRootHairCondition();
            this._hairConditionMid = DBManager.GetMidHairCondition();
            this._hairConditionTips = DBManager.GetTipsHairCondition();

            this._hairConditionRootText = intToString(this._hairConditionRoot);
            this._hairConditionMidText = intToString(this._hairConditionMid);
            this._hairConditionTipsText = intToString(this._hairConditionTips);
        }



        /// <summary>
        /// 부위별 Hair Condition의 Value에 따라 Text를 매핑해 반환합니다.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string intToString(int value)
        {
            string text = string.Empty;
            switch (value)
            {
                case 0:
                    text = "건강모";
                    break;
                case 1:
                    text = "약손상모";
                    break;
                case 2:
                    text = "손상모";
                    break;
                case 3:
                    text = "극손상모";
                    break;
                case 4:
                    text = "열모/지모";
                    break;
            }

            return text;
        }
    }
}
