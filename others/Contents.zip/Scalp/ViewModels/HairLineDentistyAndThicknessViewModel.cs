﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using IOPE_LAB.Contents.Scalp.Utils;
using System.Windows.Media.Imaging;
using System.IO;

namespace IOPE_LAB.Contents.Scalp.ViewModels
{
    /// <summary>
    /// HAIR DENSITY & THICKNESS 관련 뷰모델입니다.
    /// </summary>
    public class HairLineDentistyAndThicknessViewModel: ViewModelBase
    {
        private ScalpService.ScalpServiceClient _scalpsc;
        private DataTable _imgDt;

        private Hair_ScalpType_Entity _center;
        private Hair_ScalpType_Entity _back;
        private Hair_ScalpType_Entity _frontCenter;
        private Hair_ScalpType_Entity _frontHairLine;
        private Hair_ScalpType_Entity _leftHairLine;
        private Hair_ScalpType_Entity _rightHairLine;

        private BitmapImage _leftHairLineImage;
        private BitmapImage _rightHairLineImage;
        private BitmapImage _centerHairLineImage;
        private BitmapImage _backHairLineImage;
        private BitmapImage _frontCenterHairLineImage;
        private BitmapImage _frontHairLineImage;

        private string _centerScalpType;
        private string _backScalpType;
        private string _frontCenterScalpType;
        private string _frontHairLineScalpType;
        private string _leftHairLineScalpType;
        private string _rightHairLineScalpType;

        private int _UCCardIndex;

        public Hair_ScalpType_Entity Center 
        {
            get { return _center; }
            set { _center = value; }
        }
        public Hair_ScalpType_Entity Back 
        {
            get {return _back;}
            set {_back = value; }
        }
        public Hair_ScalpType_Entity FrontCenter 
        {
            get {return _frontCenter;}
            set {_frontCenter = value; }
        }
        public Hair_ScalpType_Entity FrontHairLine 
        {
            get {return _frontHairLine;}
            set {_frontHairLine = value; }
        }
        public Hair_ScalpType_Entity LeftHairLine 
        {
            get {return _leftHairLine;}
            set {_leftHairLine = value; }
        }
        public Hair_ScalpType_Entity RightHairLine 
        {
            get {return _rightHairLine;}
            set {_rightHairLine = value; }
        }


        public string CenterScalpType 
        {
            get { return _centerScalpType; }
            set { _centerScalpType = value; }
        }
        public string BackScalpType 
        {
            get {return _backScalpType; }
            set { _backScalpType = value; }
        }
        public string FrontCenterScalpType 
        {
            get {return _frontCenterScalpType; }
            set { _frontCenterScalpType = value; }
        }
        public string FrontHairLineScalpType 
        {
            get {return _frontHairLineScalpType; }
            set { _frontHairLineScalpType = value; }
        }
        public string LeftHairLineScalpType 
        {
            get {return _leftHairLineScalpType; }
            set { _leftHairLineScalpType = value; }
        }
        public string RightHairLineScalpType 
        {
            get {return _rightHairLineScalpType; }
            set { _rightHairLineScalpType = value; }
        }

        public int UCCardIndex
        {
            get { return _UCCardIndex; }
            set { _UCCardIndex = value; }
        }

        public BitmapImage LeftHairLineImage { get { return _leftHairLineImage; } set { _leftHairLineImage = value; } }
        public BitmapImage RightHairLineImage { get { return _rightHairLineImage;} set { _rightHairLineImage = value;} }
        public BitmapImage CenterHairLineImage { get { return _centerHairLineImage;} set { _centerHairLineImage = value;} }
        public BitmapImage BackHairLineImage { get { return _backHairLineImage;} set { _backHairLineImage = value;} }
        public BitmapImage FrontCenterHairLineImage { get { return _frontCenterHairLineImage;} set { _frontCenterHairLineImage = value;} }
        public BitmapImage FrontHairLineImage { get { return _frontHairLineImage;} set { _frontHairLineImage = value;} }

        public HairLineDentistyAndThicknessViewModel()
        {
            this._scalpsc = new ScalpService.ScalpServiceClient();
            _imgDt = _scalpsc.ScalpType_Images(IOPE_LAB_CONTROLS.Base.LoginSession.SelectedMember.surveyNo, IOPE_LAB_CONTROLS.Base.LoginSession.SelectedSurvey_M.userkey);

            this._center = LoadUserScalpTypeBaseData(ScalpTypeTableList.Center);
            this._back = LoadUserScalpTypeBaseData(ScalpTypeTableList.Back);
            this._frontCenter = LoadUserScalpTypeBaseData(ScalpTypeTableList.FrontCenter);
            this._frontHairLine = LoadUserScalpTypeBaseData(ScalpTypeTableList.FrontHairLine);
            this._leftHairLine = LoadUserScalpTypeBaseData(ScalpTypeTableList.LeftHairLine);
            this._rightHairLine = LoadUserScalpTypeBaseData(ScalpTypeTableList.RightHairLine);

            this._centerHairLineImage = ConvertBytesToBitmap((byte[])_imgDt.Rows[0]["Scalp_Center"]);
            this._backHairLineImage = ConvertBytesToBitmap((byte[])_imgDt.Rows[0]["Scalp_Back"]); 
            this._frontCenterHairLineImage = ConvertBytesToBitmap((byte[])_imgDt.Rows[0]["Scalp_FrontCenter"]); 
            this._frontHairLineImage = ConvertBytesToBitmap((byte[])_imgDt.Rows[0]["Scalp_FrontHairLine"]); 
            this._leftHairLineImage = ConvertBytesToBitmap((byte[])_imgDt.Rows[0]["Scalp_LeftHairLine"]); 
            this._rightHairLineImage = ConvertBytesToBitmap((byte[])_imgDt.Rows[0]["Scalp_RightHairLine"]); 

            this._centerScalpType = GetScalpType(this._center);
            this._backScalpType = GetScalpType(this._back);
            this._frontCenterScalpType = GetScalpType(this._frontCenter);
            this._frontHairLineScalpType = GetScalpType(this._frontHairLine);
            this._leftHairLineScalpType = GetScalpType(this._leftHairLine);
            this._rightHairLineScalpType = GetScalpType(this._rightHairLine);

            this._UCCardIndex = 1;
        }

        public BitmapImage ConvertBytesToBitmap(byte[] _data)
        {
            try
            {
                byte[] image = _data;
                string base64String = Encoding.UTF8.GetString(image, 0, image.Length);

                BitmapImage bitmap = new BitmapImage();
                MemoryStream strm = new MemoryStream();
                strm.Write(System.Convert.FromBase64String(base64String), 0, System.Convert.FromBase64String(base64String).Length);
                strm.Seek(0, SeekOrigin.Begin);
                // Read the image into the bitmap object
                bitmap.BeginInit();
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.StreamSource = strm;
                bitmap.EndInit();
                return bitmap;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// 부위별 해당하는 두피 타입의 value(0, 1)를 Text로 매핑해주기 위한 함수입니다.
        /// </summary>
        /// <param name="model"></param>
        /// <returns>string</returns>
        public string GetScalpType(Hair_ScalpType_Entity model)
        {
            string scalpType = "";

            var ScalpTypes = new Dictionary<string, int>();

            ScalpTypes.Add("양호", model.ScalpType_Nor);
            ScalpTypes.Add("지성", model.ScalpType_Oily);
            ScalpTypes.Add("아토피성", model.ScalpType_Ato);
            ScalpTypes.Add("트러블성", model.ScalpType_Trb);
            ScalpTypes.Add("민감성", model.ScalpType_Sen);
            ScalpTypes.Add("지루성", model.ScalpType_Seb);
            ScalpTypes.Add("건성", model.ScalpType_Dry);
            ScalpTypes.Add("건성비듬성", model.ScalpType_Ddan);
            ScalpTypes.Add("지성비듬성", model.ScalpType_Odan);
            ScalpTypes.Add("분석실패", model.ScalpType_Unknown);

            var ScalpTypesResult = ScalpTypes.Where(x => x.Value == 1).Select(x => x.Key);

            if (ScalpTypesResult.Count() > 1)
            {
                scalpType = string.Join(",", ScalpTypesResult);
            }
            else
            {
                scalpType = string.Join("", ScalpTypesResult);
                //foreach (KeyValuePair<string, int> item in ScalpTypes)
                //{
                //    if (item.Value == 1)
                //    {
                //        scalpType = item.Key;
                //    }
                //}
            }

            return scalpType;
        }

        /// <summary>
        /// 테이블 명을 매개변수로 관련 테이블의 데이터를 가져오기 위한 함수입니다.
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public Hair_ScalpType_Entity LoadUserScalpTypeBaseData(string tableName)
        {
            DataTable userData = null;

            switch(tableName)
            {
                case ScalpTypeTableList.Center:
                    userData = this._scalpsc.ScalpType_Center(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
                case ScalpTypeTableList.Back:
                    userData = this._scalpsc.ScalpType_Back(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
                case ScalpTypeTableList.FrontCenter:
                    userData = this._scalpsc.ScalpType_FrontCenter(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
                case ScalpTypeTableList.FrontHairLine:
                    userData = this._scalpsc.ScalpType_FrontHairLine(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
                case ScalpTypeTableList.LeftHairLine:
                    userData = this._scalpsc.ScalpType_LeftHairLine(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
                case ScalpTypeTableList.RightHairLine:
                    userData = this._scalpsc.ScalpType_RightHairLine(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
            }

            Hair_ScalpType_Entity userScalpTypeBaseInfo;

            if (userData != null)
            {
                userScalpTypeBaseInfo = new Hair_ScalpType_Entity()
                {
                    //surveyNo = Int32.Parse(userData.Rows[0][0].ToString()),
                    //userkey = Int32.Parse(userData.Rows[0][1].ToString()),
                    //PhoneNumber = userData.Rows[0][2].ToString(),
                    //Name = userData.Rows[0][3].ToString(),
                    //Age = userData.Rows[0][4].ToString() == ""? 0 : Int32.Parse(userData.Rows[0][4].ToString()),
                    //Birthday = userData.Rows[0][5].ToString(),
                    //Gender = userData.Rows[0][6].ToString(),
                    //ScalpType_Nor = Int32.Parse(userData.Rows[0][7].ToString()),
                    //ScalpType_Oily = Int32.Parse(userData.Rows[0][8].ToString()),
                    //ScalpType_Ato = Int32.Parse(userData.Rows[0][9].ToString()),
                    //ScalpType_Trb = Int32.Parse(userData.Rows[0][10].ToString()),
                    //ScalpType_Dry = Int32.Parse(userData.Rows[0][11].ToString()),
                    //ScalpType_Sen = Int32.Parse(userData.Rows[0][12].ToString()),
                    //ScalpType_Seb = Int32.Parse(userData.Rows[0][13].ToString()),
                    //ScalpType_Ddan = Int32.Parse(userData.Rows[0][14].ToString()),
                    //ScalpType_Odan = Int32.Parse(userData.Rows[0][15].ToString()),
                    //ScalpType_Unknown = Int32.Parse(userData.Rows[0][16].ToString()),
                    //Thickness = float.Parse(userData.Rows[0][17].ToString()),
                    //Density = float.Parse(userData.Rows[0][18].ToString()),
                    //Thickness_mean = float.Parse(userData.Rows[0][19].ToString()),
                    //Density_mean = float.Parse(userData.Rows[0][20].ToString()),
                    //create_dt = String.IsNullOrEmpty(userData.Rows[0][21].ToString()) ? DateTime.Today : Convert.ToDateTime(userData.Rows[0][21].ToString()), // null 관련 에러 발생. 임시로 오늘 날짜로 할당
                    //update_dt = String.IsNullOrEmpty(userData.Rows[0][22].ToString()) ? DateTime.Today : Convert.ToDateTime(userData.Rows[0][22].ToString()),

                    surveyNo = Int32.Parse(userData.Rows[0][0].ToString()),
                    userkey = Int32.Parse(userData.Rows[0][1].ToString()),
                    PhoneNumber = userData.Rows[0][2].ToString(),
                    Name = userData.Rows[0][3].ToString(),
                    Age = userData.Rows[0][4].ToString() == "" ? 0 : Int32.Parse(userData.Rows[0][4].ToString()),
                    Birthday = userData.Rows[0][5].ToString(),
                    Gender = userData.Rows[0][6].ToString(),
                    ScalpType_Nor = StringToIntConvert(userData.Rows[0][7].ToString()),
                    ScalpType_Oily = StringToIntConvert(userData.Rows[0][8].ToString()),
                    ScalpType_Ato = StringToIntConvert(userData.Rows[0][9].ToString()),
                    ScalpType_Trb = StringToIntConvert(userData.Rows[0][10].ToString()),
                    ScalpType_Dry = StringToIntConvert(userData.Rows[0][11].ToString()),
                    ScalpType_Sen = StringToIntConvert(userData.Rows[0][12].ToString()),
                    ScalpType_Seb = StringToIntConvert(userData.Rows[0][13].ToString()),
                    ScalpType_Ddan = StringToIntConvert(userData.Rows[0][14].ToString()),
                    ScalpType_Odan = StringToIntConvert(userData.Rows[0][15].ToString()),
                    ScalpType_Unknown = StringToIntConvert(userData.Rows[0][16].ToString()),
                    Thickness = float.Parse(userData.Rows[0][17].ToString()),
                    Density = float.Parse(userData.Rows[0][18].ToString()),
                    Thickness_mean = float.Parse(userData.Rows[0][19].ToString()),
                    Density_mean = float.Parse(userData.Rows[0][20].ToString()),
                    create_dt = String.IsNullOrEmpty(userData.Rows[0][21].ToString()) ? DateTime.Today : Convert.ToDateTime(userData.Rows[0][21].ToString()), // null 관련 에러 발생. 임시로 오늘 날짜로 할당
                    update_dt = String.IsNullOrEmpty(userData.Rows[0][22].ToString()) ? DateTime.Today : Convert.ToDateTime(userData.Rows[0][22].ToString()),


                };
            }
            else
            {
                throw new Exception("Could not find User Data...!");
            }

            return userScalpTypeBaseInfo;
        }

        private int StringToIntConvert(string data) {

            if (data == "")
            {
                return 0;
            }
            else 
            {
                return Int32.Parse(data);
            }
        }

    }
}
