﻿using IOPE_LAB.Contents.Scalp.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IOPE_LAB.Contents.Scalp.Utils;

namespace IOPE_LAB.Contents.Scalp.ViewModels
{
    /// <summary>
    /// HAIR LOSS TYPE 유형 버튼 클릭 시 나타나는 팝업창과 관련된 ViewModel입니다.
    /// </summary>
    internal class WindowOpinionViewModel
    {
        private string _hairBasicType;
        private string _hairLossTypeCenter;
        private string _hairLossTypeFrontCenter;
        private string _finalType;
        private string _gender;
        

        public string HairBasicType 
        { 
            get { return _hairBasicType; }
            set { _hairBasicType = value; }
        }
        public string HairLossTypeCenter 
        {
            get { return _hairLossTypeCenter; }
            set { _hairLossTypeCenter = value; }
        }
        public string HairLossTypeFrontCenter 
        {
            get { return _hairLossTypeFrontCenter; }
            set { _hairLossTypeFrontCenter = value; }
        }

        public string FinalType
        {
            get { return _finalType; }
            set { _finalType = value; }
        }

        public string Gender 
        { 
            get { return _gender; }
            set { _gender = value; }
        }



        public WindowOpinionViewModel()
        {
            this._hairBasicType = DBManager.GetHairLossBasicType();
            this._hairLossTypeCenter = DBManager.GetHairLossCenterType();
            this._hairLossTypeFrontCenter = DBManager.GetHairLossFrontCenterType();

            this._gender = DBManager.GetGender();

            this._finalType = GetFinalType();
        }

        /// <summary>
        /// 고객의 최종 타입을 반환합니다.
        /// </summary>
        /// <param></param>
        /// <returns>string</returns>
        public string GetFinalType()
        {
            int type = DBManager.GetHairLossTypeList().Count;
            string str = "";

            switch (type)
            {
                case 1:
                    if(this._hairBasicType != "")
                    {
                        str = $"BasicType({this._hairBasicType})";
                    }
                    else if (this._hairLossTypeCenter != "")
                    {
                        str = $"Specific Type({this._hairLossTypeCenter})";
                    }
                    else
                    {
                        str = $"Specific Type({this._hairLossTypeFrontCenter})";
                    }
                    break;
                case 2:
                    if (this._hairLossTypeCenter != "")
                    {
                        str = $"BasicType({this._hairBasicType})+Specific Type({this._hairLossTypeCenter})";
                    }
                    else
                    {
                        str = $"BasicType({this._hairBasicType})+Specific Type({this._hairLossTypeFrontCenter})";
                    }
                    break;
                case 3:
                    str = $"BasicType({this._hairBasicType})+Specific Type({this._hairLossTypeCenter})+Specific Type({this._hairLossTypeFrontCenter})";
                    break;
            }

            return str;
        }
    }
}
