﻿using IOPE_LAB.Contents.Scalp.Utils;
using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using IOPE_LAB_CONTROLS.Entity;
using System.Windows.Media.Imaging;
using System.IO;




namespace IOPE_LAB.Contents.Scalp.ViewModels
{
    /// <summary>
    /// 프린트 버튼을 눌렀을 때 나타는 결과 팝업창 관련 뷰모델입니다.
    /// </summary>
    public class ScalpResultViewModel : ViewModelBase
    {
        private string _customerName;

        // 고객 탈모 타입
        private string _basicType;
        private string _hairLossTypeCenter;
        private string _hairLossTypeFrontCenter;

        // 고객 모발 상태 - Radial Graph 
        private int _hairConditionRoot;
        private int _hairConditionMid;
        private int _hairConditionTips;
        private string _hairConditionRootText;
        private string _hairConditionMidText;
        private string _hairConditionTipsText;

        private string _hairCareTips;

        public string BasicType
        {
            get { return _basicType; }
            set { _basicType = value; }
        }
        public string HairLossTypeCenter
        {
            get { return _hairLossTypeCenter; }
            set { _hairLossTypeCenter = value; }
        }
        public string HairLossTypeFrontCenter
        {
            get { return _hairLossTypeFrontCenter; }
            set { _hairLossTypeFrontCenter = value; }
        }
        public int HairConditionRoot
        {
            get { return _hairConditionRoot; }
            set { _hairConditionRoot = value; }
        }
        public int HairConditionMid
        {
            get { return _hairConditionMid; }
            set { _hairConditionMid = value; }
        }
        public int HairConditionTips
        {
            get { return _hairConditionTips; }
            set { _hairConditionTips = value; }
        }
        public string HairConditionRootText
        {
            get { return _hairConditionRootText; }
            set { _hairConditionRootText = value; }
        }
        public string HairConditionMidText
        {
            get { return _hairConditionMidText; }
            set { _hairConditionMidText = value; }
        }
        public string HairConditionTipsText
        {
            get { return _hairConditionTipsText; }
            set { _hairConditionTipsText = value; }
        }

        public string HairCareTips
        {
            get { return _hairCareTips; }
            set { _hairCareTips = value; }
        }

        public string CustomerName
        {
            get { return _customerName; }
            set { _customerName = value; }
        }


        private string _c_Date;
        public string C_Date
        {
            get { return _c_Date; }
            set
            {
                if (_c_Date != value)
                {
                    _c_Date = value;
                }
            }
        }

        private int _C_Visit_Number;
        public int C_Visit_Number
        {
            get { return _C_Visit_Number; }
            set
            {
                if (_C_Visit_Number != value)
                {
                    _C_Visit_Number = value;
                }
            }

        }
        // 고객 이름 (client name)
        private string _c_Name;
        public string C_Name
        {
            get { return _c_Name; }
            set
            {
                if (_c_Name != value)
                {
                    _c_Name = value;
                }
            }
        }


        //****** 230913 HairLineDentistyAndThickness 추가1 start

        private ScalpService.ScalpServiceClient _scalpsc;

        private Hair_ScalpType_Entity _center;
        private Hair_ScalpType_Entity _back;
        private Hair_ScalpType_Entity _frontCenter;
        private Hair_ScalpType_Entity _frontHairLine;
        private Hair_ScalpType_Entity _leftHairLine;
        private Hair_ScalpType_Entity _rightHairLine;

        public Hair_ScalpType_Entity Center
        {
            get { return _center; }
            set { _center = value; }
        }
        public Hair_ScalpType_Entity Back
        {
            get { return _back; }
            set { _back = value; }
        }
        public Hair_ScalpType_Entity FrontCenter
        {
            get { return _frontCenter; }
            set { _frontCenter = value; }
        }
        public Hair_ScalpType_Entity FrontHairLine
        {
            get { return _frontHairLine; }
            set { _frontHairLine = value; }
        }
        public Hair_ScalpType_Entity LeftHairLine
        {
            get { return _leftHairLine; }
            set { _leftHairLine = value; }
        }
        public Hair_ScalpType_Entity RightHairLine
        {
            get { return _rightHairLine; }
            set { _rightHairLine = value; }
        }

        //****** 230913 HairLineDentistyAndThickness 추가1 end





        public ScalpResultViewModel()
        {
            this._customerName = DBManager.GetCustomerName();

            this._basicType = DBManager.GetHairLossBasicType();
            this._hairLossTypeCenter = DBManager.GetHairLossCenterType();
            this._hairLossTypeFrontCenter = DBManager.GetHairLossFrontCenterType();

            this._hairConditionRoot = DBManager.GetRootHairCondition();
            this._hairConditionMid = DBManager.GetMidHairCondition();
            this._hairConditionTips = DBManager.GetTipsHairCondition();

            this._hairConditionRootText = intToString(this._hairConditionRoot);
            this._hairConditionMidText = intToString(this._hairConditionMid);
            this._hairConditionTipsText = intToString(this._hairConditionTips);

            if (LoginSession.Selected_C_ResultPageData_M != null && LoginSession.Selected_C_ResultPageData_M.specialtip_memo != null)
            {
                //&& LoginSession.Selected_C_ResultPageData.Length > 0
                this._hairCareTips = LoginSession.Selected_C_ResultPageData_M.specialtip_memo;
            }


            this._scalpsc = new ScalpService.ScalpServiceClient();

            this._center = LoadUserScalpTypeBaseData(ScalpTypeTableList.Center);
            this._back = LoadUserScalpTypeBaseData(ScalpTypeTableList.Back);
            this._frontCenter = LoadUserScalpTypeBaseData(ScalpTypeTableList.FrontCenter);
            this._frontHairLine = LoadUserScalpTypeBaseData(ScalpTypeTableList.FrontHairLine);
            this._leftHairLine = LoadUserScalpTypeBaseData(ScalpTypeTableList.LeftHairLine);
            this._rightHairLine = LoadUserScalpTypeBaseData(ScalpTypeTableList.RightHairLine);



        }

        /// <summary>
        /// Hair Condition의 value에 따라 Text를 반환합니다. 0 - 건강모 / 1 - 약손상모 / 2 - 손상모 / 3 - 극손상모 / 4 - 열모/지모
        /// </summary>
        /// <param name="value">검색을 시작할 컨트롤</param>
        /// <returns>string</returns>
        public string intToString(int value)
        {
            string text = string.Empty;
            switch (value)
            {
                case 0:
                    text = "건강모";
                    break;
                case 1:
                    text = "약손상모";
                    break;
                case 2:
                    text = "손상모";
                    break;
                case 3:
                    text = "극손상모";
                    break;
                case 4:
                    text = "열모/지모";
                    break;
            }

            return text;
        }

        public Hair_ScalpType_Entity LoadUserScalpTypeBaseData(string tableName)
        {
            DataTable userData = null;

            switch (tableName)
            {
                case ScalpTypeTableList.Center:
                    userData = this._scalpsc.ScalpType_Center(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
                case ScalpTypeTableList.Back:
                    userData = this._scalpsc.ScalpType_Back(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
                case ScalpTypeTableList.FrontCenter:
                    userData = this._scalpsc.ScalpType_FrontCenter(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
                case ScalpTypeTableList.FrontHairLine:
                    userData = this._scalpsc.ScalpType_FrontHairLine(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
                case ScalpTypeTableList.LeftHairLine:
                    userData = this._scalpsc.ScalpType_LeftHairLine(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
                case ScalpTypeTableList.RightHairLine:
                    userData = this._scalpsc.ScalpType_RightHairLine(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
                    break;
            }

            Hair_ScalpType_Entity userScalpTypeBaseInfo;

            if (userData != null)
            {
                userScalpTypeBaseInfo = new Hair_ScalpType_Entity()
                {
                    //surveyNo = Int32.Parse(userData.Rows[0][0].ToString()),
                    //userkey = Int32.Parse(userData.Rows[0][1].ToString()),
                    //PhoneNumber = userData.Rows[0][2].ToString(),
                    //Name = userData.Rows[0][3].ToString(),
                    //Age = userData.Rows[0][4].ToString() == ""? 0 : Int32.Parse(userData.Rows[0][4].ToString()),
                    //Birthday = userData.Rows[0][5].ToString(),
                    //Gender = userData.Rows[0][6].ToString(),
                    //ScalpType_Nor = Int32.Parse(userData.Rows[0][7].ToString()),
                    //ScalpType_Oily = Int32.Parse(userData.Rows[0][8].ToString()),
                    //ScalpType_Ato = Int32.Parse(userData.Rows[0][9].ToString()),
                    //ScalpType_Trb = Int32.Parse(userData.Rows[0][10].ToString()),
                    //ScalpType_Dry = Int32.Parse(userData.Rows[0][11].ToString()),
                    //ScalpType_Sen = Int32.Parse(userData.Rows[0][12].ToString()),
                    //ScalpType_Seb = Int32.Parse(userData.Rows[0][13].ToString()),
                    //ScalpType_Ddan = Int32.Parse(userData.Rows[0][14].ToString()),
                    //ScalpType_Odan = Int32.Parse(userData.Rows[0][15].ToString()),
                    //ScalpType_Unknown = Int32.Parse(userData.Rows[0][16].ToString()),
                    //Thickness = float.Parse(userData.Rows[0][17].ToString()),
                    //Density = float.Parse(userData.Rows[0][18].ToString()),
                    //Thickness_mean = float.Parse(userData.Rows[0][19].ToString()),
                    //Density_mean = float.Parse(userData.Rows[0][20].ToString()),
                    //create_dt = String.IsNullOrEmpty(userData.Rows[0][21].ToString()) ? DateTime.Today : Convert.ToDateTime(userData.Rows[0][21].ToString()), // null 관련 에러 발생. 임시로 오늘 날짜로 할당
                    //update_dt = String.IsNullOrEmpty(userData.Rows[0][22].ToString()) ? DateTime.Today : Convert.ToDateTime(userData.Rows[0][22].ToString()),

                    surveyNo = Int32.Parse(userData.Rows[0][0].ToString()),
                    userkey = Int32.Parse(userData.Rows[0][1].ToString()),
                    PhoneNumber = userData.Rows[0][2].ToString(),
                    Name = userData.Rows[0][3].ToString(),
                    Age = userData.Rows[0][4].ToString() == "" ? 0 : Int32.Parse(userData.Rows[0][4].ToString()),
                    Birthday = userData.Rows[0][5].ToString(),
                    Gender = userData.Rows[0][6].ToString(),

                    ScalpType_Nor = StringToIntConvert(userData.Rows[0][7].ToString()),
                    ScalpType_Oily = StringToIntConvert(userData.Rows[0][8].ToString()),
                    ScalpType_Ato = StringToIntConvert(userData.Rows[0][9].ToString()),
                    ScalpType_Trb = StringToIntConvert(userData.Rows[0][10].ToString()),
                    ScalpType_Dry = StringToIntConvert(userData.Rows[0][11].ToString()),
                    ScalpType_Sen = StringToIntConvert(userData.Rows[0][12].ToString()),
                    ScalpType_Seb = StringToIntConvert(userData.Rows[0][13].ToString()),
                    ScalpType_Ddan = StringToIntConvert(userData.Rows[0][14].ToString()),
                    ScalpType_Odan = StringToIntConvert(userData.Rows[0][15].ToString()),
                    ScalpType_Unknown = StringToIntConvert(userData.Rows[0][16].ToString()),

                    Thickness = float.Parse(userData.Rows[0][17].ToString()),

                    Thickness_multi = float.Parse(userData.Rows[0][17].ToString())*1000,



                    Density = float.Parse(userData.Rows[0][18].ToString()),
                    Thickness_mean = float.Parse(userData.Rows[0][19].ToString()),
                    Density_mean = float.Parse(userData.Rows[0][20].ToString()),
                    create_dt = String.IsNullOrEmpty(userData.Rows[0][21].ToString()) ? DateTime.Today : Convert.ToDateTime(userData.Rows[0][21].ToString()), // null 관련 에러 발생. 임시로 오늘 날짜로 할당
                    update_dt = String.IsNullOrEmpty(userData.Rows[0][22].ToString()) ? DateTime.Today : Convert.ToDateTime(userData.Rows[0][22].ToString()),


                };
            }
            else
            {
                throw new Exception("Could not find User Data...!");
            }

            return userScalpTypeBaseInfo;
        }


        private int StringToIntConvert(string data)
        {

            if (data == "")
            {
                return 0;
            }
            else
            {
                return Int32.Parse(data);
            }
        }



    }
}
