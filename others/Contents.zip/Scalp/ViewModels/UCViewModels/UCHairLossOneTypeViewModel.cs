﻿using IOPE_LAB.Contents.Scalp.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOPE_LAB.Contents.Scalp.ViewModels.UCViewModels
{
    public class UCHairLossOneTypeViewModel: ViewModelBase
    {
        private string _basicType;
        private string _yourLossType;

        public string BasicType 
        { 
            get { return _basicType; }
            set { _basicType = value; }
        }
        public string YourLossType 
        { 
            get { return _yourLossType; }
            set { _yourLossType = value; }
        }

        public UCHairLossOneTypeViewModel()
        {
            List<string > lossOneType = DBManager.GetHairLossTypeList();
            this._basicType = lossOneType[0];
            this._yourLossType = string.Format("고객님의 탈모 유형은 {0}형입니다.", this._basicType);
        }
    }
}
