﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB.Contents.Scalp.Utils;
using IOPE_LAB.Contents.Scalp.UserControls;
using System.Windows.Controls;

namespace IOPE_LAB.Contents.Scalp.ViewModels
{
    public class ScalpMainViewModel: ViewModelBase
    {

        private string _customerName;
        private UserControl _UCHairLossType;

        public string CustomerName {
            get { return _customerName; } 
            set { _customerName = value; }  
         }

        public UserControl UCHairLossType
        {
            get { return _UCHairLossType; }
            set { _UCHairLossType = value; }
        }

        public ScalpMainViewModel()
        {
            this._customerName = DBManager.GetCustomerName() + " 님";
            LoadUserControlHairLossType();
        }

        public void LoadUserControlHairLossType()
        {
            int type = DBManager.GetHairLossTypeList().Count;

            switch (type)
            {
                case 1:
                    this._UCHairLossType = new UCHairLossOneType();
                    break;
                case 2:
                    this._UCHairLossType = new UserControlHairLossType();
                    break;
                case 3:
                    this._UCHairLossType = new UCHairLossThreeTypes();
                    break;
            }
        }
    }
}
