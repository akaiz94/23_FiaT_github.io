﻿using IOPE_LAB.Contents.Result;
using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Scalp
{
    /// <summary>
    /// Popup_InkCanvas.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Scalp_InkCanvas : Window
    {
        int default_brush_size = 2;

        //public ResultPage_Data resultpage_data;
        public ScalpResult_Data scalpResult_Data;

        bool viewMode = true;

        public Scalp_InkCanvas(ScalpResult_Data _scalpResult_Data)
        {
            InitializeComponent();

            scalpResult_Data = _scalpResult_Data;

            this.Loaded += new RoutedEventHandler(InkCanvasPopup_Loaded);
            btnClose.Click += new RoutedEventHandler(btnClose_Click);
            border_top_background.MouseLeftButtonDown += new MouseButtonEventHandler(border_top_background_MouseLeftButtonDown);
            this.KeyDown += new KeyEventHandler(InkCanvasPopup_KeyDown);
            this.MouseWheel += new MouseWheelEventHandler(InkCanvasPopup_MouseWheel);

            this.btn_all_remove.Click += new RoutedEventHandler(btn_Click);
            this.btn_eraser.Click += new RoutedEventHandler(btn_Click);
            this.btn_ink.Click += new RoutedEventHandler(btn_Click);
            this.btn_select.Click += new RoutedEventHandler(btn_Click);
        }

        //public Scalp_InkCanvas(ResultPage_Data _resultpage_data, bool _viewMode)
        //{
        //    InitializeComponent();

        //    resultpage_data = _resultpage_data;
        //    viewMode = _viewMode;

        //    this.Loaded += new RoutedEventHandler(InkCanvasPopup_Loaded);
        //    btnClose.Click += new RoutedEventHandler(btnClose_Click);
        //    border_top_background.MouseLeftButtonDown += new MouseButtonEventHandler(border_top_background_MouseLeftButtonDown);
        //    this.KeyDown += new KeyEventHandler(InkCanvasPopup_KeyDown);
        //    this.MouseWheel += new MouseWheelEventHandler(InkCanvasPopup_MouseWheel);

        //    this.btn_all_remove.Click += new RoutedEventHandler(btn_Click);
        //    this.btn_eraser.Click += new RoutedEventHandler(btn_Click);
        //    this.btn_ink.Click += new RoutedEventHandler(btn_Click);
        //    this.btn_select.Click += new RoutedEventHandler(btn_Click);
        //}

        void btn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;

            switch (btn.Name)
            {
                case "btn_all_remove":
                    if (ink_img1.Strokes.Count > 0)
                    {
                        ink_img1.Strokes.Remove(ink_img1.Strokes[ink_img1.Strokes.Count - 1]);
                    }
                    break;
                case "btn_eraser":
                    ink_img1.EditingMode = InkCanvasEditingMode.EraseByPoint;
                    break;
                case "btn_ink":
                    System.Windows.Forms.ColorDialog colordialog = new System.Windows.Forms.ColorDialog();
                    if (colordialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        ink_img1.DefaultDrawingAttributes.Color = System.Windows.Media.Color.FromArgb(colordialog.Color.A, colordialog.Color.R, colordialog.Color.G, colordialog.Color.B);
                    }
                    ink_img1.EditingMode = InkCanvasEditingMode.Ink;

                    ink_img1.ForceCursor = true;
                    ink_img1.Cursor = Cursors.Pen;
                    break;
                case "btn_select":
                    ink_img1.EditingMode = InkCanvasEditingMode.Select;
                    break;
            }
        }

        void InkCanvasPopup_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0)
            {
                if (default_brush_size > 2)
                    default_brush_size -= 1;
            }
            else
            {
                if (default_brush_size < 100)
                    default_brush_size += 1;
            }
            ink_img1.DefaultDrawingAttributes.Width = default_brush_size;
            ink_img1.DefaultDrawingAttributes.Height = default_brush_size;
        }

        void InkCanvasPopup_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Up:
                    default_brush_size += 1;
                    break;
                case Key.Down:
                    if (default_brush_size > 2)
                    {
                        default_brush_size -= 1;
                    }
                    break;
            }

            ink_img1.DefaultDrawingAttributes.Width = default_brush_size;
            ink_img1.DefaultDrawingAttributes.Height = default_brush_size;
        }

        void InkCanvasPopup_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                ink_img1.ForceCursor = true;
                ink_img1.Cursor = Cursors.Pen;

                //DrawingAttributes da = new DrawingAttributes();
                ink_img1.DefaultDrawingAttributes.Color = Colors.Black;
                ink_img1.DefaultDrawingAttributes.Width = default_brush_size;
                ink_img1.DefaultDrawingAttributes.Height = default_brush_size;

                if (LoginSession.SelectedMember != null)
                {                  

                    if (scalpResult_Data != null && scalpResult_Data.specialtip_stoke_img != null)
                    {
                        InkCanvasByteToCanvas(ink_img1, scalpResult_Data.specialtip_stoke_img);
                    }

                    if (scalpResult_Data != null && scalpResult_Data.specialtip_memo != string.Empty)
                    {
                        tb_memo.Text = scalpResult_Data.specialtip_memo;
                        scalpResult_Data.specialtip_memo = tb_memo.Text;
                    }

                    if (viewMode == false)
                    {
                        btn_all_remove.IsEnabled = false;
                        btn_eraser.IsEnabled = false;
                        btn_ink.IsEnabled = false;
                        btn_select.IsEnabled = false;
                        ink_img1.IsEnabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        private byte[] GetJpgImage(Grid source, int scale, int quality)
        {
            double actualHeight = source.RenderSize.Height;
            double actualWidth = source.RenderSize.Width;

            double renderHeight = actualHeight * scale;
            double renderWidth = actualWidth * scale;

            RenderTargetBitmap renderTarget = new RenderTargetBitmap((int)renderWidth, (int)renderHeight, 96, 96, PixelFormats.Pbgra32);
            VisualBrush sourceBrush = new VisualBrush(source);

            DrawingVisual drawingVisual = new DrawingVisual();
            DrawingContext drawingContext = drawingVisual.RenderOpen();

            using (drawingContext)
            {
                drawingContext.PushTransform(new ScaleTransform(scale, scale));
                drawingContext.DrawRectangle(sourceBrush, null, new Rect(new Point(0, 0), new Point(actualWidth, actualHeight)));
            }
            renderTarget.Render(drawingVisual);

            JpegBitmapEncoder jpgEncoder = new JpegBitmapEncoder();
            jpgEncoder.QualityLevel = quality;
            jpgEncoder.Frames.Add(BitmapFrame.Create(renderTarget));

            Byte[] _imageArray;

            using (MemoryStream outputStream = new MemoryStream())
            {
                jpgEncoder.Save(outputStream);
                _imageArray = outputStream.ToArray();
            }

            return _imageArray;
        }

        void border_top_background_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        void btnClose_Click(object sender, RoutedEventArgs e)
        {
            scalpResult_Data.specialtip_stoke_img = InkCanvasToByte(ink_img1);
            scalpResult_Data.specialtip_img = GetJpgImage(grid_inkarea, 1, 100);

            //LoginSession.SelectedResult_Rpt.result_img1 = InkCanvasToByte(ink_img1);
            //LoginSession.SelectedResult_Rpt.result_img2 = GetJpgImage(grid_inkarea, 1, 100);
            this.Close();
        }

        private void InkCanvasByteToCanvas(InkCanvas inkcanvas, byte[] _byte)
        {
            if (_byte.Length > 0)
            {
                using (MemoryStream ms = new MemoryStream(_byte))
                {
                    inkcanvas.Strokes = new System.Windows.Ink.StrokeCollection(ms);
                    ms.Close();
                }
            }
        }

        private byte[] InkCanvasToByte(InkCanvas inkcanvas)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                if (inkcanvas.Strokes.Count > 0)
                {
                    inkcanvas.Strokes.Save(ms, true);
                    byte[] unencryptedSignature = ms.ToArray();

                    return unencryptedSignature;
                }
                else
                {
                    return null;
                }
            }
        }

        private void ReadByteArrayFromFile()
        {
            string Chosen_File = "";
            Microsoft.Win32.OpenFileDialog ofd = new Microsoft.Win32.OpenFileDialog();
            ofd.Filter = "All Files (*.*)|*.*";
            ofd.FilterIndex = 1;
            ofd.Multiselect = false;
            bool? userClickedOK = ofd.ShowDialog();
            if (userClickedOK == true)
            {
                Chosen_File = ofd.FileName;
            }
            byte[] bytesFromFile = File.ReadAllBytes(Chosen_File);

        }
    }
}