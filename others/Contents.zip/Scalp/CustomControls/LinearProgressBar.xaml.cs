﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Scalp.CustomControls
{
    /// <summary>
    /// LinearProgressBar.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class LinearProgressBar : UserControl
    {
        public LinearProgressBar()
        {
            InitializeComponent();
        }
        public double ProgressValue
        {
            get { return (double)GetValue(ProgressValueProperty); }
            set { SetValue(ProgressValueProperty, value); }
        }

        public static readonly DependencyProperty ProgressValueProperty =
            DependencyProperty.Register("ProgressValue", typeof(double), typeof(LinearProgressBar), new PropertyMetadata(null));

        public double Mean
        {
            get { return (double)GetValue(MeanProperty); }
            set { SetValue(MeanProperty, value); }
        }

        public static readonly DependencyProperty MeanProperty =
            DependencyProperty.Register("Mean", typeof(double), typeof(LinearProgressBar), new PropertyMetadata(null));

    }
}
