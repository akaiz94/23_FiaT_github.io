﻿using IOPE_LAB.Contents.Scalp.ViewModels;
using IOPE_LAB.Common;
using IOPE_LAB.Popup;
using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using IOPE_LAB.Contents.Result;
using IOPE_LAB_CONTROLS.Entity;
using IOPE_LAB.UserControls;
using IOPE_LAB_CONTROLS.Entity.MarkVu;
using IOPE_LAB.Contents.Scalp.Utils;
using System.Data;

namespace IOPE_LAB.Contents.Scalp
{
    /// <summary>
    /// ScalpMain.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ScalpMain : UserControl
    {

        //ResultPage_Data rpd;
        ScalpResult_Data scalpResult_Data = new ScalpResult_Data();

        public ResultPage_Data_Entity rpde = new ResultPage_Data_Entity();

        public ScalpMain()
        {
            try
            {
                InitializeComponent();

                DBManager.intitallzeManger();
                this.Loaded += ScalpPage_Loaded;
                this.DataContext = new ScalpMainViewModel();
                this.btn_Print.Click += Print_Btn;
                this.btn_Submit.Click += Btn_Submit_Click;
                this.grid_stoke.MouseLeftButtonDown += Grid_stoke_MouseLeftButtonDown;

                LoginSession.SelectedMember.div = "scalp";



                MemberService.MemberServiceClient msc = new MemberService.MemberServiceClient();
                DataTable dt = msc.visitCount("IC", LoginSession.SelectedMember.name, LoginSession.SelectedMember.birthdate, LoginSession.SelectedMember.PCCD);

                if (dt.Rows.Count > 0 && LoginSession.Selected_C_ResultPageData_M != null)
                {
                    // 연구원명, 측정 날짜
                    if (LoginSession.Selected_C_ResultPageData_M.manager_value != null && LoginSession.SelectedMember != null)
                    {

                        string visit = dt.Rows.Count > 0 ? dt.Rows[0]["cnt"].ToString() : "0";
                        string searchDate = LoginSession.SelectedMember.rsvn_date.ToString("yyyy-MM-dd").Replace("-", "/");

                        string CustomName = LoginSession.SelectedMember.name;
                        this.C_Name.Text = $"{CustomName} 님";// No1.고객 이름

                        this.txt_result_date.Text = $"측정일자: {searchDate}";
                        this.txt_result_count.Text = $"방문회차: {visit} 회차";
                        My_Skin1.Text = "두피 측정 결과보기";
                        this.txt_result_title.Text += $"HAIR&SCALP SOLUTION   {LoginSession.Selected_C_ResultPageData_M.manager_value}";
                        this.result_rectangle.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        if (LoginSession.ProgramCourseflg == "I")
                        {
                            this.txt_result_date.Text = "MY SKIN DNA PROGRAM";
                        }
                        else { 
                        
                            this.txt_result_date.Text = "SCALP PROGRAM";
                        }
                    }
                }

                else
                {
                    string visit = dt.Rows.Count > 0 ? dt.Rows[0]["cnt"].ToString() : "0";
                    string searchDate = LoginSession.SelectedMember.rsvn_date.ToString("yyyy-MM-dd").Replace("-", "/");

                    string CustomName = LoginSession.SelectedMember.name;
                    this.C_Name.Text = $"{CustomName} 님";// No1.고객 이름

                    this.txt_result_date.Text = $"측정일자: {searchDate}";
                    this.txt_result_count.Text = $"방문회차: 1회차";
                    My_Skin1.Text = "두피 측정 결과보기";
                    this.txt_result_title.Text += $"HAIR&SCALP SOLUTION   ";
                    //this.txt_result_title.Text += $"HAIR&SCALP SOLUTION   {LoginSession.Selected_C_ResultPageData_M.manager_value}";

                    this.result_rectangle.Visibility = Visibility.Visible;
                }
               
            }
            catch(Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.LogRecord($"결과페이지 로딩중 오류 발생 >>>{ex}");
            }

        }
        private void Load_SpecialTip(object sender, MouseButtonEventArgs e)
        {
            Scalp_InkCanvasOpen();
        }

        private void Print_Btn(object sender, RoutedEventArgs e)
        {

            Window_ScalpResult windowScalpReulst = new Window_ScalpResult(scalpResult_Data);
            windowScalpReulst.ShowDialog();
        }



        private void ScalpPage_Loaded(object sender, RoutedEventArgs e)
        {
            try {

                if (LoginSession.SelectedMember != null && LoginSession.Selected_C_ResultPageData_M != null)
                {
                    //rpd.specialtip_img = LoginSession.Selected_C_ResultPageData_M.specialtip_img;
                    //rpd.specialtip_stoke_img = LoginSession.Selected_C_ResultPageData_M.specialtip_stoke_img;
                    //rpd.specialtip_memo = LoginSession.Selected_C_ResultPageData_M.specialtip_memo;
                    rpde.specialtip_img = scalpResult_Data.specialtip_img = LoginSession.Selected_C_ResultPageData_M.specialtip_img;
                    rpde.specialtip_stoke_img = scalpResult_Data.specialtip_stoke_img = LoginSession.Selected_C_ResultPageData_M.specialtip_stoke_img;
                    rpde.specialtip_memo = scalpResult_Data.specialtip_memo = LoginSession.Selected_C_ResultPageData_M.specialtip_memo;
                    UpdateInkCanvasBindArea();
                }

             }

            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.LogRecord($"{LoginSession.SelectedMember.name}님 측정 시 결과페이지 에러 내용: {ex.Message}");
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }
        }

        ////SPECIAL TIP
        private void Scalp_InkCanvasOpen()
        {
            Scalp_InkCanvas scalp_InkCanvas = new Scalp_InkCanvas(scalpResult_Data);

            scalp_InkCanvas.ShowDialog();
            rpde.specialtip_img = scalpResult_Data.specialtip_img = scalp_InkCanvas.scalpResult_Data.specialtip_img;
            rpde.specialtip_stoke_img = scalpResult_Data.specialtip_stoke_img = scalp_InkCanvas.scalpResult_Data.specialtip_stoke_img;
            rpde.specialtip_memo = scalpResult_Data.specialtip_memo = scalp_InkCanvas.tb_memo.Text;

            //if (LoginSession.Selected_C_ResultPageData_M == null)
            //{
            //    LoginSession.Selected_C_ResultPageData_M.specialtip_memo = rpde.specialtip_memo;
            //}
            //로그 저장
            Common.CommonBiz.LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}님 메모 CLOSE: {scalp_InkCanvas.tb_memo.Text}");

            UpdateInkCanvasBindArea();
        }

        public void UpdateInkCanvasBindArea()
        {
            if (scalpResult_Data != null && scalpResult_Data.specialtip_img != null && scalpResult_Data.specialtip_img.Length > 0)
            {
                grid_inkarea.Visibility = System.Windows.Visibility.Collapsed;
                grid_stoke.Visibility = System.Windows.Visibility.Visible;
                //img_stoke.Source = CommonBiz.ConvertBytesToBitmap(scalpResult_Data.specialtip_img);
                img_stoke.ImageSource = CommonBiz.ConvertBytesToBitmap(scalpResult_Data.specialtip_img);
            }
            else
            {
                grid_inkarea.Visibility = System.Windows.Visibility.Visible;
                grid_stoke.Visibility = System.Windows.Visibility.Collapsed;
            }
        }

        private void Grid_stoke_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Scalp_InkCanvasOpen();
        }

        private void Btn_Submit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (LoginSession.AdminContentFlag != true)
                {
                    rpde.userKey = LoginSession.SelectedSurvey_M.userkey;
                    rpde.surveyNo = LoginSession.SelectedMember.surveyNo;
                    rpde.surveyDate = LoginSession.SelectedSurvey_M.surveyDate;
                    rpde.name = LoginSession.SelectedMember.name;

                    Popup.Popup_ResultSaveManager prs = new Popup.Popup_ResultSaveManager(rpde);

                    prs.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                    prs.ShowDialog();
                }
                else
                {
                    Common.CommonMessageBox.ShowAlertMessage("관리자 기능 사용중엔 저장기능을 사용 할 수 없습니다.");
                }
            }
            catch (Exception ex)
            {
                Common.CommonBiz.LogRecord($"Btn_Submit_Click 중 에러: {ex.Message}");
            }
        }

        }

    public class ScalpResult_Data
    {
        public byte[] specialtip_img = new byte[0];
        public byte[] specialtip_stoke_img = new byte[0];
        public string specialtip_memo = string.Empty;

        public C_Survey survey { get; set; }

    }
}
