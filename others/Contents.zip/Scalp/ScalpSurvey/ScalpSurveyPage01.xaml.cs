﻿using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Scalp.ScalpSurvey
{
    /// <summary>
    /// ScaplSurveyPage01.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ScalpSurveyPage01 : UserControl
    {
        public ScalpSurveyPage01()
        {
            InitializeComponent();

            this.Loaded += ScalpSurveyPage01_Loaded;

            foreach (CheckBox cb in grid_Q02_1_RadioList.Children) { cb.Checked += new RoutedEventHandler(cb_Checked); }
            foreach (RadioButton rdo in grid_Q02_2_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_3_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_4_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_5_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_6_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_7_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_8_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
        }

        private void ScalpSurveyPage01_Loaded(object sender, RoutedEventArgs e)
        {
            SetData();
        }

        private void SetData()
        {
            if (LoginSession.SelectedSurvey_M != null)
            {
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S1_1) != true)
                    SetCheckBox(cb_Q01, LoginSession.SelectedSurvey_M.S1_1);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S1_2) != true)
                    SetCheckBox(cb_Q02, LoginSession.SelectedSurvey_M.S1_2);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S1_3) != true)
                    SetCheckBox(cb_Q03, LoginSession.SelectedSurvey_M.S1_3);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S1_4) != true)
                    SetCheckBox(cb_Q04, LoginSession.SelectedSurvey_M.S1_4);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S1_5) != true)
                    SetCheckBox(cb_Q05, LoginSession.SelectedSurvey_M.S1_5);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S1_6) != true)
                    SetCheckBox(cb_Q06, LoginSession.SelectedSurvey_M.S1_6);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S1_7) != true)
                    SetCheckBox(cb_Q07, LoginSession.SelectedSurvey_M.S1_7);
               


                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S1_First) != true)
                    tb_first.Text = LoginSession.SelectedSurvey_M.S1_First;
                //if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_Second) != true)
                //    tb_second.Text = LoginSession.SelectedSurvey.S1_Second;



                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_1_1) != true)
                    SetCheckBox(cb_Q301, LoginSession.SelectedSurvey_M.S2_1_1);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_1_2) != true)
                    SetCheckBox(cb_Q302, LoginSession.SelectedSurvey_M.S2_1_2);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_1_3) != true)
                    SetCheckBox(cb_Q303, LoginSession.SelectedSurvey_M.S2_1_3);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_2) != true)
                    SetRadioCheck(grid_Q02_2_RadioList, LoginSession.SelectedSurvey_M.S2_2);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_3) != true)
                    SetRadioCheck(grid_Q02_3_RadioList, LoginSession.SelectedSurvey_M.S2_3);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_4) != true)
                    SetRadioCheck(grid_Q02_4_RadioList, LoginSession.SelectedSurvey_M.S2_4);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_5) != true)
                    SetRadioCheck(grid_Q02_5_RadioList, LoginSession.SelectedSurvey_M.S2_5);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_6) != true)
                    SetRadioCheck(grid_Q02_6_RadioList, LoginSession.SelectedSurvey_M.S2_6);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_7) != true)
                    SetRadioCheck(grid_Q02_7_RadioList, LoginSession.SelectedSurvey_M.S2_7);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_8) != true)
                    SetRadioCheck(grid_Q02_8_RadioList, LoginSession.SelectedSurvey_M.S2_8);

            }
        }

        void cb_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                CheckBox cb = sender as CheckBox;
                Grid grid = cb.Parent as Grid;

                if (LoginSession.SelectedSurvey != null)
                {
                    switch (grid.Name)
                    {
                        case "grid_Q02_1_RadioList":
                            LoginSession.SelectedSurvey.S2_1 = (grid.Children.IndexOf(cb)).ToString();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }

        }

        private void SetRadioBox(RadioButton radiobox, string str_IsCheckYN)
        {
            if (str_IsCheckYN == "Y")
            {
                radiobox.IsChecked = true;
            }
        }

        private void SetCheckBox(CheckBox checkbox, string str_IsCheckYN)
        {
            if (str_IsCheckYN == "Y")
            {
                checkbox.IsChecked = true;
            }
        }

        private void SetCheckBox1(Grid grid_list, string checkNum)
        {
            try
            {
                int index = 0;

                if (checkNum.Contains("^"))
                {
                    string[] check_num_list = checkNum.Split('^');
                    foreach (string str in check_num_list)
                    {
                        index = int.Parse(str);
                        (grid_list.Children[index] as CheckBox).IsChecked = true;
                    }
                }
                else
                {
                    index = int.Parse(checkNum);
                    (grid_list.Children[index] as CheckBox).IsChecked = true;
                }

            }
            catch (Exception)
            {

            }
        }

        void rdo_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                RadioButton rdo = sender as RadioButton;
                Grid grid = rdo.Parent as Grid;

                if (LoginSession.SelectedSurvey_M != null)
                {
                    switch (grid.Name)
                    {
                        case "grid_Q02_2_RadioList":
                            LoginSession.SelectedSurvey_M.S2_2 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q02_3_RadioList":
                            LoginSession.SelectedSurvey_M.S2_3 = (grid.Children.IndexOf(rdo)).ToString();
                            break;        
                        case "grid_Q03_1_RadioList":
                            LoginSession.SelectedSurvey_M.S2_4 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_2_RadioList":
                            LoginSession.SelectedSurvey_M.S2_5 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_3_RadioList":
                            LoginSession.SelectedSurvey_M.S2_6 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_4_RadioList":
                            LoginSession.SelectedSurvey_M.S2_7 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_5_RadioList":
                            LoginSession.SelectedSurvey_M.S2_8 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }

        }

        private void SetRadioCheck(Grid grid_list, string checkNum)
        {
            try
            {
                int index = int.Parse(checkNum);
                (grid_list.Children[index] as RadioButton).IsChecked = true;
            }
            catch (Exception)
            {

            }
        }

        //변수체크
        public bool GetCustomerInputValidation()
        {
            //고민부위(체크박스)2개 이상 선택
            int check_count = 0;

            if (cb_Q01.IsChecked == true)
                check_count++;
            if (cb_Q02.IsChecked == true)
                check_count++;
            if (cb_Q03.IsChecked == true)
                check_count++;
            if (cb_Q04.IsChecked == true)
                check_count++;
            if (cb_Q05.IsChecked == true)
                check_count++;
            if (cb_Q06.IsChecked == true)
                check_count++;
            if (cb_Q07.IsChecked == true)
                check_count++;
           
            //if (cb_Q09.IsChecked == true)
            //    check_count++;
            //if (cb_Q10.IsChecked == true)
            //    check_count++;
            //if (cb_Q11.IsChecked == true)
            //    check_count++;
            //if (cb_Q12.IsChecked == true)
            //    check_count++;

            if (check_count < 1)
            {
                Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_35);
                cb_Q01.Focus();
                return false;
            }

            //1순위 텍스트 입력
            if (string.IsNullOrWhiteSpace(tb_first.Text) == true)
            {
                Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_13);
                tb_first.Focus();
                return false;
            }


            ////2순위 텍스트 입력
            //if (string.IsNullOrWhiteSpace(tb_second.Text) == true)
            //{
            //    Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_14);
            //    tb_second.Focus();
            //    return false;
            //}

            //2-1번
            //if (GetRadioCheck(grid_Q02_1_RadioList) != true)
            //{ Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str20); (grid_Q02_1_RadioList.Children[0] as RadioButton).Focus(); return false; }
            if (GetCheckBoxCheck(grid_Q02_1_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str20); (grid_Q02_1_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //2-2번
            if (GetRadioCheck(grid_Q02_2_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str21); (grid_Q02_2_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //2-3번
            if (GetRadioCheck(grid_Q02_3_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str22); (grid_Q02_3_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //2-4번
            //if (GetRadioCheck(grid_Q02_4_RadioList) != true)
            //{ Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str23); (grid_Q02_4_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //3-1번
            if (GetRadioCheck(grid_Q02_4_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str23); (grid_Q02_4_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //3-2번
            if (GetRadioCheck(grid_Q02_5_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str24); (grid_Q02_5_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //3-3번
            if (GetRadioCheck(grid_Q02_6_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str25); (grid_Q02_6_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //3-4번
            if (GetRadioCheck(grid_Q02_7_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str26); (grid_Q02_7_RadioList.Children[0] as RadioButton).Focus(); return false; }

            if (GetRadioCheck(grid_Q02_8_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str04); return false; }

            if (LoginSession.SelectedSurvey_M != null)
            {
                //GetCheckString();
                LoginSession.SelectedSurvey_M.S1_1 = cb_Q01.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S1_2 = cb_Q02.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S1_3 = cb_Q03.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S1_4 = cb_Q04.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S1_5 = cb_Q05.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S1_6 = cb_Q06.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S1_7 = cb_Q07.IsChecked == true ? "Y" : "N";
              
                //LoginSession.SelectedSurvey.S1_9 = cb_Q09.IsChecked == true ? "Y" : "N";
                //LoginSession.SelectedSurvey.S1_10 = cb_Q10.IsChecked == true ? "Y" : "N";
                //LoginSession.SelectedSurvey.S1_11 = cb_Q11.IsChecked == true ? "Y" : "N";
                //LoginSession.SelectedSurvey.S1_12 = cb_Q12.IsChecked == true ? "Y" : "N";

                LoginSession.SelectedSurvey_M.S1_First = tb_first.Text;
                //LoginSession.SelectedSurvey.S1_Second = tb_second.Text;

                LoginSession.SelectedSurvey_M.S2_1_1 = cb_Q301.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S2_1_2 = cb_Q302.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S2_1_3 = cb_Q303.IsChecked == true ? "Y" : "N";

                LoginSession.SelectedSurvey_M.S2_2 = GetRadioValue(grid_Q02_2_RadioList);
                LoginSession.SelectedSurvey_M.S2_3 = GetRadioValue(grid_Q02_3_RadioList);
                //LoginSession.SelectedSurvey.S2_4 = GetRadioValue(grid_Q02_4_RadioList);

                LoginSession.SelectedSurvey_M.S2_4 = GetRadioValue(grid_Q02_4_RadioList);
                LoginSession.SelectedSurvey_M.S2_5 = GetRadioValue(grid_Q02_5_RadioList);
                LoginSession.SelectedSurvey_M.S2_6 = GetRadioValue(grid_Q02_6_RadioList);
                LoginSession.SelectedSurvey_M.S2_7 = GetRadioValue(grid_Q02_7_RadioList);
                LoginSession.SelectedSurvey_M.S2_8 = GetRadioValue(grid_Q02_8_RadioList);
            }

            return true;
        }

        //채크여부 가져오기
        public bool GetRadioCheck(Grid grid)
        {
            foreach (RadioButton rdo in grid.Children)
            {
                if (rdo.IsChecked == true)
                {
                    return true;
                }
            }
            return false;
        }

        public bool GetCheckBoxCheck(Grid grid)
        {
            foreach (CheckBox cb in grid.Children)
            {
                if (cb.IsChecked == true)
                {
                    return true;
                }
            }
            return false;
        }

        //채크된 번호 가져오기
        public string GetRadioValue(Grid grid)
        {
            int cnt = 0;
            foreach (RadioButton rdo in grid.Children)
            {
                if (rdo.IsChecked == true)
                {
                    cnt = grid.Children.IndexOf(rdo);
                }
            }
            return cnt.ToString();
        }

        public string GetCheckValue(Grid grid)
        {
            List<string> countArr = new List<string>();
            string tempArray;

            foreach (CheckBox cb in grid.Children)
            {
                if (cb.IsChecked == true)
                {
                    countArr.Add((grid.Children.IndexOf(cb)).ToString());
                }
            }

            if (countArr.Count > 1)
            {
                tempArray = string.Join("^", countArr);
                return tempArray;
            }
            else
            {
                tempArray = string.Join("", countArr);
                return tempArray;
            }
        }

    }
}
