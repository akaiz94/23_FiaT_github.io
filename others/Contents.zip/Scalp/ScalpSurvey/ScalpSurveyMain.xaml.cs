﻿using IOPE_LAB.Common;
using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Telerik.Windows.Controls;
//using static IOPE_LAB.Contents.Survey.SurveyMain;

namespace IOPE_LAB.Contents.Scalp.ScalpSurvey
{
    /// <summary>
    /// ScalpSurveyMain.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ScalpSurveyMain : Page
    {

        public enum SurveyPageName
        {
            //SurveyPage01, SurveyPage02, SurveyPage03
            ScalpSurveyPage01, ScalpSurveyPage02
        }

        public ScalpSurveyMain()
        {
            InitializeComponent();

            this.btn_Back.Click += Btn_Back_Click;
            this.btn_Next.Click += Btn_Next_Click;
            this.btn_Submit.Click += Btn_Submit_Click;
        }
        
        private void Btn_Submit_Click(object sender, RoutedEventArgs e)
        {
            if (GetSurveyPageName() == SurveyPageName.ScalpSurveyPage02)
            {
               if (uc_ScalpSurveyPage01.GetCustomerInputValidation() == true && uc_ScalpSurveyPage02.GetCustomerInputValidation() == true)
                {
                    if (LoginSession.AdminContentFlag != true)
                    {
                        SurveyService.SurveyServiceClient ssc = new SurveyService.SurveyServiceClient();

                        //설문결과 변수 저장(두피)
                        int result = ssc.Insert_Update_C_SurveyResult_Scalp(LoginSession.SelectedSurvey_M);

                        if (ssc.State == System.ServiceModel.CommunicationState.Closed)
                        {
                            ssc.Close();
                        }

                        if (result > 0)
                        {
                            Common.CommonMessageBox.ShowAlertMessage("저장 되었습니다.");
                            CommonBiz.SelectMenu(MainWindow.Menus.DevicePage);
                        }
                    }
                    else
                    {
                        Common.CommonMessageBox.ShowAlertMessage("관리자 기능 사용중엔 저장기능을 사용 할 수 없습니다.");
                    }
                }

            }
        }

        private void Btn_Next_Click(object sender, RoutedEventArgs e)
        {
            switch (GetSurveyPageName())
            {
                case SurveyPageName.ScalpSurveyPage01:
                    SetSurveyPageUI(SurveyPageName.ScalpSurveyPage02);
                    break;

                case SurveyPageName.ScalpSurveyPage02:
                    break;
            }
        }

        private void Btn_Back_Click(object sender, RoutedEventArgs e)
        {
            switch (GetSurveyPageName())
            {
                //case SurveyPageName.SurveyPage01_1:
                //    SetSurveyPageUI(SurveyPageName.SurveyPage01);
                //    break;
                case SurveyPageName.ScalpSurveyPage02:
                    SetSurveyPageUI(SurveyPageName.ScalpSurveyPage01);
                    break;
            }
        }

        public SurveyPageName GetSurveyPageName()
        {
            SurveyPageName result = SurveyPageName.ScalpSurveyPage01;

            if (uc_ScalpSurveyPage01.Visibility == Visibility)
            {
                result = SurveyPageName.ScalpSurveyPage01;
            }
            //else if (uc_ScalpSurveyPage01_1.Visibility == Visibility.Visible)
            //{
            //    result = SurveyPageName.SurveyPage01_1;

            //}

            else if (uc_ScalpSurveyPage02.Visibility == Visibility.Visible)
            {
                result = SurveyPageName.ScalpSurveyPage02;
            }

            return result;
        }

        public void SetSurveyPageUI(SurveyPageName s_pagename)
        {
            switch (s_pagename)
            {
                case SurveyPageName.ScalpSurveyPage01:
                    uc_ScalpSurveyPage01.Visibility = Visibility.Visible;
                    //uc_ScalpSurveyPage01_1.Visibility = Visibility.Collapsed;

                    uc_ScalpSurveyPage02.Visibility = Visibility.Collapsed;
                    btn_Next.Visibility = Visibility.Visible;
                    btn_Back.Visibility = Visibility.Collapsed;
                    btn_Submit.Visibility = Visibility.Collapsed;
                    break;
                //case SurveyPageName.SurveyPage01_1:
                //    uc_ScalpSurveyPage01.Visibility = Visibility.Collapsed;
                //    uc_ScalpSurveyPage01_1.Visibility = Visibility.Visible;
                //    uc_SurveyPage02.Visibility = Visibility.Collapsed;
                //    btn_Next.Visibility = Visibility.Visible;
                //    btn_Back.Visibility = Visibility.Visible;
                //    btn_Submit.Visibility = Visibility.Collapsed;
                //    break;

                case SurveyPageName.ScalpSurveyPage02:
                    uc_ScalpSurveyPage01.Visibility = Visibility.Collapsed;
                    //uc_ScalpSurveyPage01_1.Visibility = Visibility.Collapsed;
                    uc_ScalpSurveyPage02.Visibility = Visibility.Visible;
                    btn_Next.Visibility = Visibility.Collapsed;
                    btn_Back.Visibility = Visibility.Visible;
                    btn_Submit.Visibility = Visibility.Visible;
                    break;

            }
        }
    }
}
