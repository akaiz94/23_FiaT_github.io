﻿using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Scalp.ScalpSurvey
{
    /// <summary>
    /// ScalpSurveyPage02.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ScalpSurveyPage02 : UserControl
    {
        public ScalpSurveyPage02()
        {
            InitializeComponent();

            this.Loaded += SurveyPage02_Loaded;
            foreach (RadioButton rdo in grid_Q02_9_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_10_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_11_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (CheckBox cb in grid_Q02_12_RadioList.Children) { cb.Checked += new RoutedEventHandler(cb_Checked); }

            // 3-1
            foreach (CheckBox cb in grid_Q03_1_checkbox_List.Children) { cb.Checked += new RoutedEventHandler(cb_Checked); }

            // 3-2
            foreach (RadioButton rdo in grid_Q03_2_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }

        }


        private void SurveyPage02_Loaded(object sender, RoutedEventArgs e)
        {
            SetData();
        }

        private void SetData()
        {
            if (LoginSession.SelectedSurvey_M != null)
            {
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_9) != true)
                    SetRadioCheck(grid_Q02_9_RadioList, LoginSession.SelectedSurvey_M.S2_9);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_10) != true)
                    SetRadioCheck(grid_Q02_10_RadioList, LoginSession.SelectedSurvey_M.S2_10);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_11) != true)
                    SetRadioCheck(grid_Q02_11_RadioList, LoginSession.SelectedSurvey_M.S2_11);

                // 2-12
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_12_1) != true)
                    SetCheckBox(cb_Q401, LoginSession.SelectedSurvey_M.S2_12_1);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_12_2) != true)
                    SetCheckBox(cb_Q402, LoginSession.SelectedSurvey_M.S2_12_2);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_12_3) != true)
                    SetCheckBox(cb_Q403, LoginSession.SelectedSurvey_M.S2_12_3);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_12_4) != true)
                    SetCheckBox(cb_Q404, LoginSession.SelectedSurvey_M.S2_12_4);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_12_5) != true)
                    SetCheckBox(cb_Q405, LoginSession.SelectedSurvey_M.S2_12_5);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_12_6) != true)
                    SetCheckBox(cb_Q406, LoginSession.SelectedSurvey_M.S2_12_6);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_12_7) != true)
                    SetCheckBox(cb_Q407, LoginSession.SelectedSurvey_M.S2_12_7);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_12_8) != true)
                    SetCheckBox(cb_Q408, LoginSession.SelectedSurvey_M.S2_12_8);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S2_12_9) != true)
                    SetCheckBox(cb_Q409, LoginSession.SelectedSurvey_M.S2_12_9);

                // 3-1
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S3_1_1) != true)
                    SetCheckBox(cb_Q201, LoginSession.SelectedSurvey_M.S3_1_1);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S3_1_2) != true)
                    SetCheckBox(cb_Q202, LoginSession.SelectedSurvey_M.S3_1_2);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S3_1_3) != true)
                    SetCheckBox(cb_Q203, LoginSession.SelectedSurvey_M.S3_1_3);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S3_1_4) != true)
                    SetCheckBox(cb_Q204, LoginSession.SelectedSurvey_M.S3_1_4);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S3_1_5) != true)
                    SetCheckBox(cb_Q205, LoginSession.SelectedSurvey_M.S3_1_5);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S3_1_6) != true)
                    SetCheckBox(cb_Q206, LoginSession.SelectedSurvey_M.S3_1_6);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S3_1_7) != true)
                    SetCheckBox(cb_Q207, LoginSession.SelectedSurvey_M.S3_1_7);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S3_1_8) != true)
                    SetCheckBox(cb_Q208, LoginSession.SelectedSurvey_M.S3_1_8);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S3_1_First) != true)
                    tb_second.Text = LoginSession.SelectedSurvey_M.S3_1_First;

                // 3-2
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey_M.S3_2) != true)
                    SetRadioCheck(grid_Q03_2_RadioList, LoginSession.SelectedSurvey_M.S3_2);

            }
        }
        private void SetRadioCheck(Grid grid_list, string checkNum)
        {
            try
            {
                int index = int.Parse(checkNum);
                (grid_list.Children[index] as RadioButton).IsChecked = true;
            }
            catch (Exception ex)
            {

            }
        }

        private void SetCheckBox(CheckBox checkbox, string str_IsCheckYN)
        {
            if (str_IsCheckYN == "Y")
            {
                checkbox.IsChecked = true;
            }
        }

        void cb_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                CheckBox cb = sender as CheckBox;
                Grid grid = cb.Parent as Grid;

                if (LoginSession.SelectedSurvey_M != null)
                {
                    switch (grid.Name)
                    {
                        case "grid_Q02_12_RadioList":
                            LoginSession.SelectedSurvey_M.S2_9 = (grid.Children.IndexOf(cb)).ToString();
                            break;
                        case "grid_Q03_1_checkbox_List":
                            LoginSession.SelectedSurvey_M.S2_10 = (grid.Children.IndexOf(cb)).ToString();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }

        }

        void rdo_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rdo = sender as RadioButton;
            Grid grid = rdo.Parent as Grid;
            if (LoginSession.SelectedSurvey_M != null)
            {
                switch (grid.Name)
                {
                    case "grid_Q02_9_RadioList":
                        LoginSession.SelectedSurvey_M.S2_9 = (grid.Children.IndexOf(rdo)).ToString();
                        break;
                    case "grid_Q02_10_RadioList":
                        LoginSession.SelectedSurvey_M.S2_10 = (grid.Children.IndexOf(rdo)).ToString();
                        break;
                    case "grid_Q02_11_RadioList":
                        LoginSession.SelectedSurvey_M.S2_11 = (grid.Children.IndexOf(rdo)).ToString();
                        break;
                    case "grid_Q03_2_RadioList":
                        LoginSession.SelectedSurvey_M.S3_2 = (grid.Children.IndexOf(rdo)).ToString();
                        break;
                }
            }
        }

        //변수체크
        public bool GetCustomerInputValidation()
        {
            int check_count = 0;

            if (cb_Q201.IsChecked == true)
                check_count++;
            if (cb_Q202.IsChecked == true)
                check_count++;
            if (cb_Q203.IsChecked == true)
                check_count++;
            if (cb_Q204.IsChecked == true)
                check_count++;
            if (cb_Q205.IsChecked == true)
                check_count++;
            if (cb_Q206.IsChecked == true)
                check_count++;
            if (cb_Q207.IsChecked == true)
                check_count++;
            if (cb_Q208.IsChecked == true)
                check_count++;


            if (check_count < 1)
            {
                Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_35);
                cb_Q201.Focus();
                return false;
            }

            //1순위 텍스트 입력 알림창
            if (string.IsNullOrWhiteSpace(tb_second.Text) == true)
            {
                Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_13);
                tb_second.Focus();
                return false;
            }

            //
            if (GetRadioCheck(grid_Q02_9_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str05); return false; }
            //
            if (GetRadioCheck(grid_Q02_10_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str06); return false; }
            //
            if (GetRadioCheck(grid_Q02_11_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str07); return false; }
            //
            if (GetRadioCheck(grid_Q03_2_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str07); return false; }

            if (LoginSession.SelectedSurvey_M != null)
            {
                LoginSession.SelectedSurvey_M.S2_9 = GetRadioValue(grid_Q02_9_RadioList);
                LoginSession.SelectedSurvey_M.S2_10 = GetRadioValue(grid_Q02_10_RadioList);
                LoginSession.SelectedSurvey_M.S2_11 = GetRadioValue(grid_Q02_11_RadioList);

                // 2-12
                LoginSession.SelectedSurvey_M.S2_12_1 = cb_Q401.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S2_12_2 = cb_Q402.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S2_12_3 = cb_Q403.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S2_12_4 = cb_Q404.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S2_12_5 = cb_Q405.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S2_12_6 = cb_Q406.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S2_12_7 = cb_Q407.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S2_12_8 = cb_Q408.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S2_12_9 = cb_Q409.IsChecked == true ? "Y" : "N";

                // 3-1
                LoginSession.SelectedSurvey_M.S3_1_1 = cb_Q201.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S3_1_2 = cb_Q202.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S3_1_3 = cb_Q203.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S3_1_4 = cb_Q204.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S3_1_5 = cb_Q205.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S3_1_6 = cb_Q206.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S3_1_7 = cb_Q207.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S3_1_8 = cb_Q208.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey_M.S3_1_First = tb_second.Text;

                // 3-2
                LoginSession.SelectedSurvey_M.S3_2 = GetRadioValue(grid_Q03_2_RadioList);
            }

            return true;
        }

        //채크여부 가져오기
        public bool GetRadioCheck(Grid grid)
        {
            foreach (RadioButton rdo in grid.Children)
            {
                if (rdo.IsChecked == true)
                {
                    return true;
                }
            }
            return false;
        }

        private void SetCheckBox(Grid grid_list, string checkNum)
        {
            try
            {
                int index = 0;

                if (checkNum.Contains("^"))
                {
                    string[] check_num_list = checkNum.Split('^');
                    foreach (string str in check_num_list)
                    {
                        index = int.Parse(str);
                        (grid_list.Children[index] as CheckBox).IsChecked = true;
                    }
                }
                else
                {
                    index = int.Parse(checkNum);
                    (grid_list.Children[index] as CheckBox).IsChecked = true;
                }

            }
            catch (Exception)
            {

            }
        }

        //채크된 번호 가져오기
        public string GetRadioValue(Grid grid)
        {
            int cnt = 0;
            foreach (RadioButton rdo in grid.Children)
            {
                if (rdo.IsChecked == true)
                {
                    cnt = grid.Children.IndexOf(rdo);
                }
            }
            return cnt.ToString();
        }

        //체크여부 가져오기
        public bool GetCheckBoxCheck(Grid grid)
        {
            foreach (CheckBox cb in grid.Children)
            {
                if (cb.IsChecked == true)
                {
                    return true;
                }
            }
            return false;
        }

        public string GetCheckValue(Grid grid)
        {
            List<string> countArr = new List<string>();
            string tempArray;

            foreach (CheckBox cb in grid.Children)
            {
                if (cb.IsChecked == true)
                {
                    countArr.Add((grid.Children.IndexOf(cb)).ToString());
                }
            }

            if (countArr.Count > 1)
            {
                tempArray = string.Join("^", countArr);
                return tempArray;
            }
            else
            {
                tempArray = string.Join("", countArr);
                return tempArray;
            }
        }


    }
}
