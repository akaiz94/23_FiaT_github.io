﻿using IOPE_LAB.Contents.Scalp.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using IOPE_LAB.Contents.Scalp.ViewModels;

namespace IOPE_LAB.Contents.Scalp
{
    /// <summary>
    /// Window_Opinion.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Window_Opinion : Window
    {
        public Window_Opinion()
        {
            InitializeComponent();
            this.DataContext = new WindowOpinionViewModel();
            SelectTypes();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void SelectTypes()
        {
            List<string> types = DBManager.GetHairLossTypeList();
            BrushConverter brushConverter = new BrushConverter();

            foreach (string type in types)
            {
                Border border = FindName(type) as Border;
                Border innerBorder = FindName($"inner{type}") as Border;
                TextBlock textType = FindName($"text{type}") as TextBlock;

                border.BorderBrush = (Brush)brushConverter.ConvertFrom("#efc5f0");
                innerBorder.Background = (Brush)brushConverter.ConvertFrom("#efc5f0");
                textType.Foreground = (Brush)brushConverter.ConvertFrom("#ffffff");
            }
        }
    }
}
