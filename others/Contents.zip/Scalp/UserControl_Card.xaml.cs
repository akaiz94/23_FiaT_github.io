﻿using IOPE_LAB.Contents.Scalp.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Scalp
{
    /// <summary>
    /// UserControl_Card.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UserControl_Card : UserControl
    {
        private UserControl_tooltip userControlTooltip;


        public UserControl_Card()
        {
            InitializeComponent();

            this.Loaded += UserControl_Card_Loaded;
        }

        private void UserControl_Card_Loaded(object sender, RoutedEventArgs e)
        {
            //this.ToolTip = this.img_view.ImageSource;
            userControlTooltip = new UserControl_tooltip(this.img_view.ImageSource);
            this.ToolTip = userControlTooltip;
        }

        public BitmapImage ConvertBytesToBitmap(byte[] _data)
        {
            try
            {
                byte[] image = _data;
                string base64String = Encoding.UTF8.GetString(image, 0, image.Length);

                BitmapImage bitmap = new BitmapImage();
                MemoryStream strm = new MemoryStream();
                strm.Write(System.Convert.FromBase64String(base64String), 0, System.Convert.FromBase64String(base64String).Length);
                strm.Seek(0, SeekOrigin.Begin);
                // Read the image into the bitmap object
                bitmap.BeginInit();
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.StreamSource = strm;
                bitmap.EndInit();
                return bitmap;
            }
            catch (Exception)
            {
                return null;
            }
        }



        public int Index { get; set; }

        public string title { get; set; }

        public BitmapImage ImgSource
        {
            get { return (BitmapImage)GetValue(ImgSourceProperty); }
            set { SetValue(ImgSourceProperty, value); }
        }

        public static readonly DependencyProperty ImgSourceProperty =
            DependencyProperty.Register("ImgSource", typeof(BitmapImage), typeof(UserControl_Card), new PropertyMetadata(null));

        public float Thickness
        {
            get { return (float)GetValue(ThicknessProperty); }
            set { SetValue(ThicknessProperty, value); }
        }

        public static readonly DependencyProperty ThicknessProperty =
            DependencyProperty.Register("Thickness", typeof(float), typeof(UserControl_Card), new PropertyMetadata(null));

        public float Density
        {
            get { return (float)GetValue(DensityProperty); }
            set { SetValue(DensityProperty, value); }
        }

        public static readonly DependencyProperty DensityProperty =
            DependencyProperty.Register("Density", typeof(float), typeof(UserControl_Card), new PropertyMetadata(null));

        public float ThicknessMean
        {
            get { return (float)GetValue(ThicknessMeanProperty); }
            set { SetValue(ThicknessMeanProperty, value); }
        }

        public static readonly DependencyProperty ThicknessMeanProperty =
            DependencyProperty.Register("ThicknessMean", typeof(float), typeof(UserControl_Card), new PropertyMetadata(null));

        public float DensityMean
        {
            get { return (float)GetValue(DensityMeanProperty); }
            set { SetValue(DensityMeanProperty, value); }
        }

        public static readonly DependencyProperty DensityMeanProperty =
            DependencyProperty.Register("DensityMean", typeof(float), typeof(UserControl_Card), new PropertyMetadata(null));

        public string ScalpType
        {
            get { return (string)GetValue(ScalpTypeProperty); }
            set { SetValue(ScalpTypeProperty, value); }
        }

        public static readonly DependencyProperty ScalpTypeProperty =
            DependencyProperty.Register("ScalpType", typeof(string), typeof(UserControl_Card), new PropertyMetadata(null));

        private void OnMouseEnter(object sender, MouseEventArgs e)
        {
            this.ImgBorder.ToolTip = userControlTooltip;
        }

    }
}
