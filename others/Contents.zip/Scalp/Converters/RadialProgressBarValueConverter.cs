﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace IOPE_LAB.Contents.Scalp.Converters
{
    /// <summary>
    /// Value에 따라 원형 그래프를 그리기 위한 컨버터입니다.
    /// </summary>
    public class RadialProgressBarValueConverter: IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int hairConditionValue = (int)value;

            if (hairConditionValue == 4)
            {
                hairConditionValue = 0;
            }

            return hairConditionValue;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
