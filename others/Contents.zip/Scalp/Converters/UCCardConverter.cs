﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace IOPE_LAB.Contents.Scalp.Converters
{
    /// <summary>
    /// UserControl_Card Index에 따라 버튼 배경색상 변경 컨버터입니다.
    /// </summary>
    /// <param></param>
    /// <return string></return>
    public class UCCardConverter: IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int index = (int)value;

            string colorValue = string.Empty;

            // Console.WriteLine(index);
            switch (index)
            {
                case 1:
                    colorValue = "#EFC5F0";
                    break;
                case 2:
                    colorValue = "#ED7B39";
                    break;
                case 3:
                    colorValue = "#FAC936";
                    break;
                case 4:
                    colorValue = "#6DBFA1";
                    break;
                case 5:
                    colorValue = "#AEE8FC";
                    break;
                case 6:
                    colorValue = "#884AA1";
                    break;

            }
            // Console.WriteLine(colorValue);

            return colorValue;

        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}

