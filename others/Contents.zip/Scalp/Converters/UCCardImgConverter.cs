﻿using IOPE_LAB_Agreement.Entity;
using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media.Imaging;
using IOPE_LAB.Common;


namespace IOPE_LAB.Contents.Scalp.Converters
{
    /// <summary>
    /// HAIR DENSITY & THICKNESS 부위별 이미지를 렌더링하기 위한 컨버터입니다.
    /// </summary>
    public class UCCardImgConverter: IValueConverter
    {
        private ScalpService.ScalpServiceClient _scalpsc;
        private DataTable _dt;

        
        public BitmapImage imageSource;

        public BitmapImage ConvertBytesToBitmap(byte[] _data)
        {
            try
            {
                byte[] image = _data;
                string base64String = Encoding.UTF8.GetString(image, 0, image.Length);

                BitmapImage bitmap = new BitmapImage();
                MemoryStream strm = new MemoryStream();
                strm.Write(System.Convert.FromBase64String(base64String), 0, System.Convert.FromBase64String(base64String).Length);
                strm.Seek(0, SeekOrigin.Begin);
                // Read the image into the bitmap object
                bitmap.BeginInit();
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.StreamSource = strm;
                bitmap.EndInit();
                return bitmap;
                }
            catch (Exception)
            {
                return null;
            }
        }
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int index = (int)value;

            _scalpsc = new ScalpService.ScalpServiceClient();
            _dt = _scalpsc.ScalpType_Images(IOPE_LAB_CONTROLS.Base.LoginSession.SelectedMember.surveyNo, IOPE_LAB_CONTROLS.Base.LoginSession.SelectedMember.userkey);

            switch (index)
            {
                case 1:

                    // 좌측 헤어라인 Left hair line
                    //imageSource = Encoding.UTF8.GetBytes(_dt.Rows[0][11].ToString());
                    // byte[] temp = Encoding.UTF8.GetBytes(_dt.Rows[0][11].ToString());
                    //string temp = System.Convert.ToBase64String((byte[])_dt.Rows[0][11]);
                    //String base64 = Convert.ToBase64String(bytes);
                    //byte[] imgBytes = System.Convert.FromBase64String(_dt.Rows[0][11].ToString());
                    //imageSource = System.Convert.FromBase64String(FixBase64ForImage(_dt.Rows[0][11].ToString()));
                    imageSource = ConvertBytesToBitmap(_dt.Rows[0][11] as byte[]);
                    //Source
                    break;
                case 2:
                    // 앞 헤어라인
                    // imageSource = System.Convert.FromBase64String(_dt.Rows[0][6].ToString());
                    imageSource = ConvertBytesToBitmap((byte[])_dt.Rows[0][6]);
                    break;
                case 3:
                    // 우측 헤어라인
                    // imageSource = System.Convert.FromBase64String(_dt.Rows[0][9].ToString());
                    imageSource = ConvertBytesToBitmap((byte[])_dt.Rows[0][9]);
                    break;
                case 4:
                    // 앞 중앙 헤어라인
                    // imageSource = System.Convert.FromBase64String(_dt.Rows[0][7].ToString());
                    imageSource = ConvertBytesToBitmap((byte[])_dt.Rows[0][7]);
                    break;
                case 5:
                    // 정수리 헤어라인
                    // imageSource = System.Convert.FromBase64String(_dt.Rows[0][8].ToString());
                    imageSource = ConvertBytesToBitmap((byte[])_dt.Rows[0][8]);
                    break;
                case 6:
                    // 후두부 헤어라인
                    // imageSource = System.Convert.FromBase64String(_dt.Rows[0][10].ToString());
                    imageSource = ConvertBytesToBitmap((byte[])_dt.Rows[0][10]);
                    break;
            }


            //BitmapImage bitMap = new BitmapImage();
            /*string base64ImageString = System.Convert.ToBase64String(imageSource);
            byte[] imgBytes = System.Convert.FromBase64String(base64ImageString);*/

            //using (MemoryStream ms = new MemoryStream(imageSource, 0, imageSource.Length))
            //{
                // Image image = Image.FromStream(ms);
                // return image;

                /*bitMap.BeginInit();
                bitMap.StreamSource = ms;
                bitMap.CacheOption = BitmapCacheOption.OnLoad;
                bitMap.EndInit();*/
            //}
        
            //return new BitmapImage(new Uri("pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/1 좌측헤어라인.png"));
            //return bitMap;
            return imageSource;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
