﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace IOPE_LAB.Contents.Scalp.Converters
{
    public class EmptyStringConverter: IValueConverter
    {
        /// <summary>
        /// HAIR LOSS TYPE "NULL" 또는 빈 문자열이 들어오면 해당 컨트롤의 Visibilty 여부를 결정하기 위한 컨버터입니다.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string str = (string)value;
            string propertyValue = "Visible";

            if (String.IsNullOrEmpty(str))
            {
                propertyValue = "Collapsed";
            }

            return propertyValue;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
