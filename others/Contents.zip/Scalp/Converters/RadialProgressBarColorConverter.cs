﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace IOPE_LAB.Contents.Scalp.Converters
{
    internal class RadialProgressBarColorConverter: IValueConverter
    {
        /// <summary>
        /// Value에 따라 원형 그래프의 색상을 결정하기 위한 컨버터입니다.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {

            //string color = string.Empty;
            //string val = value.ToString();
            //switch (val)
            //{
            //    case "건강모":
            //        color = "#6DBFA1";
            //        break;
            //    case "약손상모":
            //        color = "#FAC936";
            //        break;
            //    case "손상모":
            //        color = "#ED7B39";
            //        break;
            //    case "극손상모":
            //        color = "tomato";
            //        break;
            //    case "열모/지모":
            //        color = "#884AA1";
            //        break;
            //}

            string color = "#e7c1da";

            return color;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}

