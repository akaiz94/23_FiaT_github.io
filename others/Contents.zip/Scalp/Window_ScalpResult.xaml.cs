﻿using IOPE_LAB.Contents.Scalp.UserControls;
using IOPE_LAB.Contents.Scalp.Utils;
using IOPE_LAB.Contents.Scalp.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using IOPE_LAB_CONTROLS.Base; //LoginSession 사용
using System.Data; // DataTable 사용


namespace IOPE_LAB.Contents.Scalp
{
    /// <summary>
    /// Window_ScalpResult.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Window_ScalpResult : Window
    {
        private UserControl _UCHairLossType;
        public Window_ScalpResult(ScalpResult_Data scalpResult_Data)
        {

            InitializeComponent();
            this.DataContext = new ScalpResultViewModel();
            this.Loaded += Control_Loaded;
            LoadHairLossType();
            AnalysisResult(scalpResult_Data);

        }

        private void AnalysisResult(ScalpResult_Data scalpResult_Data)
        {
            ScalpResultViewModel AnalysisResult = this.DataContext as ScalpResultViewModel;

            MemberService.MemberServiceClient msc = new MemberService.MemberServiceClient();
            DataTable dt = msc.visitCount("IC", LoginSession.SelectedMember.name, LoginSession.SelectedMember.birthdate, LoginSession.SelectedMember.PCCD);
            string searchDate = LoginSession.SelectedMember.rsvn_date.ToString("yyyy-MM-dd").Replace("-", "/");

            // AnalysisResult.C_Name = LoginSession.MySolution_ViewModel.C_Name; // No1.고객 이름

            AnalysisResult.C_Name = LoginSession.SelectedMember.name;// No1.고객 이름
            AnalysisResult.C_Date = searchDate; //  No2. 측정일자
            Hair_Care_Tip.Text = scalpResult_Data.specialtip_memo;

            if (dt.Rows.Count > 0)
            {
                string visit = dt.Rows.Count > 0 ? dt.Rows[0]["cnt"].ToString() : "0";
                AnalysisResult.C_Visit_Number = Int32.Parse(visit);
            }

        }


        private void Control_Loaded(object sender, RoutedEventArgs e)
        {

            List<string> ScalpTypesList = DBManager.GetScalpType();

            foreach (string item in ScalpTypesList)
            {
                Button button = FindName(item) as Button;
                button.Style = this.FindResource("style_PinkButton_Selected") as Style;
            }
        }

        private void LoadHairLossType()
        {
            int type = DBManager.GetHairLossTypeList().Count;

            switch (type)
            {
                case 1:
                    this._UCHairLossType = new UCHairLossPopupOne();
                    break;
                case 2:
                    this._UCHairLossType = new UCHairLossPopupTwo();
                    break;
                case 3:
                    this._UCHairLossType = new UCHairLossPopupThree();
                    break;
            }

            this.UCHairLossTypePopup.Content = _UCHairLossType;
        }

        private void Print_Btn(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            btn_PrintReady.Visibility = Visibility.Collapsed;

            if (printDialog.ShowDialog().GetValueOrDefault())
            {
                Transform originTransform = this.LayoutTransform;
                Size originSize = new Size(this.ActualWidth, this.ActualHeight);

                double xStartPrint = 45;
                double yStartPrint = 50;

                PrintCapabilities capabilities = printDialog.PrintQueue.GetPrintCapabilities(printDialog.PrintTicket);

                double scale = Math.Min(capabilities.PageImageableArea.ExtentWidth / this.ActualWidth, capabilities.PageImageableArea.ExtentHeight /
                                this.ActualHeight);

                this.LayoutTransform = new ScaleTransform(scale, scale);

                Size sz = new Size(capabilities.PageImageableArea.ExtentWidth, capabilities.PageImageableArea.ExtentHeight);

                this.Measure(sz);
                // this.Arrange(new Rect(new Point(capabilities.PageImageableArea.OriginWidth, capabilities.PageImageableArea.OriginHeight), sz));
                this.Arrange(new Rect(new Point(xStartPrint, yStartPrint), sz));


                printDialog.PrintVisual(this, "Print Scalp Result");

                this.LayoutTransform = originTransform;
                this.Measure(originSize);
                this.Arrange(new Rect(new Point(0, 0), originSize));
            }

            btn_PrintReady.Visibility = Visibility.Visible;
        }
    }
}
