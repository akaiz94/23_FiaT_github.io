﻿using IOPE_LAB_CONTROLS.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOPE_LAB.Contents.Scalp.Utils
{
    /// <summary>
    /// 타이핑 실수를 줄이기 위한 config 클래스
    /// </summary>
    public class ScalpTypeTableList
    {
        public const string Center = "center";
        public const string Back = "back";
        public const string FrontCenter = "Front Center";
        public const string FrontHairLine = "Front Hair Line";
        public const string LeftHairLine = "Left Hair Line";
        public const string RightHairLine = "Right Hair Line";

    }
}
