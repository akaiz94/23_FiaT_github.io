﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOPE_LAB.Contents.Scalp.Utils
{
    public class TypeDescription
    {
        private Dictionary<string, string> _dictTypeDescriptions;

        public TypeDescription()
        {
            this._dictTypeDescriptions = new Dictionary<string, string>();

            this._dictTypeDescriptions.Add("L", "현재 탈모의 형태가 관찰되지 않습니다. ");
            this._dictTypeDescriptions.Add("M0", "탈모는 진행되고 있지 않지만 헤어라인 모양이 M자형으로 예측됩니다. ");
            this._dictTypeDescriptions.Add("M1", "헤어라인이 M자 형태로 물러나기 시작하여 이마가 도드라져 보일 수 있습니다. ");
            this._dictTypeDescriptions.Add("M2", "헤어라인이 M자 형태로 물러나 보일 수 있으며 이마 헤어라인의 모발 또한 가늘어 보일 수 있습니다. ");
            this._dictTypeDescriptions.Add("M3", "헤어라인이 M자 형태로 물러난 양상이 가중되어 보이며 양쪽 이마 헤어라인이 비어 보일 수 있습니다. ");
            this._dictTypeDescriptions.Add("C0", "탈모는 진행되고 있지 않지만 헤어라인 모양이 C자형으로 예측됩니다. ");
            this._dictTypeDescriptions.Add("C1", "헤어라인이 C자 형태로 물러나기 시작하여 이마가 도드라져 보일 수 있습니다. ");
            this._dictTypeDescriptions.Add("C2", "헤어라인이 C자 형태로 물러나 보일 수 있으며 이마 헤어라인의 모발 또한 가늘어 보일 수 있습니다. ");
            this._dictTypeDescriptions.Add("C3", "헤어라인이 C자 형태로 물러난 양상이 가중되어 보이며 이마 헤어라인이 비어 보일 수 있습니다. ");
            this._dictTypeDescriptions.Add("U1", "정수리에서 후두부 융기까지를 3등분 하였을 때, 1/3 지점까지 탈모가 진행되었습니다. ");
            this._dictTypeDescriptions.Add("U2", "정수리에서 후두부 융기까지를 3등분 하였을 때, 2/3 지점까지 탈모가 진행되었습니다. ");
            this._dictTypeDescriptions.Add("U3", "정수리에서 후두부 융기까지를 3등분 하였을 때, 2/3 지점 이상 탈모가 진행되었습니다. ");
            this._dictTypeDescriptions.Add("F1", "헤어라인에서부터 정수리까지의 모발이 가늘어지는 형태가 예상됩니다. ");
            this._dictTypeDescriptions.Add("F2", "헤어라인에서부터 정수리까지의 모발이 가늘어지는 것이 육안으로도 인지될 수 있습니다. ");
            this._dictTypeDescriptions.Add("F3", "헤어라인에서부터 정수리까지의 모발이 매우 가늘어졌으며 밀도도 줄어든 것이 육안으로 인지될 수 있습니다. ");
            this._dictTypeDescriptions.Add("V1", "머리의 정점에서 머리카락이 가늘어지고 있음을 인지할 수 있습니다. ");
            this._dictTypeDescriptions.Add("V2", "머리의 정점에서 머리카락이 가늘어지고 면적이 넓어지고 있음을 인지할 수 있습니다. ");
            this._dictTypeDescriptions.Add("V3", "머리의 정점에 머리카락이 드물고 그 면적이 넓어지고 있음을 인지할 수 있습니다. ");            
        }

        public string GetTypeDescriptions()
        {
            List<string> lossTypeList = DBManager.GetHairLossTypeList();
            string description = "";

            foreach(string type in lossTypeList)
            {
                description += this._dictTypeDescriptions[type];
            }

            return description;
        }
    }
}
