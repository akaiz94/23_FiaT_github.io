﻿using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOPE_LAB.Contents.Scalp.Utils
{
    /// <summary>
    /// Hair_Scalp_Main Table 관련 데이터를 전역스코프로 사용하기 위한 Static 클래스입니다.
    /// </summary>
    public class DBManager
    {
        private static ScalpService.ScalpServiceClient _scalpsc;
        private static DataTable _dt = new DataTable();

        public static void intitallzeManger() {
            _scalpsc = new ScalpService.ScalpServiceClient();
            _dt = _scalpsc.ScalpType_Main(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
        }

        // 7 ~ 16 두피타입
        // 17 ~ 19 로스타입
        // 21 ~ 23 헤어 상태
        static DBManager()
        {
            _scalpsc = new ScalpService.ScalpServiceClient();
            _dt = _scalpsc.ScalpType_Main(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
        }

        public static string GetCustomerName()
        {
            return _dt.Rows[0][3].ToString();
        }

        public static string GetUserPhoneNumber()
        {
            return _dt.Rows[0][2].ToString();
        }

        public static string GetGender()
        {
            try
            {
                if (_dt.Rows[0][6].ToString() == "F")
                {
                    return "W";
                }
                else
                {
                    return _dt.Rows[0][6].ToString();
                }
                //return _dt.Rows[0][6].ToString();
            }
            catch (Exception ex)
            {
                throw new Exception("The Gender value is null....!");
            }

            //return _dt.Rows[0][6].ToString() ?? throw new Exception("The Gender value is null....!");
        }

        public static string GetHairLossBasicType()
        {
            return _dt.Rows[0][17].ToString();
        }

        public static string GetHairLossCenterType()
        {
            return _dt.Rows[0][18].ToString();
        }

        public static string GetHairLossFrontCenterType()
        {
            return _dt.Rows[0][19].ToString();
        }

        public static int GetRootHairCondition()
        {
            return Int32.Parse(_dt.Rows[0][21].ToString());
        }
        public static int GetMidHairCondition()
        {
            return Int32.Parse(_dt.Rows[0][22].ToString());
        }
        public static int GetTipsHairCondition()
        {
            return Int32.Parse(_dt.Rows[0][23].ToString());
        }

        public static List<string> GetHairLossTypeList()
        {
            List<string> list = new List<string>();

            if (!String.IsNullOrEmpty(_dt.Rows[0][17].ToString()))
            {
                list.Add(_dt.Rows[0][17].ToString());
            }

            if (!String.IsNullOrEmpty(_dt.Rows[0][18].ToString()))
            {
                list.Add(_dt.Rows[0][18].ToString());
            }

            if (!String.IsNullOrEmpty(_dt.Rows[0][19].ToString()))
            {
                list.Add(_dt.Rows[0][19].ToString());
            }

            return list;
        }


        public static List<string> GetScalpType()
        {
            ScalpService.ScalpServiceClient scalpsc = new ScalpService.ScalpServiceClient();
            DataTable dt = scalpsc.ScalpType_Main(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);


            List<string> ScalpTypesList = new List<string>();

            var ScalpTypes = new Dictionary<string, int>();

            ScalpTypes.Add("Nor", StringToIntConvert(dt.Rows[0][7].ToString()));
            ScalpTypes.Add("Oily", StringToIntConvert(dt.Rows[0][8].ToString()));
            ScalpTypes.Add("Ato", StringToIntConvert(dt.Rows[0][9].ToString()));
            ScalpTypes.Add("Trb", StringToIntConvert(dt.Rows[0][10].ToString()));
            ScalpTypes.Add("Dry", StringToIntConvert(dt.Rows[0][11].ToString()));
            ScalpTypes.Add("Sen", StringToIntConvert(dt.Rows[0][12].ToString()));
            ScalpTypes.Add("Seb", StringToIntConvert(dt.Rows[0][13].ToString()));
            ScalpTypes.Add("Ddan", StringToIntConvert(dt.Rows[0][14].ToString()));
            ScalpTypes.Add("Odan", StringToIntConvert(dt.Rows[0][15].ToString()));
            ScalpTypes.Add("Unknown", StringToIntConvert(dt.Rows[0][16].ToString()));

            foreach (KeyValuePair<string, int> item in ScalpTypes)
            {
                if (item.Value == 1)
                {
                    ScalpTypesList.Add(item.Key);
                }
            }

            return ScalpTypesList;
        }
        private static int StringToIntConvert(string data)
        {

            if (data == "")
            {
                return 0;
            }
            else
            {
                return Int32.Parse(data);
            }
        }
    }

    //public class ResultManager
    //{

    //}
}