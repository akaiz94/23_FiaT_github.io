﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using IOPE_LAB.Contents.Scalp.Utils;
using IOPE_LAB_CONTROLS.Base;

namespace IOPE_LAB.Contents.Scalp
{
    /// <summary>
    /// UserControl_HairAndScalpType.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UserControl_HairAndScalpType : UserControl
    {
        public UserControl_HairAndScalpType()
        {
            InitializeComponent();

            this.Loaded += Control_Loaded;
        }

        private void Control_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (string item in DBManager.GetScalpType())
            {
                Button button = FindName(item) as Button;
                button.Style = (Style)this.Resources["style_PinkButton_Selected"];
            }
        }

       
    }
}
