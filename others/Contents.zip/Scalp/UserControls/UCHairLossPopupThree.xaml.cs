﻿using IOPE_LAB.Contents.Scalp.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Scalp.UserControls
{
    /// <summary>
    /// UCHairLossPopupThree.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UCHairLossPopupThree : UserControl
    {
        public UCHairLossPopupThree()
        {
            InitializeComponent();
            LoadHairLossTypeImages();
            TypeDescription typeDescription = new TypeDescription();
            this.txtBox.Text = typeDescription.GetTypeDescriptions();
        }
        private void LoadHairLossTypeImages()
        {
            string gender = DBManager.GetGender();
            string basicType = DBManager.GetHairLossBasicType();
            string centerType = DBManager.GetHairLossCenterType();
            string frontCenterType = DBManager.GetHairLossFrontCenterType();

            switch (gender)
            {
                case "M":
                    if (basicType == "U1" || basicType == "U2" || basicType == "U3")
                    {
                        this.firstLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/M/{basicType}_f.png"));
                        firstRight.Visibility = System.Windows.Visibility.Collapsed;

                    }
                    else
                    {
                        this.firstLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/M/{basicType}_f.png"));
                        this.firstRight.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/M/{basicType}_s.png"));
                    }
                    this.secondLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/M/{centerType}_f.png"));
                    this.secondRight.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/M/{centerType}_s.png"));
                    this.thirdLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/M/{frontCenterType}_f.png"));
                    this.thirdRight.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/M/{frontCenterType}_s.png"));
                    break;

                case "W":
                    if (basicType == "U1" || basicType == "U2" || basicType == "U3")
                    {
                        this.firstLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/W/{basicType}_f.png"));
                        firstRight.Visibility = System.Windows.Visibility.Collapsed;
                    }
                    else
                    {
                        this.firstLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/W/{basicType}_f.png"));
                        this.firstRight.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/W/{basicType}_s.png"));
                    }
                    this.secondLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/W/{centerType}_f.png"));
                    this.secondRight.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/W/{centerType}_s.png"));
                    this.thirdLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/W/{frontCenterType}_f.png"));
                    this.thirdRight.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/W/{frontCenterType}_s.png"));
                    break;
            }
        }
    }
}
