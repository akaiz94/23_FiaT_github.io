﻿using IOPE_LAB.Contents.Scalp.Utils;
using IOPE_LAB.Contents.Scalp.ViewModels.UCViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics.PerformanceData;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Scalp.UserControls
{
    /// <summary>
    /// UCHairLossOneType.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UCHairLossOneType : UserControl
    {
        Window windowOpinion;
        public UCHairLossOneType()
        {
            InitializeComponent();
            this.DataContext = new UCHairLossOneTypeViewModel();
            LoadHairLossTypeImages();
        }

        private void btnHairLossType(object sender, RoutedEventArgs e)
        {
            string gender = DBManager.GetGender();
            switch (gender)
            {
                case "M":
                    windowOpinion = new Window_Opinion_M();
                    break;
                case "W":
                    windowOpinion = new Window_Opinion();
                    break;
            }
            windowOpinion.ShowDialog();
        }

        private void LoadHairLossTypeImages()
        {
            string gender = DBManager.GetGender();
            List<string> lossOneType = DBManager.GetHairLossTypeList();

            switch (gender)
            {
                case "M":
                    if (lossOneType[0] == "L" || lossOneType[0] == "U1" || lossOneType[0] == "U2" || lossOneType[0] == "U3")
                    {
                        this.firstLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/M/{lossOneType[0]}_f.png"));
                        firstRightBorder.Visibility = System.Windows.Visibility.Collapsed;
                        LossTypeColumn2.Width = new GridLength(0);
                    }
                    else
                    {
                        this.firstLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/M/{lossOneType[0]}_f.png"));
                        this.firstRight.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/M/{lossOneType[0]}_s.png"));
                    }
                    break;

                case "W":
                    if (lossOneType[0] == "L" || lossOneType[0] == "U1" || lossOneType[0] == "U2" || lossOneType[0] == "U3")
                    {
                        this.firstLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/W/{lossOneType[0]}_f.png"));
                        firstRightBorder.Visibility = System.Windows.Visibility.Collapsed;
                        LossTypeColumn2.Width = new GridLength(0);

                    }
                    else
                    {
                        this.firstLeft.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/W/{lossOneType[0]}_f.png"));
                        this.firstRight.Source = new BitmapImage(new Uri($"pack://application:,,,/IOPE_LAB;component/Contents/Scalp/Resource/LossTypes/W/{lossOneType[0]}_s.png"));
                    }
                    break;
            }
        }
    }
}
