﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Media;
using System.Collections.ObjectModel;



namespace IOPE_LAB.Contents.Result
{
    public class MySkin_ViewModel : INotifyPropertyChanged
    {



        // 고객 이름 (client name)
        private string _c_Name;
        public string C_Name
        {
            get { return _c_Name; }
            set
            {
                if (_c_Name != value)
                {
                    _c_Name = value;
                    OnPropertyChanged();
                }
            }
        }

        // 방문 날짜
        private string _c_Date;
        public string C_Date
        {
            get { return _c_Date; }
            set
            {
                if (_c_Date != value)
                {
                    _c_Date = value;
                    OnPropertyChanged();
                }
            }
        }

        // 방문 횟수
        private string _C_Visit_Number;
        public string C_Visit_Number
        {
            get { return _C_Visit_Number; }
            set
            {
                if (_C_Visit_Number != value)
                {
                    _C_Visit_Number = value;
                    OnPropertyChanged();
                }
            }
        }


        //1. 분석결과 - 피부점수
        private int _skin_Condition_Score;

        public int Skin_Condition_Score
        {
            get { return _skin_Condition_Score; }
            set
            {
                if (_skin_Condition_Score != value)
                {
                    _skin_Condition_Score = value;
                    OnPropertyChanged();
                    Skin_Condition_ScoreChanged();
                }
            }
        }

        //1.분석결과 - 현재 상태 원형테두리 조건
        private void Skin_Condition_ScoreChanged()
        {
            if (Skin_Condition_Score > 80)
            {
                Skin_Condition_Img = "./images/Skin_Condition00.png";
            }
            else if (Skin_Condition_Score >= 60)
            {
                Skin_Condition_Img = "./images/Skin_Condition01.png";
            }
            else if (Skin_Condition_Score >= 40)
            {
                Skin_Condition_Img = "./images/Skin_Condition02.png";
            }
            else if (Skin_Condition_Score >= 20)
            {
                Skin_Condition_Img = "./images/Skin_Condition03.png";
            }
            else
            {
                Skin_Condition_Img = "./images/Skin_Condition04.png";
            }
            OnPropertyChanged();
        }

        private string _skin_Condition_Img;
        public string Skin_Condition_Img
        {
            get { return _skin_Condition_Img; }
            set
            {
                if (_skin_Condition_Img != value)
                {
                    _skin_Condition_Img = value;
                    OnPropertyChanged();
                }
            }
        }



        // 2. 스킨타입 복합성 Yes or No
        //2-1) 피부타입 복합성 여부
        private int _skin_Type_Select;

        public int Skin_Type_Select
        {
            get { return _skin_Type_Select; }
            set
            {
                if (_skin_Type_Select != value)
                {
                    _skin_Type_Select = value;
                    OnPropertyChanged();
                    Skin_Type_Changed();
                }
            }
        }

        //2-1) 피부타입 복항성여부 체크 반영
        private void Skin_Type_Changed()
        {
            if (Skin_Type_Select == 1)
            {
                Skin_Type_Check_Img = "./images/Skin_Type_Check_No.png";
            }                  
            else 
            {
                Skin_Type_Check_Img = "./images/Skin_Type_Check_Yes.png";
            }

            OnPropertyChanged();
        }

        private string _skin_Type_Check_Img;
        public string Skin_Type_Check_Img
        {
            get { return _skin_Type_Check_Img; }
            set
            {
                if (_skin_Type_Check_Img != value)
                {
                    _skin_Type_Check_Img = value;
                    OnPropertyChanged();
                }
            }
        }


        //2.피부 타입 - T존 텍스트 내용


        private string _t_zone_Text;
        public string T_zone_Text
        {
            get { return _t_zone_Text; }
            set
            {
                if (_t_zone_Text != value)
                {
                    _t_zone_Text = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _u_zone_Text;
        public string U_zone_Text
        {
            get { return _u_zone_Text; }
            set
            {
                if (_u_zone_Text != value)
                {
                    _u_zone_Text = value;
                    OnPropertyChanged();
                }
            }
        }




        // 남여 성별 구분 (U,T존 이미지)
        private int _sex_Type;
        public int Sex_Type
        {
            get { return _sex_Type; }
            set
            {
                if (_sex_Type != value)
                {
                    _sex_Type = value;
                    OnPropertyChanged();
                    Sex_Type_Changed();
                }
            }
        }


        private void Sex_Type_Changed()
        {
            if (Sex_Type == 1)
            {
                Skin_Sex_Type_Img = "./images/Man_UT.png";
            }
            else
            {
                Skin_Sex_Type_Img = "./images/Woman_UT.png";
            }

            OnPropertyChanged();
        }


        private string _skin_Sex_Type_Img;
        public string Skin_Sex_Type_Img
        {
            get { return _skin_Sex_Type_Img; }
            set
            {
                if (_skin_Sex_Type_Img != value)
                {
                    _skin_Sex_Type_Img = value;
                    OnPropertyChanged();
                }
            }
        }



        // T존에 들어갈 9칸 내의 이미지 Select
        private int _mySkin_T_Zone_Select;
        public int MySkin_T_Zone_Select
        {
            get { return _mySkin_T_Zone_Select; }
            set
            {
                if (_mySkin_T_Zone_Select != value)
                {
                    _mySkin_T_Zone_Select = value;
                    OnPropertyChanged();
                    MySkin_T_Zone_Select_Changed();
                }
            }
        }


        private void MySkin_T_Zone_Select_Changed()
        {
            switch(MySkin_T_Zone_Select)
            {
                case 1: MySkin_T_Zone_Img = "./images/Zone1.png"; break;
                case 2: MySkin_T_Zone_Img = "./images/Zone2.png"; break;
                case 3: MySkin_T_Zone_Img = "./images/Zone3.png"; break;
                case 4: MySkin_T_Zone_Img = "./images/Zone4.png"; break;
                case 5: MySkin_T_Zone_Img = "./images/Zone5.png"; break;
                case 6: MySkin_T_Zone_Img = "./images/Zone6.png"; break;
                case 7: MySkin_T_Zone_Img = "./images/Zone7.png"; break;
                case 8: MySkin_T_Zone_Img = "./images/Zone8.png"; break;
                case 9: MySkin_T_Zone_Img = "./images/Zone9.png"; break;
            }        
            OnPropertyChanged();
        }


        private string _mySkin_T_Zone_Img;
        public string MySkin_T_Zone_Img
        {
            get { return _mySkin_T_Zone_Img; }
            set
            {
                if (_mySkin_T_Zone_Img != value)
                {
                    _mySkin_T_Zone_Img = value;
                    OnPropertyChanged();
                }
            }
        }



        // U존에 들어갈 9칸 내의 이미지 Select
        private int _mySkin_U_Zone_Select;
        public int MySkin_U_Zone_Select
        {
            get { return _mySkin_U_Zone_Select; }
            set
            {
                if (_mySkin_U_Zone_Select != value)
                {
                    _mySkin_U_Zone_Select = value;
                    OnPropertyChanged();
                    MySkin_U_Zone_Select_Changed();
                }
            }
        }


        private void MySkin_U_Zone_Select_Changed()
        {
            switch (MySkin_U_Zone_Select)
            {
                case 1: MySkin_U_Zone_Img = "./images/Zone1.png"; break;
                case 2: MySkin_U_Zone_Img = "./images/Zone2.png"; break;
                case 3: MySkin_U_Zone_Img = "./images/Zone3.png"; break;
                case 4: MySkin_U_Zone_Img = "./images/Zone4.png"; break;
                case 5: MySkin_U_Zone_Img = "./images/Zone5.png"; break;
                case 6: MySkin_U_Zone_Img = "./images/Zone6.png"; break;
                case 7: MySkin_U_Zone_Img = "./images/Zone7.png"; break;
                case 8: MySkin_U_Zone_Img = "./images/Zone8.png"; break;
                case 9: MySkin_U_Zone_Img = "./images/Zone9.png"; break;
            }
            OnPropertyChanged();
        }


        private string _mySkin_U_Zone_Img;
        public string MySkin_U_Zone_Img
        {
            get { return _mySkin_U_Zone_Img; }
            set
            {
                if (_mySkin_U_Zone_Img != value)
                {
                    _mySkin_U_Zone_Img = value;
                    OnPropertyChanged();
                }
            }
        }




        //3. 피부고민 - 분홍색 프로그레스 바 & 오른쪽 텍스트
        private int _mySkin_Concerns_Bar;
        public int MySkin_Concerns_Bar
        {
            get { return _mySkin_Concerns_Bar; }
            set
            {
                if (_mySkin_Concerns_Bar != value)
                {
                    _mySkin_Concerns_Bar = value;
                    OnPropertyChanged();
                    MySkin_Concern_Text_Changed();
                }
            }
        }

        private void MySkin_Concern_Text_Changed()
        {
            if(MySkin_Concerns_Bar > 80)
            {
                MySkin_Concerns_Text = "매우 좋음";
            }
            else if (MySkin_Concerns_Bar > 60)
            {
                MySkin_Concerns_Text = "좋음";
            }
            else if (MySkin_Concerns_Bar > 40)
            {
                MySkin_Concerns_Text = "보통";
            }
            else if (MySkin_Concerns_Bar > 20)
            {
                MySkin_Concerns_Text = "관심 필요";
            }
            else 
            {
                MySkin_Concerns_Text = "집중 관리";
            }
        }

        private string _mySkin_Concerns_Text;
        public string MySkin_Concerns_Text
        {
            get { return _mySkin_Concerns_Text; }
            set
            {
                if (_mySkin_Concerns_Text != value)
                {
                    _mySkin_Concerns_Text = value;
                    OnPropertyChanged();
                }
            }
        }





        private int _mySkin_Concerns_Bar1;
        public int MySkin_Concerns_Bar1
        {
            get { return _mySkin_Concerns_Bar1; }
            set
            {
                if (_mySkin_Concerns_Bar1 != value)
                {
                    _mySkin_Concerns_Bar1 = value;
                    MySkin_Concern_Text1_Changed();
                    OnPropertyChanged();

                }
            }
        }
        private void MySkin_Concern_Text1_Changed()
        {
            if (MySkin_Concerns_Bar1 > 80)
            {
                MySkin_Concerns_Text1 = "매우 좋음";
            }
            else if (MySkin_Concerns_Bar1 > 60)
            {
                MySkin_Concerns_Text1 = "좋음";
            }
            else if (MySkin_Concerns_Bar1 > 40)
            {
                MySkin_Concerns_Text1 = "보통";
            }
            else if (MySkin_Concerns_Bar1 > 20)
            {
                MySkin_Concerns_Text1 = "관심 필요";
            }
            else
            {
                MySkin_Concerns_Text1 = "집중 관리";
            }
        }

        private string _mySkin_Concerns_Text1;
        public string MySkin_Concerns_Text1
        {
            get { return _mySkin_Concerns_Text1; }
            set
            {
                if (_mySkin_Concerns_Text1 != value)
                {
                    _mySkin_Concerns_Text1 = value;
                    OnPropertyChanged();
                }
            }
        }



        private int _mySkin_Concerns_Bar2;
        public int MySkin_Concerns_Bar2
        {
            get { return _mySkin_Concerns_Bar2; }
            set
            {
                if (_mySkin_Concerns_Bar2 != value)
                {
                    _mySkin_Concerns_Bar2 = value;
                    MySkin_Concern_Text2_Changed();
                    OnPropertyChanged();
                }
            }
        }

        private void MySkin_Concern_Text2_Changed()
        {
            if (MySkin_Concerns_Bar2 > 80)
            {
                MySkin_Concerns_Text2 = "매우 좋음";
            }
            else if (MySkin_Concerns_Bar2 > 60)
            {
                MySkin_Concerns_Text2 = "좋음";
            }
            else if (MySkin_Concerns_Bar2 > 40)
            {
                MySkin_Concerns_Text2 = "보통";
            }
            else if (MySkin_Concerns_Bar2 > 20)
            {
                MySkin_Concerns_Text2 = "관심 필요";
            }
            else
            {
                MySkin_Concerns_Text2 = "집중 관리";
            }
        }

        private string _mySkin_Concerns_Text2;
        public string MySkin_Concerns_Text2
        {
            get { return _mySkin_Concerns_Text2; }
            set
            {
                if (_mySkin_Concerns_Text2 != value)
                {
                    _mySkin_Concerns_Text2 = value;
                    OnPropertyChanged();
                }
            }
        }





        private int _mySkin_Concerns_Bar3;
        public int MySkin_Concerns_Bar3
        {
            get { return _mySkin_Concerns_Bar3; }
            set
            {
                if (_mySkin_Concerns_Bar3 != value)
                {
                    _mySkin_Concerns_Bar3 = value;
                    MySkin_Concern_Text3_Changed();
                    OnPropertyChanged();
                }
            }
        }
        private void MySkin_Concern_Text3_Changed()
        {
            if (MySkin_Concerns_Bar3 > 80)
            {
                MySkin_Concerns_Text3 = "매우 좋음";
            }
            else if (MySkin_Concerns_Bar3 > 60)
            {
                MySkin_Concerns_Text3 = "좋음";
            }
            else if (MySkin_Concerns_Bar3 > 40)
            {
                MySkin_Concerns_Text3 = "보통";
            }
            else if (MySkin_Concerns_Bar3 > 20)
            {
                MySkin_Concerns_Text3 = "관심 필요";
            }
            else
            {
                MySkin_Concerns_Text3 = "집중 관리";
            }
        }

        private string _mySkin_Concerns_Text3;
        public string MySkin_Concerns_Text3
        {
            get { return _mySkin_Concerns_Text3; }
            set
            {
                if (_mySkin_Concerns_Text3 != value)
                {
                    _mySkin_Concerns_Text3 = value;
                    OnPropertyChanged();
                }
            }
        }



        private int _mySkin_Concerns_Bar4;
        public int MySkin_Concerns_Bar4
        {
            get { return _mySkin_Concerns_Bar4; }
            set
            {
                if (_mySkin_Concerns_Bar4 != value)
                {
                    _mySkin_Concerns_Bar4 = value;
                    MySkin_Concern_Text4_Changed();
                    OnPropertyChanged();
                }
            }
        }
        private void MySkin_Concern_Text4_Changed()
        {
            if (MySkin_Concerns_Bar4 > 80)
            {
                MySkin_Concerns_Text4 = "매우 좋음";
            }
            else if (MySkin_Concerns_Bar4 > 60)
            {
                MySkin_Concerns_Text4 = "좋음";
            }
            else if (MySkin_Concerns_Bar4 > 40)
            {
                MySkin_Concerns_Text4 = "보통";
            }
            else if (MySkin_Concerns_Bar4 > 20)
            {
                MySkin_Concerns_Text4 = "관심 필요";
            }
            else
            {
                MySkin_Concerns_Text4 = "집중 관리";
            }
        }

        private string _mySkin_Concerns_Text4;
        public string MySkin_Concerns_Text4
        {
            get { return _mySkin_Concerns_Text4; }
            set
            {
                if (_mySkin_Concerns_Text4 != value)
                {
                    _mySkin_Concerns_Text4 = value;
                    OnPropertyChanged();
                }
            }
        }





        private int _mySkin_Concerns_Bar5;
        public int MySkin_Concerns_Bar5
        {
            get { return _mySkin_Concerns_Bar5; }
            set
            {
                if (_mySkin_Concerns_Bar5 != value)
                {
                    _mySkin_Concerns_Bar5 = value;
                    MySkin_Concern_Text5_Changed();
                    OnPropertyChanged();
                }
            }
        }

        private void MySkin_Concern_Text5_Changed()
        {
            if (MySkin_Concerns_Bar5 > 80)
            {
                MySkin_Concerns_Text5 = "매우 좋음";
            }
            else if (MySkin_Concerns_Bar5 > 60)
            {
                MySkin_Concerns_Text5 = "좋음";
            }
            else if (MySkin_Concerns_Bar5 > 40)
            {
                MySkin_Concerns_Text5 = "보통";
            }
            else if (MySkin_Concerns_Bar5 > 20)
            {
                MySkin_Concerns_Text5 = "관심 필요";
            }
            else if (MySkin_Concerns_Bar5 > -10)
            {
                MySkin_Concerns_Text5 = "집중 관리";
            }
            else
            {
                MySkin_Concerns_Text5 = "집중 관리";
            }
        }

        private string _mySkin_Concerns_Text5;
        public string MySkin_Concerns_Text5
        {
            get { return _mySkin_Concerns_Text5; }
            set
            {
                if (_mySkin_Concerns_Text5 != value)
                {
                    _mySkin_Concerns_Text5 = value;
                    OnPropertyChanged();
                }
            }
        }


        private int _mySkin_Concerns_Bar6;
        public int MySkin_Concerns_Bar6
        {
            get { return _mySkin_Concerns_Bar6; }
            set
            {
                if (_mySkin_Concerns_Bar6 != value)
                {
                    _mySkin_Concerns_Bar6 = value;
                    MySkin_Concern_Text6_Changed();
                    OnPropertyChanged();
                }
            }
        }

        private void MySkin_Concern_Text6_Changed()
        {
            if (MySkin_Concerns_Bar6 > 80)
            {
                MySkin_Concerns_Text6 = "매우 좋음";
            }
            else if (MySkin_Concerns_Bar6 > 60)
            {
                MySkin_Concerns_Text6 = "좋음";
            }
            else if (MySkin_Concerns_Bar6 > 40)
            {
                MySkin_Concerns_Text6 = "보통";
            }
            else if (MySkin_Concerns_Bar6 > 20)
            {
                MySkin_Concerns_Text6 = "관심 필요";
            }
            else
            {
                MySkin_Concerns_Text6 = "집중 관리";
            }
        }

        private string _mySkin_Concerns_Text6;
        public string MySkin_Concerns_Text6
        {
            get { return _mySkin_Concerns_Text6; }
            set
            {
                if (_mySkin_Concerns_Text6 != value)
                {
                    _mySkin_Concerns_Text6 = value;
                    OnPropertyChanged();
                }
            }
        }





        private int _mySkin_Concerns_Bar7;
        public int MySkin_Concerns_Bar7
        {
            get { return _mySkin_Concerns_Bar7; }
            set
            {
                if (_mySkin_Concerns_Bar7 != value)
                {
                    _mySkin_Concerns_Bar7 = value;
                    MySkin_Concern_Text7_Changed();
                    OnPropertyChanged();
                }
            }
        }

        private void MySkin_Concern_Text7_Changed()
        {
            if (MySkin_Concerns_Bar7 > 80)
            {
                MySkin_Concerns_Text7 = "매우 좋음";
            }
            else if (MySkin_Concerns_Bar7 > 60)
            {
                MySkin_Concerns_Text7 = "좋음";
            }
            else if (MySkin_Concerns_Bar7 > 40)
            {
                MySkin_Concerns_Text7 = "보통";
            }
            else if (MySkin_Concerns_Bar7 > 20)
            {
                MySkin_Concerns_Text7 = "관심 필요";
            }
            else
            {
                MySkin_Concerns_Text7 = "집중 관리";
            }
        }

        private string _mySkin_Concerns_Text7;
        public string MySkin_Concerns_Text7
        {
            get { return _mySkin_Concerns_Text7; }
            set
            {
                if (_mySkin_Concerns_Text7 != value)
                {
                    _mySkin_Concerns_Text7 = value;
                    OnPropertyChanged();
                }
            }
        }




        private int _mySkin_Concerns_Bar8;
        public int MySkin_Concerns_Bar8
        {
            get { return _mySkin_Concerns_Bar8; }
            set
            {
                if (_mySkin_Concerns_Bar8 != value)
                {
                    _mySkin_Concerns_Bar8 = value;
                    MySkin_Concern_Text8_Changed();
                    OnPropertyChanged();
                }
            }
        }

        private void MySkin_Concern_Text8_Changed()
        {
            if (MySkin_Concerns_Bar8 > 80)
            {
                MySkin_Concerns_Text8 = "매우 좋음";
            }
            else if (MySkin_Concerns_Bar8 > 60)
            {
                MySkin_Concerns_Text8 = "좋음";
            }
            else if (MySkin_Concerns_Bar8 > 40)
            {
                MySkin_Concerns_Text8 = "보통";
            }
            else if (MySkin_Concerns_Bar8 > 20)
            {
                MySkin_Concerns_Text8 = "관심 필요";
            }
            else
            {
                MySkin_Concerns_Text8 = "집중 관리";
            }
        }

        private string _mySkin_Concerns_Text8;
        public string MySkin_Concerns_Text8
        {
            get { return _mySkin_Concerns_Text8; }
            set
            {
                if (_mySkin_Concerns_Text8 != value)
                {
                    _mySkin_Concerns_Text8 = value;
                    OnPropertyChanged();
                }
            }
        }


        // 4. 민감성 타입

        private string _mySkin_Solution_Type;
        public string MySkin_Solution_Type
        {
            get { return _mySkin_Solution_Type; }
            set
            {
                if (_mySkin_Solution_Type != value)
                {
                    _mySkin_Solution_Type = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _mySkin_Solution_Text;
        public string MySkin_Solution_Text
        {
            get { return _mySkin_Solution_Text; }
            set
            {
                if (_mySkin_Solution_Text != value)
                {
                    _mySkin_Solution_Text = value;
                    OnPropertyChanged();
                }
            }
        }










        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
