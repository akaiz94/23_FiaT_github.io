﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Result
{
    /// <summary>
    /// MySkin_PrintMain.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MySkin_PrintMain : Page
    {

        public enum MySolution_PageName
        {
            MySkin_PrintPage, MySkin_PrintPage_sub1

        }


        public MySkin_PrintMain()
        {
            InitializeComponent();
            

            this.btn_Back.Click += Btn_Back_Click;
            this.btn_Next.Click += Btn_Next_Click;
        }


        private void Btn_Back_Click(object sender, RoutedEventArgs e)
        {
            switch (GetMySkin_PageName())
            {
                case MySolution_PageName.MySkin_PrintPage_sub1:
                    SetMySkin_PageUI(MySolution_PageName.MySkin_PrintPage);
                    break;
              

            }
        }


        private void Btn_Next_Click(object sender, RoutedEventArgs e)
        {
            switch (GetMySkin_PageName())
            {
                case MySolution_PageName.MySkin_PrintPage:
                    SetMySkin_PageUI(MySolution_PageName.MySkin_PrintPage_sub1);
                    break;                              
            }
        }


        public MySolution_PageName GetMySkin_PageName()
        {
            MySolution_PageName result = MySolution_PageName.MySkin_PrintPage; //초기값

            if (hs_MySkin_PrintPage.Visibility == Visibility)
            {
                result = MySolution_PageName.MySkin_PrintPage;
            }

            else if (hs_MySkin_PrintPage_sub1.Visibility == Visibility.Visible)
            {
                result = MySolution_PageName.MySkin_PrintPage_sub1;
            }


            return result;
        }

        public void SetMySkin_PageUI(MySolution_PageName MySolution_pagename)
        {
            switch (MySolution_pagename)
            {
                case MySolution_PageName.MySkin_PrintPage: //페이지 보이기 (1페이지)
                    hs_MySkin_PrintPage.Visibility = Visibility.Visible;
                    hs_MySkin_PrintPage_sub1.Visibility = Visibility.Collapsed;                 

                    btn_Next.Visibility = Visibility.Visible; // 버튼 구분
                    btn_Back.Visibility = Visibility.Collapsed;                
                    break;

                case MySolution_PageName.MySkin_PrintPage_sub1: // 1-2페이지
                    hs_MySkin_PrintPage.Visibility = Visibility.Collapsed;
                    hs_MySkin_PrintPage_sub1.Visibility = Visibility.Visible;                 

                    btn_Next.Visibility = Visibility.Collapsed;
                    btn_Back.Visibility = Visibility.Visible;                  
                    break;                                

            }
        }





    }
}
