﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Markup; //IAddChild 활용 (동적 생성)
using System.IO;//MemoryStream 활용
using System.Printing; // 해상도 조절용 print ticket 사용
using IOPE_LAB_CONTROLS.Base;
using System.Data;


namespace IOPE_LAB.Contents.Result
{
    /// <summary>
    /// MySkin_PrintPage_sub1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MySkin_PrintPage_sub1 : Page
    {
        public MySkin_PrintPage_sub1()
        {
            InitializeComponent();

            AnalysisResult();
        }

        private void AnalysisResult()
        {
            MySkin_ViewModel AnalysisResult = this.DataContext as MySkin_ViewModel;
            AnalysisResult.C_Name = LoginSession.SelectedMember.name; // 고객 이름
            AnalysisResult.C_Date = LoginSession.SelectedMember.rsvn_date.ToString("yyyy-MM-dd").Replace("-", "/"); // 측정일자

            MemberService.MemberServiceClient msc = new MemberService.MemberServiceClient();
            DataTable dt = msc.visitCount("IC", LoginSession.SelectedMember.name, LoginSession.SelectedMember.birthdate, LoginSession.SelectedMember.PCCD);

            if (dt.Rows.Count > 0 && LoginSession.Selected_C_ResultPageData != null)
            {
                string visit = dt.Rows.Count > 0 ? dt.Rows[0]["cnt"].ToString() : "0";
                AnalysisResult.C_Visit_Number = dt.Rows[0]["cnt"].ToString();    // 방문 횟수
            }





        }




        private void btn_PrintReady_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            btn_PrintReady.Visibility = Visibility.Collapsed;


            if (printDialog.ShowDialog().GetValueOrDefault())
            {
                Transform originTransform = this.LayoutTransform;
                Size originSize = new Size(this.ActualWidth, this.ActualHeight);

                double xStartPrint = 45;
                double yStartPrint = 50;

                PrintCapabilities capabilities = printDialog.PrintQueue.GetPrintCapabilities(printDialog.PrintTicket);

                double scale = Math.Min(capabilities.PageImageableArea.ExtentWidth / this.ActualWidth, capabilities.PageImageableArea.ExtentHeight /
                                this.ActualHeight);

                this.LayoutTransform = new ScaleTransform(scale, scale);

                Size sz = new Size(capabilities.PageImageableArea.ExtentWidth, capabilities.PageImageableArea.ExtentHeight);

                this.Measure(sz);
                // this.Arrange(new Rect(new Point(capabilities.PageImageableArea.OriginWidth, capabilities.PageImageableArea.OriginHeight), sz));
                this.Arrange(new Rect(new Point(xStartPrint, yStartPrint), sz));


                printDialog.PrintVisual(this, "Print MySkin Result_Second");

                this.LayoutTransform = originTransform;
                this.Measure(originSize);
                this.Arrange(new Rect(new Point(0, 0), originSize));
            }

            btn_PrintReady.Visibility = Visibility.Visible;
        }

    }




}
