﻿using System.Windows.Controls;
using System;
using System.Collections.Generic;
using IOPE_LAB.UserControls;
using IOPE_LAB.Contents.Result;
using System.Linq;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Data;
using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity.MarkVu;
using IOPE_LAB.Common;
using IOPE_LAB_DEVICE;
using System.Windows.Media;
using LiveCharts;
using LiveCharts.Wpf;
using IOPE_LAB_CONTROLS.Entity;
using LiveCharts.Helpers;

namespace IOPE_LAB.Contents.Result
{
    /// <summary>
    /// MySkin_History.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MySkin_History : UserControl
    {

        //private ResultPage_Data_Entity items;
        //private ResultPage_Data_Entity rpde;
        private DataTable dt = null;
        private List<ResultHistrory> list = null;

        public MySkin_History()
        {
            InitializeComponent();
            //items = rpde;
            dt = new DataTable();
            dt = HistoryData();
            InitChart_V2(dt);


        }


        private DataTable HistoryData()
        {
            try
            {
                DataTable result = null;

                ResultService.ResultServiceClient rsc = new ResultService.ResultServiceClient();
                string gubun = string.Empty;

                if (LoginSession.SelectedMember.PCCD == "PC001009" || LoginSession.SelectedMember.PCCD == "PC001001" || LoginSession.SelectedMember.PCCD == "PC001013")
                {
                    gubun = "I";
                }
                else
                {
                    gubun = "B";
                }
                result = rsc.Select_History_ResultScore("IC", gubun, LoginSession.SelectedMember.name, LoginSession.SelectedMember.birthdate);

                if (rsc.State != System.ServiceModel.CommunicationState.Closed)
                {
                    rsc.Close();
                }

                if (result != null && result.Rows.Count > 0)
                {
                    list = new List<ResultHistrory>();

                    foreach (DataRow dr in result.Rows)
                    {
                        list.Add(new ResultHistrory()
                        {
                            surveyNo = Convert.ToInt32(dr["surveyNo"].ToString()),
                            name = dr["name"].ToString(),
                            birthdate = dr["birthdate"].ToString(),
                            rsvn_date = dr["rsvn_date"].ToString(),
                            t_zone_subun = Convert.ToDouble(dr["t_zone_subun"].ToString()),
                            t_zone_ubun = Convert.ToDouble(dr["t_zone_ubun"].ToString()),
                            u_zone_subun = Convert.ToDouble(dr["u_zone_subun"].ToString()),
                            u_zone_ubun = Convert.ToDouble(dr["u_zone_ubun"].ToString()),
                            skin_score = Convert.ToDouble(dr["skin_score"].ToString()),
                        });
                    }
                }

                return result;
            }
            catch (Exception)
            {
                return null;
            }
        }


        private void InitChart_V2(DataTable dt)
        {
            ChartValues<double> skinList = list.Select(x => x.skin_score).ToList().AsChartValues();
            ChartValues<double> tZoneSubunList = list.Select(x => x.t_zone_subun).ToList().AsChartValues();
            ChartValues<double> tZoneUbunList = list.Select(x => x.t_zone_ubun).ToList().AsChartValues();
            ChartValues<double> uZoneSubunList = list.Select(x => x.u_zone_subun).ToList().AsChartValues();
            ChartValues<double> uZoneUbunList = list.Select(x => x.u_zone_ubun).ToList().AsChartValues();


            //피부점수
            SeriesSkinScore = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "SkinScore:",
                    DataLabels = true,
                    Stroke = new SolidColorBrush(Colors.Gray),
                    Fill = new SolidColorBrush(Colors.Transparent),
                    Values = skinList
                },
            };

            //T존 수분
            SeriesTzoneSubun = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "TZone 수분:",
                    DataLabels = true,
                    Stroke = new SolidColorBrush(Colors.Gray),
                    Fill = new SolidColorBrush(Colors.Transparent),
                    Values = tZoneSubunList
                },
            };

            //T존 유분
            SeriesTzoneUbun = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "TZone 유분:",
                    DataLabels = true,
                    Stroke = new SolidColorBrush(Colors.Gray),
                    Fill = new SolidColorBrush(Colors.Transparent),
                    Values = tZoneUbunList
                },
            };

            //U존 수분
            SeriesUzoneSubun = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "UZone 수분:",
                    DataLabels = true,
                    Stroke = new SolidColorBrush(Colors.Gray),
                    Fill = new SolidColorBrush(Colors.Transparent),
                    Values = uZoneSubunList
                },
            };

            //U존 유분
            SeriesUzoneUbun = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "UZone 유분:",
                    DataLabels = true,
                    Stroke = new SolidColorBrush(Colors.Gray),
                    Fill = new SolidColorBrush(Colors.Transparent),
                    Values = uZoneUbunList
                },
            };


            DataContext = this;

            //MaxAxisValue = tZoneSubunList.Select(value => Math.Abs(value) + 10).Max();
            //MinAxisValue = this.MaxAxisValue * -1;

            //X축 날짜
            Labels = list.Select(x => x.rsvn_date).ToArray();

        }

        public SeriesCollection SeriesSkinScore { get; set; }
        public SeriesCollection SeriesTzoneSubun { get; set; }
        public SeriesCollection SeriesTzoneUbun { get; set; }
        public SeriesCollection SeriesUzoneSubun { get; set; }
        public SeriesCollection SeriesUzoneUbun { get; set; }
        public string[] Labels { get; set; }
        public double[] YFormatter { get; set; }
        public double MaxAxisValue { get; set; }
        public double MinAxisValue { get; set; }
    }
}
