﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IOPE_LAB.UserControls;
using System.Data;
using IOPE_LAB_CONTROLS.Entity;
using IOPE_LAB_CONTROLS.Base;

namespace IOPE_LAB.Contents.Result
{
    public class Result_Logic
    {

        public List<Result_Concern_Entity> list_rce = null;

        public List<Result_Sensitive_Entity> list_rse = null;

        public List<Result_Solution_Entity> list_rsse = null;

        public List<Result_Solution_RoleData> list_rule_data = null;

        public DataTable datatable_rule = null;

        public Result_Logic()
        {
            list_rce = new List<Result_Concern_Entity>();
            list_rse = new List<Result_Sensitive_Entity>();
            list_rsse = new List<Result_Solution_Entity>();
            list_rule_data = new List<Result_Solution_RoleData>();
            
            //Result_Concern_Entity
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 19, gubun = "모공", first = 32, second = 37, third = 42, fourth = 52, fifth = 57, sixth = 62, A = 37.6, B = 44.6, C = 0, D = 0, E = 0, F = 0, G = 34.4, H = 34.2, AVG = 38 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 19, gubun = "주름", first = 9.2, second = 12.2, third = 14.6, fourth = 16.4, fifth = 17.6, sixth = 22.2, A = 18.8, B = 0, C = 12.7, D = 13.7, E = 15.8, F = 16, G = 0, H = 0, AVG = 15 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 19, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 19, gubun = "색소침착", first = 8.5, second = 13.6, third = 18.1, fourth = 21.3, fifth = 24.6, sixth = 34.6, A = 15.1455, B = 21.5273, C = 0, D = 0, E = 13.5455, F = 14.2364, G = 21.9091, H = 21.5273, AVG = 18 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 19, gubun = "멜라닌", first = 3.8, second = 6.6, third = 9.5, fourth = 12, fifth = 15.1, sixth = 24.8, A = 9.83535, B = 16.4, C = 0, D = 0, E = 9.23636, F = 9.21818, G = 11.6182, H = 11.0546, AVG = 16 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 19, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 6.36136, B = 16.4833, C = 0, D = 0, E = 6.71818, F = 7.39631, G = 10.0281, H = 10.0361, AVG = 10 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 19, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 19, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 19, gubun = "탄력", first = 0.915962, second = 0.834322, third = 0.752682, fourth = 0.671042, fifth = 0.589402, sixth = 0.507762, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 19, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 24, gubun = "모공", first = 32, second = 37, third = 42, fourth = 52, fifth = 57, sixth = 62, A = 37.6, B = 44.6, C = 0, D = 0, E = 0, F = 0, G = 34.4, H = 34.2, AVG = 38 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 24, gubun = "주름", first = 9.2, second = 12.2, third = 14.6, fourth = 16.4, fifth = 17.6, sixth = 22.2, A = 18.8, B = 0, C = 12.7, D = 13.7, E = 15.8, F = 16, G = 0, H = 0, AVG = 15 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 24, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 24, gubun = "색소침착", first = 8.5, second = 13.6, third = 18.1, fourth = 21.3, fifth = 24.6, sixth = 34.6, A = 15.1455, B = 21.5273, C = 0, D = 0, E = 13.5455, F = 14.2364, G = 21.9091, H = 21.5273, AVG = 18 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 24, gubun = "멜라닌", first = 3.8, second = 6.6, third = 9.5, fourth = 12, fifth = 15.1, sixth = 24.8, A = 9.83535, B = 16.4, C = 0, D = 0, E = 9.23636, F = 9.21818, G = 11.6182, H = 11.0546, AVG = 16 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 24, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 6.36136, B = 16.4833, C = 0, D = 0, E = 6.71818, F = 7.39631, G = 10.0281, H = 10.0361, AVG = 10 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 24, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 24, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 24, gubun = "탄력", first = 0.915962, second = 0.834322, third = 0.752682, fourth = 0.671042, fifth = 0.589402, sixth = 0.507762, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 24, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 29, gubun = "모공", first = 32, second = 37, third = 42, fourth = 52, fifth = 57, sixth = 62, A = 37.6, B = 44.6, C = 0, D = 0, E = 0, F = 0, G = 34.4, H = 34.2, AVG = 38 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 29, gubun = "주름", first = 9.2, second = 12.2, third = 14.6, fourth = 16.4, fifth = 17.6, sixth = 22.2, A = 18.8, B = 0, C = 12.7, D = 13.7, E = 15.8, F = 16, G = 0, H = 0, AVG = 15 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 29, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 29, gubun = "색소침착", first = 8.5, second = 13.6, third = 18.1, fourth = 21.3, fifth = 24.6, sixth = 34.6, A = 15.1455, B = 21.5273, C = 0, D = 0, E = 13.5455, F = 14.2364, G = 21.9091, H = 21.5273, AVG = 18 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 29, gubun = "멜라닌", first = 3.8, second = 6.6, third = 9.5, fourth = 12, fifth = 15.1, sixth = 24.8, A = 9.83535, B = 16.4, C = 0, D = 0, E = 9.23636, F = 9.21818, G = 11.6182, H = 11.0546, AVG = 16 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 29, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 6.36136, B = 16.4833, C = 0, D = 0, E = 6.71818, F = 7.39631, G = 10.0281, H = 10.0361, AVG = 10 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 29, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 29, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 29, gubun = "탄력", first = 0.915962, second = 0.834322, third = 0.752682, fourth = 0.671042, fifth = 0.589402, sixth = 0.507762, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 29, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 34, gubun = "모공", first = 38, second = 43, third = 48, fourth = 58, fifth = 65, sixth = 68, A = 42.2, B = 48.3, C = 0, D = 0, E = 0, F = 0, G = 39.4, H = 39.8, AVG = 42 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 34, gubun = "주름", first = 11.2, second = 14.2, third = 15.8, fourth = 17.8, fifth = 20.6, sixth = 31.2, A = 21.2 , B = 0, C = 15, D = 16.3, E = 18.5, F = 18.4, G = 0, H = 0, AVG = 18 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 34, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 34, gubun = "색소침착", first = 8.8, second = 15.5, third = 18, fourth = 20, fifth = 24.7, sixth = 32.1, A = 15.75, B = 33.625, C = 0, D = 0, E = 15.8125, F = 17.2813, G = 21.9063, H = 22.2813, AVG = 21 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 34, gubun = "멜라닌", first = 3.3, second = 8, third = 10.3, fourth = 11.5, fifth = 15.8, sixth = 39.8, A = 10.2813, B = 20.2188, C = 0, D = 0, E = 10.375, F = 10.9063, G = 12.6875, H = 14.125, AVG = 13 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 34, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 6.36136, B = 16.4833, C = 0, D = 0, E = 6.71818, F = 7.39631, G = 10.0281, H = 10.0361, AVG = 10 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 34, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 34, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 34, gubun = "탄력", first = 0.876296, second = 0.794096, third = 0.711896, fourth = 0.629696, fifth = 0.547496, sixth = 0.465296, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 34, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 39, gubun = "모공", first = 38, second = 43, third = 48, fourth = 58, fifth = 65, sixth = 68, A = 42.2, B = 48.3, C = 0, D = 0, E = 0, F = 0, G = 39.4, H = 39.8, AVG = 42 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 39, gubun = "주름", first = 11.2, second = 14.2, third = 15.8, fourth = 17.8, fifth = 20.6, sixth = 31.2, A = 21.2, B = 0, C = 15, D = 16.3, E = 18.5, F = 18.4, G = 0, H = 0, AVG = 18 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 39, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 39, gubun = "색소침착", first = 8.8, second = 15.5, third = 18, fourth = 20, fifth = 24.7, sixth = 32.1, A = 15.75, B = 33.625, C = 0, D = 0, E = 15.8125, F = 17.2813, G = 21.9063, H = 22.2813, AVG = 21 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 39, gubun = "멜라닌", first = 3.3, second = 8, third = 10.3, fourth = 11.5, fifth = 15.8, sixth = 39.8, A = 10.2813, B = 20.2188, C = 0, D = 0, E = 10.375, F = 10.9063, G = 12.6875, H = 14.125, AVG = 13 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 39, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 6.36136, B = 16.4833, C = 0, D = 0, E = 6.71818, F = 7.39631, G = 10.0281, H = 10.0361, AVG = 10 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 39, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 39, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 39, gubun = "탄력", first = 0.876296, second = 0.794096, third = 0.711896, fourth = 0.629696, fifth = 0.547496, sixth = 0.465296, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 39, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 44, gubun = "모공", first = 42, second = 47, third = 52, fourth = 62, fifth = 67, sixth = 72, A = 58, B = 54, C = 0, D = 0, E = 0, F = 0, G = 58, H = 58, AVG = 57 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 44, gubun = "주름", first = 19, second = 22, third = 25, fourth = 31, fifth = 34, sixth = 37, A = 29, B = 0, C = 27, D = 27, E = 29, F = 29, G = 0, H = 0, AVG = 28.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 44, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 44, gubun = "색소침착", first = 14, second = 19, third = 24, fourth = 34, fifth = 39, sixth = 44, A = 25, B = 35, C = 0, D = 0, E = 22, F = 22, G = 35, H = 35, AVG = 29 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 44, gubun = "멜라닌", first = 14, second = 19, third = 24, fourth = 34, fifth = 39, sixth = 44, A = 30, B = 30, C = 0, D = 0, E = 25, F = 25, G = 32, H = 32, AVG = 29 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 44, gubun = "붉은기", first = 4, second = 7, third = 10, fourth = 16, fifth = 19, sixth = 22, A = 10, B = 18, C = 0, D = 0, E = 9, F = 9, G = 16, H = 16, AVG = 13 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 44, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 44, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 44, gubun = "탄력", first = 0.798059, second = 0.721019, third = 0.643979, fourth = 0.566939, fifth = 0.489899, sixth = 0.412859, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 44, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 49, gubun = "모공", first = 45, second = 50, third = 55, fourth = 65, fifth = 70, sixth = 75, A = 61, B = 57, C = 0, D = 0, E = 0, F = 0, G = 61, H = 61, AVG = 60 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 49, gubun = "주름", first = 20, second = 23, third = 26, fourth = 32, fifth = 35, sixth = 38, A = 29, B = 0, C = 29, D = 29, E = 29, F = 29, G = 0, H = 0, AVG = 29 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 49, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 49, gubun = "색소침착", first = 15, second = 20, third = 25, fourth = 35, fifth = 40, sixth = 45, A = 26, B = 36, C = 0, D = 0, E = 24, F = 24, G = 35, H = 35, AVG = 30 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 49, gubun = "멜라닌", first = 17, second = 22, third = 27, fourth = 37, fifth = 42, sixth = 47, A = 32, B = 34, C = 0, D = 0, E = 27, F = 27, G = 36, H = 36, AVG = 32 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 49, gubun = "붉은기", first = 4, second = 7, third = 10, fourth = 16, fifth = 19, sixth = 22, A = 10, B = 18, C = 0, D = 0, E = 9, F = 9, G = 16, H = 16, AVG = 13 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 49, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 49, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 49, gubun = "탄력", first = 0.798059, second = 0.721019, third = 0.643979, fourth = 0.566939, fifth = 0.489899, sixth = 0.412859, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 49, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 54, gubun = "모공", first = 46, second = 51, third = 56, fourth = 66, fifth = 71, sixth = 76, A = 62, B = 58, C = 0, D = 0, E = 0, F = 0, G = 62, H = 62, AVG = 61 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 54, gubun = "주름", first = 21, second = 24, third = 27, fourth = 33, fifth = 36, sixth = 39, A = 30, B = 0, C = 30, D = 30, E = 30, F = 30, G = 0, H = 0, AVG = 30 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 54, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 54, gubun = "색소침착", first = 17, second = 22, third = 27, fourth = 37, fifth = 42, sixth = 47, A = 27, B = 37, C = 0, D = 0, E = 26, F = 26, G = 38, H = 38, AVG = 32 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 54, gubun = "멜라닌", first = 19, second = 24, third = 29, fourth = 39, fifth = 44, sixth = 49, A = 34, B = 36, C = 0, D = 0, E = 30, F = 30, G = 37, H = 37, AVG = 34 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 54, gubun = "붉은기", first = 4, second = 7, third = 10, fourth = 16, fifth = 19, sixth = 22, A = 10, B = 18, C = 0, D = 0, E = 9, F = 9, G = 16, H = 16, AVG = 13 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 54, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 54, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 54, gubun = "탄력", first = 0.747938, second = 0.675478, third = 0.603018, fourth = 0.530558, fifth = 0.458098, sixth = 0.385638, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 54, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 59, gubun = "모공", first = 48, second = 53, third = 58, fourth = 68, fifth = 73, sixth = 78, A = 65, B = 59, C = 0, D = 0, E = 0, F = 0, G = 64, H = 64, AVG = 63 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 59, gubun = "주름", first = 21, second = 24, third = 27, fourth = 33, fifth = 36, sixth = 39, A = 32, B = 0, C = 30, D = 30, E = 30, F = 30, G = 0, H = 0, AVG = 30.4 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 59, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 59, gubun = "색소침착", first = 19, second = 24, third = 29, fourth = 39, fifth = 44, sixth = 49, A = 29, B = 39, C = 0, D = 0, E = 28, F = 28, G = 40, H = 40, AVG = 34 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 59, gubun = "멜라닌", first = 23, second = 28, third = 33, fourth = 43, fifth = 48, sixth = 53, A = 37, B = 39, C = 0, D = 0, E = 35, F = 35, G = 41, H = 41, AVG = 38 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 59, gubun = "붉은기", first = 4, second = 7, third = 10, fourth = 16, fifth = 19, sixth = 22, A = 10, B = 18, C = 0, D = 0, E = 9, F = 9, G = 16, H = 16, AVG = 13 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 59, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 59, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 59, gubun = "탄력", first = 0.747938, second = 0.675478, third = 0.603018, fourth = 0.530558, fifth = 0.458098, sixth = 0.385638, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 59, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 69, gubun = "모공", first = 50, second = 55, third = 60, fourth = 70, fifth = 75, sixth = 80, A = 69, B = 61, C = 0, D = 0, E = 0, F = 0, G = 65, H = 65, AVG = 65 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 69, gubun = "주름", first = 23, second = 26, third = 29, fourth = 35, fifth = 38, sixth = 41, A = 34, B = 0, C = 31, D = 31, E = 32, F = 32, G = 0, H = 0, AVG = 32 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 69, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 69, gubun = "색소침착", first = 22, second = 27, third = 32, fourth = 42, fifth = 47, sixth = 52, A = 32, B = 40, C = 0, D = 0, E = 33, F = 33, G = 42, H = 42, AVG = 37 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 69, gubun = "멜라닌", first = 26, second = 31, third = 36, fourth = 46, fifth = 51, sixth = 56, A = 41, B = 43, C = 0, D = 0, E = 38, F = 38, G = 43, H = 43, AVG = 41 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 69, gubun = "붉은기", first = 4, second = 7, third = 10, fourth = 16, fifth = 19, sixth = 22, A = 10, B = 18, C = 0, D = 0, E = 9, F = 9, G = 16, H = 16, AVG = 13 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 69, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 69, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 69, gubun = "탄력", first = 0.747938, second = 0.675478, third = 0.603018, fourth = 0.530558, fifth = 0.458098, sixth = 0.385638, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 69, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 70, gubun = "모공", first = 52, second = 57, third = 62, fourth = 72, fifth = 77, sixth = 82, A = 70, B = 62, C = 0, D = 0, E = 0, F = 0, G = 68, H = 68, AVG = 67 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 70, gubun = "주름", first = 25, second = 28, third = 31, fourth = 37, fifth = 40, sixth = 43, A = 36, B = 0, C = 33, D = 33, E = 34, F = 34, G = 0, H = 0, AVG = 34 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 70, gubun = "미래주름", first = 0, second = 2, third = 5, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 70, gubun = "색소침착", first = 26, second = 31, third = 36, fourth = 46, fifth = 51, sixth = 56, A = 36, B = 44, C = 0, D = 0, E = 37, F = 37, G = 46, H = 46, AVG = 41 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 70, gubun = "멜라닌", first = 30, second = 35, third = 40, fourth = 50, fifth = 55, sixth = 60, A = 43, B = 53, C = 0, D = 0, E = 41, F = 41, G = 46, H = 46, AVG = 45 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 70, gubun = "붉은기", first = 4, second = 7, third = 10, fourth = 16, fifth = 19, sixth = 22, A = 10, B = 18, C = 0, D = 0, E = 9, F = 9, G = 16, H = 16, AVG = 13 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 70, gubun = "포피린", first = 14, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 39, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 70, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 70, gubun = "탄력", first = 0.747938, second = 0.675478, third = 0.603018, fourth = 0.530558, fifth = 0.458098, sixth = 0.385638, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "M", age = 70, gubun = "경피수분손실도", first = 8.85, second = 12.40, third = 14.00, fourth = 17.40, fifth = 21.00, sixth = 39.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 19, gubun = "모공", first = 25, second = 29, third = 33, fourth = 41, fifth = 45, sixth = 49, A = 33.5, B = 39, C = 0, D = 0, E = 0, F = 0, G = 26.8, H = 27.3, AVG = 31.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 19, gubun = "주름", first = 7.4, second = 11, third = 12, fourth = 13.6, fifth = 15.6, sixth = 19.4, A = 16.8, B = 0, C = 10.2, D = 10.9, E = 14.5, F = 14.7, G = 0, H = 0, AVG = 13.4 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 19, gubun = "미래주름", first = 1, second = 4, third = 7, fourth = 13, fifth = 16, sixth = 19, A = 9, B = 0, C = 0, D = 0, E = 10, F = 10, G = 11, H = 11, AVG = 10.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 19, gubun = "색소침착", first = 3.8, second = 11.3, third = 14, fourth = 17, fifth = 21.2, sixth = 34, A = 13.6, B = 23.7, C = 0, D = 0, E = 12.3, F = 12.7, G = 16.1, H = 16, AVG = 15.7 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 19, gubun = "멜라닌", first = 1.2, second = 4.8, third = 6.2, fourth = 7.7, fifth = 10.8, sixth = 20.2, A = 7.3, B = 0, C = 0, D = 0, E = 0, F = 0, G = 7.6, H = 7.9, AVG = 7.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 19, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 3.5, B = 9.8, C = 0, D = 0, E = 3.9, F = 4.2, G = 6, H = 6.1, AVG = 5.1 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 19, gubun = "포피린", first = 0, second = 5, third = 15, fourth = 30, fifth = 45, sixth = 50, A = 11, B = 19, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 19, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 19, gubun = "탄력", first = 1.053344, second = 0.939084, third = 0.824824, fourth = 0.710564, fifth = 0.596304, sixth = 0.482044, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 19, gubun = "경피수분손실도", first = 7.10, second = 9.15, third = 11.35, fourth = 14.25, fifth = 16.75, sixth = 32.10, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 24, gubun = "모공", first = 25, second = 29, third = 33, fourth = 41, fifth = 45, sixth = 49, A = 33.5, B = 39, C = 0, D = 0, E = 0, F = 0, G = 26.8, H = 27.3, AVG = 31.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 24, gubun = "주름", first = 7.4, second = 11, third = 12, fourth = 13.6, fifth = 15.6, sixth = 19.4, A = 16.8, B = 0, C = 10.2, D = 10.9, E = 14.5, F = 14.7, G = 0, H = 0, AVG = 13.4 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 24, gubun = "미래주름", first = 1, second = 4, third = 7, fourth = 13, fifth = 16, sixth = 19, A = 9, B = 0, C = 0, D = 0, E = 10, F = 10, G = 11, H = 11, AVG = 10.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 24, gubun = "색소침착", first = 3.8, second = 11.3, third = 14, fourth = 17, fifth = 21.2, sixth = 34, A = 13.6, B = 23.7, C = 0, D = 0, E = 12.3, F = 12.7, G = 16.1, H = 16, AVG = 15.7 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 24, gubun = "멜라닌", first = 1.2, second = 4.8, third = 6.2, fourth = 7.7, fifth = 10.8, sixth = 20.2, A = 7.3, B = 0, C = 0, D = 0, E = 0, F = 0, G = 7.6, H = 7.9, AVG = 7.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 24, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 3.5, B = 9.8, C = 0, D = 0, E = 3.9, F = 4.2, G = 6, H = 6.1, AVG = 5.1 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 24, gubun = "포피린", first = 0, second = 5, third = 15, fourth = 30, fifth = 45, sixth = 50, A = 11, B = 19, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 24, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 24, gubun = "탄력", first = 1.053344, second = 0.939084, third = 0.824824, fourth = 0.710564, fifth = 0.596304, sixth = 0.482044, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 24, gubun = "경피수분손실도", first = 7.10, second = 9.15, third = 11.35, fourth = 14.25, fifth = 16.75, sixth = 32.10, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 29, gubun = "모공", first = 25, second = 29, third = 33, fourth = 41, fifth = 45, sixth = 49, A = 33.5, B = 39, C = 0, D = 0, E = 0, F = 0, G = 26.8, H = 27.3, AVG = 31.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 29, gubun = "주름", first = 7.4, second = 11, third = 12, fourth = 13.6, fifth = 15.6, sixth = 19.4, A = 16.8, B = 0, C = 10.2, D = 10.9, E = 14.5, F = 14.7, G = 0, H = 0, AVG = 13.4 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 29, gubun = "미래주름", first = 1, second = 4, third = 7, fourth = 13, fifth = 16, sixth = 19, A = 9, B = 0, C = 0, D = 0, E = 10, F = 10, G = 11, H = 11, AVG = 10.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 29, gubun = "색소침착", first = 3.8, second = 11.3, third = 14, fourth = 17, fifth = 21.2, sixth = 34, A = 13.6, B = 23.7, C = 0, D = 0, E = 12.3, F = 12.7, G = 16.1, H = 16, AVG = 15.7 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 29, gubun = "멜라닌", first = 1.2, second = 4.8, third = 6.2, fourth = 7.7, fifth = 10.8, sixth = 20.2, A = 7.3, B = 0, C = 0, D = 0, E = 0, F = 0, G = 7.6, H = 7.9, AVG = 7.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 29, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 3.5, B = 9.8, C = 0, D = 0, E = 3.9, F = 4.2, G = 6, H = 6.1, AVG = 5.1 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 29, gubun = "포피린", first = 0, second = 5, third = 15, fourth = 30, fifth = 45, sixth = 50, A = 11, B = 19, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 29, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 29, gubun = "탄력", first = 1.053344, second = 0.939084, third = 0.824824, fourth = 0.710564, fifth = 0.596304, sixth = 0.482044, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 29, gubun = "경피수분손실도", first = 7.10, second = 9.15, third = 11.35, fourth = 14.25, fifth = 16.75, sixth = 32.10, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 34, gubun = "모공", first = 29, second = 33, third = 37, fourth = 45, fifth = 49, sixth = 53, A = 36.1, B = 40.1, C = 0, D = 0, E = 0, F = 0, G = 31.9, H = 32.2, AVG = 35.1 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 34, gubun = "주름", first = 7.6, second = 12.2, third = 13.8, fourth = 15.2, fifth = 17, sixth = 26.8, A = 18, B = 0, C = 11.6, D = 12.6, E = 15.9, F = 16.1, G = 0, H = 0, AVG = 14.8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 34, gubun = "미래주름", first = 1, second = 4, third = 7, fourth = 13, fifth = 16, sixth = 19, A = 9, B = 0, C = 0, D = 0, E = 10, F = 10, G = 11, H = 11, AVG = 10.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 34, gubun = "색소침착", first = 4.3, second = 13.3, third = 15.8, fourth = 18.5, fifth = 22, sixth = 36.8, A = 14.5, B = 25.9, C = 0, D = 0, E = 13.6, F = 14.4, G = 18.5, H = 18.7, AVG = 17.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 34, gubun = "멜라닌", first = 2, second = 6, third = 7.8, fourth = 9.5, fifth = 12.3, sixth = 30.8, A = 7.3, B = 0, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9.8, AVG = 8.7 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 34, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 3.5, B = 9.8, C = 0, D = 0, E = 3.9, F = 4.2, G = 6, H = 6.1, AVG = 5.3 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 34, gubun = "포피린", first = 0, second = 5, third = 15, fourth = 30, fifth = 45, sixth = 50, A = 11, B = 19, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 34, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 34, gubun = "탄력", first = 0.917858, second = 0.836938, third = 0.756018, fourth = 0.675098, fifth = 0.594178, sixth = 0.513258, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 34, gubun = "경피수분손실도", first = 6.15, second = 9.35, third = 11.60, fourth = 13.00, fifth = 15.70, sixth = 29.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 39, gubun = "모공", first = 31, second = 35, third = 39, fourth = 47, fifth = 51, sixth = 55, A = 37, B = 42.4, C = 0, D = 0, E = 0, F = 0, G = 33.3, H = 34, AVG = 36.7 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 39, gubun = "주름", first = 8.4, second = 13.6, third = 14.8, fourth = 16, fifth = 17.4, sixth = 28.2, A = 18.6, B = 0, C = 12.9, D = 14, E = 16.7, F = 17.1, G = 0, H = 0, AVG = 15.8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 39, gubun = "미래주름", first = 1, second = 4, third = 7, fourth = 13, fifth = 16, sixth = 19, A = 9, B = 0, C = 0, D = 0, E = 10, F = 10, G = 11, H = 11, AVG = 10.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 39, gubun = "색소침착", first = 7, second = 14.2, third = 16.8, fourth = 20.2, fifth = 23.5, sixth = 36.7, A = 15.3, B = 26.8, C = 0, D = 0, E = 15.5, F = 15.5, G = 19.7, H = 19.6, AVG = 18.7 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 39, gubun = "멜라닌", first = 2.2, second = 7.3, third = 8.8, fourth = 11.3, fifth = 14.3, sixth = 30.2, A = 8.1, B = 0, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10.8, AVG = 9.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 39, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 3.5, B = 9.8, C = 0, D = 0, E = 3.9, F = 4.2, G = 6, H = 6.1, AVG = 5.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 39, gubun = "포피린", first = 0, second = 5, third = 15, fourth = 30, fifth = 45, sixth = 50, A = 11, B = 19, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 39, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 39, gubun = "탄력", first = 0.917858, second = 0.836938, third = 0.756018, fourth = 0.675098, fifth = 0.594178, sixth = 0.513258, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 39, gubun = "경피수분손실도", first = 6.15, second = 9.35, third = 11.60, fourth = 13.00, fifth = 15.70, sixth = 29.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 44, gubun = "모공", first = 34, second = 38, third = 42, fourth = 50, fifth = 54, sixth = 58, A = 39.3, B = 44.6, C = 0, D = 0, E = 0, F = 0, G = 34.8, H = 35.2, AVG = 38.5 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 44, gubun = "주름", first = 8, second = 14.8, third = 15.6, fourth = 17.4, fifth = 20.2, sixth = 24, A = 19.7, B = 0, C = 14.9, D = 15.1, E = 18.3, F = 18.4, G = 0, H = 0, AVG = 17.3 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 44, gubun = "미래주름", first = 1, second = 4, third = 7, fourth = 13, fifth = 16, sixth = 19, A = 9, B = 0, C = 0, D = 0, E = 10, F = 10, G = 11, H = 11, AVG = 10.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 44, gubun = "색소침착", first = 5.6, second = 15.2, third = 17.3, fourth = 20.5, fifth = 23.3, sixth = 40.8, A = 16.6, B = 29.1, C = 0, D = 0, E = 16, F = 16.2, G = 19.4, H = 19.5, AVG = 19.5 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 44, gubun = "멜라닌", first = 3.3, second = 8.5, third = 11.2, fourth = 13.3, fifth = 15.8, sixth = 30.2, A = 8.4, B = 0, C = 0, D = 0, E = 0, F = 0, G = 11.7, H = 12.2, AVG = 10.8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 44, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 3.5, B = 9.8, C = 0, D = 0, E = 3.9, F = 4.2, G = 6, H = 6.1, AVG = 5.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 44, gubun = "포피린", first = 0, second = 5, third = 15, fourth = 30, fifth = 45, sixth = 50, A = 11, B = 19, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 44, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 44, gubun = "탄력", first = 0.876296, second = 0.794096, third = 0.711896, fourth = 0.629696, fifth = 0.547496, sixth = 0.465296, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 44, gubun = "경피수분손실도", first = 6.15, second = 9.35, third = 11.60, fourth = 13.00, fifth = 15.70, sixth = 29.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 49, gubun = "모공", first = 36, second = 40, third = 44, fourth = 52, fifth = 56, sixth = 60, A = 43.9, B = 46, C = 0, D = 0, E = 0, F = 0, G = 38.5, H = 38.9, AVG = 41.8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 49, gubun = "주름", first = 16, second = 16.8, third = 17.8, fourth = 18.4, fifth = 20.6, sixth = 26.4, A = 21.9, B = 0, C = 16.6, D = 17.1, E = 18.4, F = 18.8, G = 0, H = 0, AVG = 18.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 49, gubun = "미래주름", first = 1, second = 4, third = 7, fourth = 13, fifth = 16, sixth = 19, A = 9, B = 0, C = 0, D = 0, E = 10, F = 10, G = 11, H = 11, AVG = 10.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 49, gubun = "색소침착", first = 13.2, second = 16.2, third = 17.8, fourth = 20.5, fifth = 23.8, sixth = 37.7, A = 17.2, B = 31, C = 0, D = 0, E = 16.9, F = 17.4, G = 20.8, H = 20.8, AVG = 20.7 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 49, gubun = "멜라닌", first = 8, second = 9.7, third = 11.3, fourth = 15.2, fifth = 18.5, sixth = 24.5, A = 9.2, B = 0, C = 0, D = 0, E = 0, F = 0, G = 13.4, H = 14, AVG = 12.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 49, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 3.5, B = 9.8, C = 0, D = 0, E = 3.9, F = 4.2, G = 6, H = 6.1, AVG = 6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 49, gubun = "포피린", first = 0, second = 5, third = 15, fourth = 30, fifth = 45, sixth = 50, A = 11, B = 19, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 49, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 49, gubun = "탄력", first = 0.876296, second = 0.794096, third = 0.711896, fourth = 0.629696, fifth = 0.547496, sixth = 0.465296, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 49, gubun = "경피수분손실도", first = 6.15, second = 9.35, third = 11.60, fourth = 13.00, fifth = 15.70, sixth = 29.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 54, gubun = "모공", first = 41, second = 45, third = 49, fourth = 57, fifth = 61, sixth = 65, A = 46.3, B = 52.1, C = 0, D = 0, E = 0, F = 0, G = 46.1, H = 45.1, AVG = 47.4 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 54, gubun = "주름", first = 14.4, second = 17.6, third = 19.6, fourth = 21.8, fifth = 23.8, sixth = 25.6, A = 23.1, B = 0, C = 17.6, D = 19.4, E = 22.3, F = 21.9, G = 0, H = 0, AVG = 20.9 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 54, gubun = "미래주름", first = 1, second = 4, third = 7, fourth = 13, fifth = 16, sixth = 19, A = 9, B = 0, C = 0, D = 0, E = 10, F = 10, G = 11, H = 11, AVG = 10.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 54, gubun = "색소침착", first = 14.5, second = 19.8, third = 22.8, fourth = 28.2, fifth = 29.5, sixth = 35.3, A = 19.1, B = 35.2, C = 0, D = 0, E = 22.5, F = 23.3, G = 26, H = 27, AVG = 25.5 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 54, gubun = "멜라닌", first = 10.5, second = 13.5, third = 17.8, fourth = 21.5, fifth = 25, sixth = 33.5, A = 11.3, B = 0, C = 0, D = 0, E = 0, F = 0, G = 18.4, H = 19.4, AVG = 16.4 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 54, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 3.5, B = 9.8, C = 0, D = 0, E = 3.9, F = 4.2, G = 6, H = 6.1, AVG = 5.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 54, gubun = "포피린", first = 0, second = 5, third = 15, fourth = 30, fifth = 45, sixth = 50, A = 11, B = 19, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 54, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 54, gubun = "탄력", first = 0.795516, second = 0.729396, third = 0.663276, fourth = 0.597156, fifth = 0.531036, sixth = 0.464916, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 54, gubun = "경피수분손실도", first = 6.15, second = 9.35, third = 11.60, fourth = 13.00, fifth = 15.70, sixth = 29.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 59, gubun = "모공", first = 41, second = 45, third = 49, fourth = 57, fifth = 61, sixth = 65, A = 46.3, B = 52.1, C = 0, D = 0, E = 0, F = 0, G = 46.1, H = 45.1, AVG = 47.4 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 59, gubun = "주름", first = 14.4, second = 17.6, third = 19.6, fourth = 21.8, fifth = 23.8, sixth = 25.6, A = 23.1, B = 0, C = 17.6, D = 19.4, E = 22.3, F = 21.9, G = 0, H = 0, AVG = 20.9 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 59, gubun = "미래주름", first = 1, second = 4, third = 7, fourth = 13, fifth = 16, sixth = 19, A = 9, B = 0, C = 0, D = 0, E = 10, F = 10, G = 11, H = 11, AVG = 10.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 59, gubun = "색소침착", first = 14.5, second = 19.8, third = 22.8, fourth = 28.2, fifth = 29.5, sixth = 35.3, A = 19.1, B = 35.2, C = 0, D = 0, E = 22.5, F = 23.3, G = 26, H = 27, AVG = 25.5 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 59, gubun = "멜라닌", first = 10.5, second = 13.5, third = 17.8, fourth = 21.5, fifth = 25, sixth = 33.5, A = 11.3, B = 0, C = 0, D = 0, E = 0, F = 0, G = 18.4, H = 19.4, AVG = 16.4 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 59, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 3.5, B = 9.8, C = 0, D = 0, E = 3.9, F = 4.2, G = 6, H = 6.1, AVG = 5.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 59, gubun = "포피린", first = 0, second = 5, third = 15, fourth = 30, fifth = 45, sixth = 50, A = 11, B = 19, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 59, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 59, gubun = "탄력", first = 0.795516, second = 0.729396, third = 0.663276, fourth = 0.597156, fifth = 0.531036, sixth = 0.464916, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 59, gubun = "경피수분손실도", first = 6.15, second = 9.35, third = 11.60, fourth = 13.00, fifth = 15.70, sixth = 29.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 69, gubun = "모공", first = 41, second = 45, third = 49, fourth = 57, fifth = 61, sixth = 65, A = 46.3, B = 52.1, C = 0, D = 0, E = 0, F = 0, G = 46.1, H = 45.1, AVG = 47.4 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 69, gubun = "주름", first = 14.4, second = 17.6, third = 19.6, fourth = 21.8, fifth = 23.8, sixth = 25.6, A = 23.1, B = 0, C = 17.6, D = 19.4, E = 22.3, F = 21.9, G = 0, H = 0, AVG = 20.9 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 69, gubun = "미래주름", first = 1, second = 4, third = 7, fourth = 13, fifth = 16, sixth = 19, A = 9, B = 0, C = 0, D = 0, E = 10, F = 10, G = 11, H = 11, AVG = 10.2 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 69, gubun = "색소침착", first = 14.5, second = 19.8, third = 22.8, fourth = 28.2, fifth = 29.5, sixth = 35.3, A = 19.1, B = 35.2, C = 0, D = 0, E = 22.5, F = 23.3, G = 26, H = 27, AVG = 25.5 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 69, gubun = "멜라닌", first = 10.5, second = 13.5, third = 17.8, fourth = 21.5, fifth = 25, sixth = 33.5, A = 11.3, B = 0, C = 0, D = 0, E = 0, F = 0, G = 18.4, H = 19.4, AVG = 16.4 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 69, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 3.5, B = 9.8, C = 0, D = 0, E = 3.9, F = 4.2, G = 6, H = 6.1, AVG = 5.6 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 69, gubun = "포피린", first = 0, second = 5, third = 15, fourth = 30, fifth = 45, sixth = 50, A = 11, B = 19, C = 0, D = 0, E = 0, F = 0, G = 9, H = 9, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 69, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 69, gubun = "탄력", first = 0.795516, second = 0.729396, third = 0.663276, fourth = 0.597156, fifth = 0.531036, sixth = 0.464916, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 69, gubun = "경피수분손실도", first = 6.15, second = 9.35, third = 11.60, fourth = 13.00, fifth = 15.70, sixth = 29.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 70, gubun = "모공", first = 55, second = 60, third = 65, fourth = 70, fifth = 75, sixth = 80, A = 69, B = 61, C = 0, D = 0, E = 0, F = 0, G = 65, H = 65, AVG = 65 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 70, gubun = "주름", first = 26, second = 29, third = 32, fourth = 35, fifth = 38, sixth = 41, A = 34, B = 0, C = 31, D = 31, E = 32, F = 32, G = 0, H = 0, AVG = 32 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 70, gubun = "미래주름", first = 2, second = 5, third = 8, fourth = 11, fifth = 14, sixth = 17, A = 8, B = 0, C = 0, D = 0, E = 7, F = 7, G = 9, H = 9, AVG = 8 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 70, gubun = "색소침착", first = 27, second = 32, third = 37, fourth = 42, fifth = 47, sixth = 52, A = 32, B = 40, C = 0, D = 0, E = 33, F = 33, G = 42, H = 42, AVG = 37 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 70, gubun = "멜라닌", first = 31, second = 36, third = 41, fourth = 46, fifth = 51, sixth = 56, A = 41, B = 0, C = 0, D = 0, E = 0, F = 0, G = 43, H = 43, AVG = 42.3 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 70, gubun = "붉은기", first = 1.8, second = 3.6, third = 5.4, fourth = 7.2, fifth = 11, sixth = 12.8, A = 10, B = 18, C = 0, D = 0, E = 9, F = 9, G = 16, H = 16, AVG = 13 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 70, gubun = "포피린", first = 0, second = 18, third = 22, fourth = 29, fifth = 35, sixth = 50, A = 10, B = 18, C = 0, D = 0, E = 0, F = 0, G = 10, H = 10, AVG = 12 });
            //list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 70, gubun = "다크서클", first = 0, second = 1.5, third = 3, fourth = 4, fifth = 5, sixth = 7, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 70, gubun = "탄력", first = 0.795516, second = 0.729396, third = 0.663276, fourth = 0.597156, fifth = 0.531036, sixth = 0.464916, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });
            list_rce.Add(new Result_Concern_Entity() { gender = "F", age = 70, gubun = "경피수분손실도", first = 6.15, second = 9.35, third = 11.60, fourth = 13.00, fifth = 15.70, sixth = 29.30, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, AVG = 0 });

            //Result_Sensitive_Entity
            list_rse.Add(new Result_Sensitive_Entity() { s_type = "S0", s_type_name = "건강한 피부", s_result = "일상 생활 습관, 계절 또는 환경 변화 등에 반응성이 적은 건강한 피부 입니다." });
            list_rse.Add(new Result_Sensitive_Entity() { s_type = "S1", s_type_name = "가벼운 민감성", s_result = "일상 생활 습관, 계절 또는 환경 변화 등에 간지러운 것 같은 느낌 혹은 오돌도돌 피부가 거칠고 건조한 느낌을 가끔씩 받을 수 있습니다." });
            list_rse.Add(new Result_Sensitive_Entity() { s_type = "S2", s_type_name = "지복합 민감", s_result = "일상 생활 습관, 계절 또는 환경 변화 등에 의해 트러블이 자주 생기며 종종 가려움 혹은 속건조등이 동반됩니다." });
            list_rse.Add(new Result_Sensitive_Entity() { s_type = "S3", s_type_name = "건성 민감", s_result = "일상 생활 습관, 계절 또는 환경 변화 등에 의해 자주 가렵고 따가움을 느끼며, 각질 부각과 트러블이 발생할 수 있습니다." });
            list_rse.Add(new Result_Sensitive_Entity() { s_type = "S4", s_type_name = "붉은기 민감", s_result = "일상 생활 습관, 계절 또는 환경 변화 등에 의해 자주 화끈거리고 붉어질 수 있습니다." });

            //Result_Soultion_Entity
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "1"
    ,
                s_type_gomin = "건성 / 안티에이징 고민(주름 & 탄력)"
    ,
                s_result = @"각질층 수분량이 부족하여 건조한 피부입니다.

탄력섬유인 콜라겐과 엘라스틴이 노화로 인해 감소되면서 주름이 생성되거나 탄력이 저하 될 수 있습니다."
    ,
                s_beauty_tip = @"- 너무 과도한 세안은 피하고, 미온수로 세안하는 것이 좋습니다.

- 세안 후 건조한상태로 장시간 방치하기 보다는 바로 스킨케어 제품을 바르는것이 중요합니다.

- 스킨케어 시 탄력 전용 제품을 사용하고, 다른 곳에 비해 눈가 잔주름이 빨리 나타나므로 눈가 전용 제품 사용을 추천합니다."
            });

            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "2"
                ,
                s_type_gomin = "건성 / 미백고민(칙칙함 & 색소침착)"
                ,
                s_result = @"각질층 수분량이 부족하여 건조한 피부입니다.

자외선 노출 시 멜라닌 색소세포의 자극으로 균일하지 않은 피부톤을 가질 수 있습니다."
                ,
                s_beauty_tip = @"- 매일 6잔(1.5L) 이상의 충분한 수분을 섭취하고 적절한 수분 상태를 유지하며, 충분한 수면을 통해 피로가 쌓이지 않도록 하는것이 좋습니다.

- 피부가 건조하면 잡티가 생기기 쉬우므로 고보습제품으로 유수분을 충분히 채워주고 미백제품을 통해 기미와 집티를 꾸준히 관리해 줍니다.

- 기미와 잡티가 진해지는것을 예방하기 위해 자외선차단제를 반드시 4계절 사용하는것이 중요합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "3"
                ,
                s_type_gomin = "건성 / 안티에이징 & 미백고민"
                ,
                s_result = @"각질층 수분량이 부족하여 건조한 피부입니다.

자외선이 지속적으로 피부에 노출되면 콜라겐이 손상되어 주름을 증가시키고, 멜라닌 색소세포의 자극으로 균일하지 않은 피부톤을 가질 수 있습니다."
                ,
                s_beauty_tip = @"- 수분을 빼앗는 흡연이나 음주, 카페인 섭취는 줄이고 생선 등 콜라겐이 함유되어 있는 음식이나 항산화성분이 많이 함유된 식품을 섭취하는 것이 좋습니다.

- 피부 탄력 유지에 중요한 역할을 하는 콜라겐,엘라스틴을 강화하는 탄력 전용 제품 사용을 추천합니다.

- 주름이 생성되고 색소침착이 진해지는것을 예방하기위해 자외선차단제를 반드시 4계절 사용하는것이 중요합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "4"
                ,
                s_type_gomin = "건성 / 고민없음"
                ,
                s_result = @"각질층 수분량이 부족하여 건조한 피부입니다. 

모공이 대체적으로 작은편이며, 각질 턴오버가 원활하지 않아 거친 피부결을 가질 수 있습니다."
,
                s_beauty_tip = @"- 수분을 빼앗는 흡연이나 음주, 카페인 섭취는 줄이고 생선 등 콜라겐이 함유되어 있는 음식이나 항산화성분이 많이 함유된 식품을 섭취하는 것이 좋습니다.

- 세안 후 건조한상태로 장시간 방치하기 보다는 바로 스킨케어 제품을 바르는것이 중요합니다.

- 건조한 피부환경은 잔주름을 빨리 유발하므로 유수분 공급을 충분히 할 수 있는 기초제품과 함께 안티에이징 제품을 꾸준히 사용하여 노화를 예방하는것을 추천합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "5"
                ,
                s_type_gomin = "지성 / 안티에이징고민(주름 & 탄력)"
                ,
                s_result = @"피지가 과도하게 분비되는 피부입니다.

과도한 피지로 모공이 넓어질 수 있으며, 콜라겐과 엘라스틴이 감소됨에 따라서 넓어진 모공도 주름처럼 변화 할 수 있습니다."
,
                s_beauty_tip = @"- 클렌징시 모공이 발달되어있는 부분은 한번 더 롤링하여 꼼꼼한 세안으로 과잉피지를 깨끗하게 제거하는 것이 좋습니다. 

- 수분을 빼앗는 흡연이나 음주, 카페인 섭취는 줄이고 생선 등 콜라겐이 함유되어 있는 음식이나 항산화성분이 많이 함유된 식품을 섭취하는 것이 좋습니다.

- 주름이 생성되지 않도록 자외선을 철저히 차단해 줍니다. 따라서 자외선차단제를 반드시 4계절 사용하는것이 중요합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "6"
                ,
                s_type_gomin = "지성 / 미백고민(칙칙함 & 색소침착)"
                ,
                s_result = @"자외선이 지속적으로 피부에 노출 될 경우 멜라닌 색소세포가 생성되어 피부톤이 균일하지 않을 수 있으며, 열감으로 인하여 피지분비가 촉진 될 수 있습니다.

각질이나 피지가 뒤엉켜 잘못 된 케어를 진행하였을때 피부에 흔적으로 남을 수 있습니다."
,
                s_beauty_tip = @"- 클렌징시 모공이 발달되어있는 부분은 한번 더 롤링을하여 꼼꼼한 세안으로 과잉피지를 깨끗하게 제거하는 것이 좋습니다. 

- 기미와 잡티가 진해지는것을 예방하기 위해 자외선차단제를 반드시 4계절 사용하는것이 중요합니다.

- 칙칙함과 색소침착을 케어하기 위한 미백 기능의 고기능성 에센스와 크림으로 지속적인 관리를 추천합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "7"
                ,
                s_type_gomin = "지성 / 안티에이징 & 미백고민"
                ,
                s_result = @"과도한 피지분비로 인해 노화속도는 느린편입니다.

자외선이 지속적으로 피부에 노출 될 경우 콜라겐이 손상되어 주름이 증가하거나, 색소침착이 발생될 수 있습니다."
,
                s_beauty_tip = @"- 클렌징시 모공이 발달되어있는 부분은 한번 더 롤링을하여 꼼꼼한 세안으로 과잉피지를 깨끗하게 제거하는 것이 좋습니다. 

- 주름이 생성되거나 색소침착이 진해지는것을 예방하기위해 자외선차단제를 반드시 4계절 사용하는것이 중요합니다.

- 피부를 맑게하는 비타민 C와 비타민 A(당근. 양배추, 시금치, 호박 등)등 항산화성분이 많이 함유된 식품의 섭취를 추천합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "8"
                ,
                s_type_gomin = "지성 / 고민없음"
                ,
                s_result = @"산화된 피지가 각질세포의 턴오버를 저하시켜 피부가 탁해보일 수 있습니다.

좁은 모공으로 많은 양의 피지가 원활하게 분비되지 못할 경우 피부의 문제점이 야기 될 수 있습니다."
,
                s_beauty_tip = @"- 클렌징시 모공이 발달되어있는 부분은 한번 더 롤링을하여 꼼꼼한 세안으로 과잉피지를 깨끗하게 제거하는 것이 좋습니다.

- 세포산화와 피지분비를 촉진하는 맵거나 기름진 음식, 지나치게 단 음식은 피하는것을 추천합니다.

- 매일 6잔(1.5L) 이상의 충분한 수분을 섭취하고 충분한 수면을 통해 피로가 쌓이지 않도록 하는것이 좋습니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "9"
                ,
                s_type_gomin = "중성 / 안티에이징고민(주름 & 탄력)"
                ,
                s_result = @"유수분 발란스가 좋은 피부 입니다.

자외선은 콜라겐을 손상시켜 주름이 생성될 수 있으며, 수분이 감소하게 되면 엘라스틴에 영향을 미칠 수 있습니다.

계절이나 환경의 변화에 케어하는 습관이 필요합니다."
,
                s_beauty_tip = @"- 유 수분이 균형을 이루는 현재 피부 상태를 유지할 수 있도록 매일 6잔(1.5L) 이상의 충분한 수분을 섭취하고, 적절한 실내 습도를 유지하는것이 좋습니다.

- 주름을 생성하게 하는 자외선을 철저히 차단하기 위해 자외선차단제를 반드시 4계절 사용하는것이 중요합니다.

- 스킨케어 시 탄력 전용 제품을 꼭 발라주고, 다른 곳에 비해 눈가 잔주름이 빨리 나타나므로 눈가 전용 제품 사용을 추천합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "10"
                ,
                s_type_gomin = "중성 / 미백고민(칙칙함 & 색소침착)"
                ,
                s_result = @"유수분 발란스가 좋은 피부 입니다.

건조한 피부일 경우 피부 장벽이 약화되어 자외선의 자극으로 색소침착이 생성 될 수 있습니다.

전체적으로 칙칙한 피부일경우 스트레스, 외부자극, 묵은각질등이 원인일 수 있습니다."
,
                s_beauty_tip = @"- 유 수분이 균형을 이루는 현재 피부 상태를 유지할 수 있도록 매일 6잔(1.5L) 이상의 충분한 수분을 섭취하고, 적절한 실내 습도를 유지하는것이 좋습니다.

- 기미와 잡티가 진해지는것을 예방하기 위해 자외선차단제를 반드시 4계절 사용하는것이 중요합니다.

- 피부를 맑게하는 비타민 C(딸기, 파프리카, 키위 등)와 비타민 A(당근. 양배추, 시금치, 호박 등)등 항산화성분이 많이 함유된 식품의 섭취를 추천합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "11"
                ,
                s_type_gomin = "중성 / 안티에이징 & 미백고민"
                ,
                s_result = @"유수분 발란스가 좋은 피부 입니다.

지속적인 자외선 노출 시 콜라겐 손상으로 주름이 생성되거나, 멜라닌 색소세포가 생성 될 수 있습니다."
,
                s_beauty_tip = @"- 유 수분이 균형을 이루는 현재 피부 상태를 유지할 수 있도록 매일 6잔(1.5L) 이상의 충분한 수분을 섭취하고, 적절한 실내 습도를 유지하는것이 좋습니다.

- 주름을 생성시키고 색소침착이 진해지는것을 예방하기위해 자외선차단제를 반드시 4계절 사용하는것이 중요합니다.

- 건조한 피부환경은 잔주름을 빨리 유발하므로 유수분 공급을 충분히 할 수 있는 기초제품과 함께 안티에이징 제품을 꾸준히 사용하여 노화를 예방하는것을 추천합니다. "
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "12"
                ,
                s_type_gomin = "중성 / 고민없음"
                ,
                s_result = @"유수분 발란스가 좋은 피부 입니다.

피부가 당기는 부분이 없고 피부 장벽 기능 또한 좋은 건강한 피부 입니다."
,
                s_beauty_tip = @"- 유 수분이 균형을 이루는 현재 피부 상태를 유지할 수 있도록 매일 6잔(1.5L) 이상의 충분한 수분을 섭취하고, 적절한 실내 습도를 유지하는것이 좋습니다.

- 수분을 빼앗는 흡연이나 음주, 카페인 섭취는 줄이고 생선 등 콜라겐이 함유되어 있는 음식이나 항산화성분이 많이 함유된 식품을 섭취하는 것이 중요합니다.

- 세안 후 건조한상태로 장시간 방치하기 보다는 바로 스킨케어 제품을 바르는것이 중요합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "13"
                ,
                s_type_gomin = "복합성 / 안티에이징고민(주름 & 탄력)"
                ,
                s_result = @"피부가 건조한 부분은 잔주름이 발생될 가능성이 높습니다.

건조한 피부에서는 엘라스틴에 영향을 미칠 수 있습니다.탄력감소와 주름이 생성될 수 있습니다."
,
                s_beauty_tip = @"- 클렌징시 모공이 발달되어있는 부분은 한번 더 롤링하여 꼼꼼한 세안으로 과잉피지를 깨끗하게 제거하는 것이 좋습니다.

- 주름을 생성시키고 색소침착이 진해지는것을 예방하기위해 자외선차단제를 반드시 4계절 사용하는것이 중요합니다.

- 스킨케어 시 탄력 전용 제품을 꼭 발라주고, 다른 곳에 비해 눈가 잔주름이 빨리 나타나므로 눈가 전용 제품 사용을 추천합니다"
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "14"
                ,
                s_type_gomin = "복합성 / 미백고민(칙칙함 & 색소침착)"
                ,
                s_result = @"피부가 건조한 부분은 피부 보호막이 잘 유지되지않아 외부 자극에 쉽게 칙칙해 질 수 있습니다.

피지분비가 과도한 부분은 과도한 피지와 각질로 인해 피부톤이 균일하지 않게 보일 수 있습니다."
,
                s_beauty_tip = @"- 클렌징시 모공이 발달되어있는 부분은 한번 더 롤링하여 꼼꼼한 세안으로 과잉피지를 깨끗하게 제거하는 것이 좋습니다.

- 피부가 건조하면 잡티가 생기기 쉬우므로 고보습제품으로 유수분을 충분히 채워주고 미백제품을 통해 기미와 집티를 꾸준히 관리를 추천합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "15"
                ,
                s_type_gomin = "복합성 / 안티에이징 & 미백고민"
                ,
                s_result = @"수분이 부족한 부분은 엘라스틴에 영향을 미칠 수 있습니다.

탄력감소와 주름 생성이 진행 될 수 있습니다.

건조한 피부 부위는 피부 보호막의 기능이 약해 색소침착이 쉽게 생성 될 수 있습니다.

피지분비가 많은 피부 부위는 과도한 각질과 뒤엉킴으로 피부가 칙칙해 보일 수 있습니다."
,
                s_beauty_tip = @"- 클렌징시 모공이 발달되어있는 부분은 한번 더 롤링하여 꼼꼼한 세안으로 과잉피지를 깨끗하게 제거하는 것이 좋습니다. 

- 주름을 생성시키고 색소침착이 진해지는것을 예방하기위해 자외선차단제를 반드시 4계절 사용하는것이 중요합니다.

- 기미와 잡티가 진해지는것을 예방하기 위해 자외선차단제를 반드시 4계절 사용하는것을 추천합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "16"
                ,
                s_type_gomin = "복합성 / 고민없음"
                ,
                s_result = @"피부결이 전체적으로 고르지 못해 보일 수 있습니다.

외부 환경의 변화에 따라서 피부 부위별 유수분 발란스 차이가 발생될 수 있습니다."
,
                s_beauty_tip = @"- 클렌징시 모공이 발달되어있는 부분은 한번 더 롤링하여 꼼꼼한 세안으로 과잉피지를 깨끗하게 제거하는 것이 좋습니다.

- 세안 후 건조한상태로 장시간 방치하기 보다는 바로 스킨케어 제품을 바르는것이 중요합니다.

- 수분을 빼앗는 흡연이나 음주, 카페인 섭취는 줄이고 생선 등 콜라겐이 함유되어 있는 음식이나 항산화성분이 많이 함유된 식품을 섭취하는 것을 추천합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "17"
                ,
                s_type_gomin = "심각한 민감피부"
                ,
                s_result = @"온도변화나 외부자극에 예민하게 반응할 수 있습니다.

건조한 피부의 경우 피부 장벽이 손상되어 피부가 자극을 느끼기 쉬우며 열감이 느껴지는 경우도 있습니다."
,
                s_beauty_tip = @"- 피부 온도 변화나 찬 바람, 자외선에 쉽게 자극 받을 수 있으므로 평소 충분한 보습을 통해 유수분 균형을 맞춰주고 피부 장벽을 강화할수 있는 스킨케어제품을 사용하는것이 좋습니다.

- 팩이나 마사지를 장시간 하지 않으며, 과도한 세안이나 자극적인 필링은 피하는것이 중요합니다.

- 저자극 제품을 꾸준하게 사용하되 자신의 피부에 맞는 화장품 선택이 중요하므로 구입 전 성분을 꼼꼼하게 살펴보고 목 등에 발라 사전 테스트 후 사용하는것을 추천합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "18"
                ,
                s_type_gomin = "심각한 여드름 피부"
                ,
                s_result = @"각질이 모공을 막아 원활하게 피지분비가 되지 않을때 흔적이 발생 될 수 있습니다.

흔적이 발생 된 후 멜라닌의 증가로 자국이 나타날 수 있습니다.

피부결이 거칠고 칙칙해 보일 수 있습니다."
,
                s_beauty_tip = @"- 트러블 예방을 위해 가급적 매일 머리를 감는 것이 좋으며, 트러블 부위를 손으로 짜거나 만지지 않는것이 좋습니다.

- 피부정화와 진정효과가 있는 스킨케어 제품과, 적당한 유수분공급을 통해 유수분 균형을 이루어  피부 장벽을 강화하는것을 추천합니다.

- 트러블을 유발하는 맵거나 기름진 음식, 지나치게 단 음식은 피하고 매일 6잔(1.5L) 이상의 충분한 수분을 섭취하며 충분한 수면을 통해 피로가 쌓이지 않도록 하는것이 중요합니다."
            });
            list_rsse.Add(new Result_Solution_Entity()
            {
                s_type_number = "19"
                ,
                s_type_gomin = "심각한 민감 & 여드름 피부"
                ,
                s_result = @"피부장벽이 손상되어 쉽게 자극을 느끼기 쉬우며, 열감이 느껴질 수 있는 피부입니다.

각질 턴오버 저하로 피부 고민이 발생 될 수 있습니다."
,
                s_beauty_tip = @"- 팩이나 마사지를 장시간 하지 않으며, 과도한 세안이나 자극적인 필링은 피하는것이 중요합니다.

- 저자극 제품을 꾸준하게 사용하되 자신의 피부에 맞는 화장품 선택이 중요하므로 구입 전 성분을 꼼꼼하게 살펴보고 목 등에 발라 사전 테스트 후 사용하는것을 추천합니다.

- 트러블 예방을 위해 가급적 매일 머리를 감는 것이 좋으며, 트러블 부위를 손으로 짜거나 만지지 않는것이 좋습니다."
            });

            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "1", solution_type_name = "건성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "1", solution_type_name = "건성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "1", solution_type_name = "건성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "1", solution_type_name = "건성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "1", solution_type_name = "건성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "1", solution_type_name = "건성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "2", solution_type_name = "건성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "2", solution_type_name = "건성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "2", solution_type_name = "건성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "2", solution_type_name = "건성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "2", solution_type_name = "건성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "2", solution_type_name = "건성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "3", solution_type_name = "건성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "3", solution_type_name = "건성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "3", solution_type_name = "건성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "3", solution_type_name = "건성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "3", solution_type_name = "건성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "3", solution_type_name = "건성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "3", solution_type_name = "건성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "3", solution_type_name = "건성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "3", solution_type_name = "건성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "4", solution_type_name = "건성 -", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "4", solution_type_name = "건성 -", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "4", solution_type_name = "건성 -", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "4", solution_type_name = "건성 -", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = false, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "5", solution_type_name = "지성 A", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "5", solution_type_name = "지성 A", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "5", solution_type_name = "지성 A", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "5", solution_type_name = "지성 A", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "5", solution_type_name = "지성 A", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "5", solution_type_name = "지성 A", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "6", solution_type_name = "지성 T", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "6", solution_type_name = "지성 T", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "6", solution_type_name = "지성 T", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "6", solution_type_name = "지성 T", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "6", solution_type_name = "지성 T", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "6", solution_type_name = "지성 T", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "7", solution_type_name = "지성 AT", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "7", solution_type_name = "지성 AT", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "7", solution_type_name = "지성 AT", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "7", solution_type_name = "지성 AT", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "7", solution_type_name = "지성 AT", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "7", solution_type_name = "지성 AT", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "7", solution_type_name = "지성 AT", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "7", solution_type_name = "지성 AT", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "7", solution_type_name = "지성 AT", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "8", solution_type_name = "지성 -", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "8", solution_type_name = "지성 -", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "8", solution_type_name = "지성 -", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "8", solution_type_name = "지성 -", tzone_value_01 = false, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "9", solution_type_name = "중성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "9", solution_type_name = "중성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "9", solution_type_name = "중성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "9", solution_type_name = "중성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "9", solution_type_name = "중성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "9", solution_type_name = "중성 A", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "10", solution_type_name = "중성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "10", solution_type_name = "중성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "10", solution_type_name = "중성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "10", solution_type_name = "중성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "10", solution_type_name = "중성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "10", solution_type_name = "중성 T", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "11", solution_type_name = "중성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "11", solution_type_name = "중성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "11", solution_type_name = "중성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "11", solution_type_name = "중성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "11", solution_type_name = "중성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "11", solution_type_name = "중성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "11", solution_type_name = "중성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "11", solution_type_name = "중성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "11", solution_type_name = "중성 AT", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "12", solution_type_name = "중성 -", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "12", solution_type_name = "중성 -", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "12", solution_type_name = "중성 -", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "12", solution_type_name = "중성 -", tzone_value_01 = true, tzone_value_02 = true, tzone_value_03 = true, uzone_value_01 = false, uzone_value_02 = true, uzone_value_03 = false, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "13", solution_type_name = "복합성 A", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "13", solution_type_name = "복합성 A", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "13", solution_type_name = "복합성 A", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "13", solution_type_name = "복합성 A", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "13", solution_type_name = "복합성 A", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "13", solution_type_name = "복합성 A", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "14", solution_type_name = "복합성 T", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "14", solution_type_name = "복합성 T", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "14", solution_type_name = "복합성 T", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "14", solution_type_name = "복합성 T", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "14", solution_type_name = "복합성 T", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "14", solution_type_name = "복합성 T", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "15", solution_type_name = "복합성 AT", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "15", solution_type_name = "복합성 AT", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "15", solution_type_name = "복합성 AT", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = true, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "15", solution_type_name = "복합성 AT", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "15", solution_type_name = "복합성 AT", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "15", solution_type_name = "복합성 AT", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = true, FFutrueWrinkle_value_05 = true, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "15", solution_type_name = "복합성 AT", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = true, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = true, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "15", solution_type_name = "복합성 AT", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = true, FMelanin_value_05 = true, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "15", solution_type_name = "복합성 AT", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = true, FPore_value_05 = true, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = true, FPigmentation_value_05 = true, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "16", solution_type_name = "복합성 -", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "16", solution_type_name = "복합성 -", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = true, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "16", solution_type_name = "복합성 -", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = true, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "16", solution_type_name = "복합성 -", tzone_value_01 = true, tzone_value_02 = false, tzone_value_03 = true, uzone_value_01 = true, uzone_value_02 = false, uzone_value_03 = true, FPore_value_01 = true, FPore_value_02 = true, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = true, FFutrueWrinkle_value_02 = true, FFutrueWrinkle_value_03 = true, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = true, FPigmentation_value_02 = true, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = true, FMelanin_value_02 = true, FMelanin_value_03 = true, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "17", solution_type_name = "심각한 민감피부", tzone_value_01 = false, tzone_value_02 = false, tzone_value_03 = false, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = false, FRedness_value_02 = false, FRedness_value_03 = false, FRedness_value_04 = true, FRedness_value_05 = true, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = true, FPorphyrin_value_02 = true, FPorphyrin_value_03 = true, FPorphyrin_value_04 = false, FPorphyrin_value_05 = false });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "18", solution_type_name = "심각한 여드름 피부", tzone_value_01 = false, tzone_value_02 = false, tzone_value_03 = false, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = true, FRedness_value_02 = true, FRedness_value_03 = true, FRedness_value_04 = false, FRedness_value_05 = false, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = false, FPorphyrin_value_02 = false, FPorphyrin_value_03 = false, FPorphyrin_value_04 = true, FPorphyrin_value_05 = true });
            list_rule_data.Add(new Result_Solution_RoleData() { solution_type_number = "19", solution_type_name = "심각한 민감&여드름 피부", tzone_value_01 = false, tzone_value_02 = false, tzone_value_03 = false, uzone_value_01 = false, uzone_value_02 = false, uzone_value_03 = false, FPore_value_01 = false, FPore_value_02 = false, FPore_value_03 = false, FPore_value_04 = false, FPore_value_05 = false, FFutrueWrinkle_value_01 = false, FFutrueWrinkle_value_02 = false, FFutrueWrinkle_value_03 = false, FFutrueWrinkle_value_04 = false, FFutrueWrinkle_value_05 = false, FRedness_value_01 = false, FRedness_value_02 = false, FRedness_value_03 = false, FRedness_value_04 = true, FRedness_value_05 = true, FPigmentation_value_01 = false, FPigmentation_value_02 = false, FPigmentation_value_03 = false, FPigmentation_value_04 = false, FPigmentation_value_05 = false, FMelanin_value_01 = false, FMelanin_value_02 = false, FMelanin_value_03 = false, FMelanin_value_04 = false, FMelanin_value_05 = false, FPorphyrin_value_01 = false, FPorphyrin_value_02 = false, FPorphyrin_value_03 = false, FPorphyrin_value_04 = true, FPorphyrin_value_05 = true });

            datatable_rule = ConvertListToDataTable(list_rule_data);

        }

        public DataTable ConvertListToDataTable(IEnumerable<Result_Solution_RoleData> data)
        {
            DataTable table = new DataTable();
            table.Columns.Add("solution_type_number", typeof(string));
            table.Columns.Add("solution_type_name", typeof(string));
            table.Columns.Add("tzone_value_01", typeof(bool));
            table.Columns.Add("tzone_value_02", typeof(bool));
            table.Columns.Add("tzone_value_03", typeof(bool));
            table.Columns.Add("uzone_value_01", typeof(bool));
            table.Columns.Add("uzone_value_02", typeof(bool));
            table.Columns.Add("uzone_value_03", typeof(bool));
            table.Columns.Add("FPore_value_01", typeof(bool));
            table.Columns.Add("FPore_value_02", typeof(bool));
            table.Columns.Add("FPore_value_03", typeof(bool));
            table.Columns.Add("FPore_value_04", typeof(bool));
            table.Columns.Add("FPore_value_05", typeof(bool));
            table.Columns.Add("FFutrueWrinkle_value_01", typeof(bool));
            table.Columns.Add("FFutrueWrinkle_value_02", typeof(bool));
            table.Columns.Add("FFutrueWrinkle_value_03", typeof(bool));
            table.Columns.Add("FFutrueWrinkle_value_04", typeof(bool));
            table.Columns.Add("FFutrueWrinkle_value_05", typeof(bool));
            table.Columns.Add("FRedness_value_01", typeof(bool));
            table.Columns.Add("FRedness_value_02", typeof(bool));
            table.Columns.Add("FRedness_value_03", typeof(bool));
            table.Columns.Add("FRedness_value_04", typeof(bool));
            table.Columns.Add("FRedness_value_05", typeof(bool));
            table.Columns.Add("FPigmentation_value_01", typeof(bool));
            table.Columns.Add("FPigmentation_value_02", typeof(bool));
            table.Columns.Add("FPigmentation_value_03", typeof(bool));
            table.Columns.Add("FPigmentation_value_04", typeof(bool));
            table.Columns.Add("FPigmentation_value_05", typeof(bool));
            table.Columns.Add("FMelanin_value_01", typeof(bool));
            table.Columns.Add("FMelanin_value_02", typeof(bool));
            table.Columns.Add("FMelanin_value_03", typeof(bool));
            table.Columns.Add("FMelanin_value_04", typeof(bool));
            table.Columns.Add("FMelanin_value_05", typeof(bool));
            table.Columns.Add("FPorphyrin_value_01", typeof(bool));
            table.Columns.Add("FPorphyrin_value_02", typeof(bool));
            table.Columns.Add("FPorphyrin_value_03", typeof(bool));
            table.Columns.Add("FPorphyrin_value_04", typeof(bool));
            table.Columns.Add("FPorphyrin_value_05", typeof(bool));

            foreach (Result_Solution_RoleData info in data)
            {
                DataRow row = table.NewRow();

                row["solution_type_number"] = info.solution_type_number;
                row["solution_type_name"] = info.solution_type_name;
                row["tzone_value_01"] = info.tzone_value_01;
                row["tzone_value_02"] = info.tzone_value_02;
                row["tzone_value_03"] = info.tzone_value_03;
                row["uzone_value_01"] = info.uzone_value_01;
                row["uzone_value_02"] = info.uzone_value_02;
                row["uzone_value_03"] = info.uzone_value_03;
                row["FPore_value_01"] = info.FPore_value_01;
                row["FPore_value_02"] = info.FPore_value_02;
                row["FPore_value_03"] = info.FPore_value_03;
                row["FPore_value_04"] = info.FPore_value_04;
                row["FPore_value_05"] = info.FPore_value_05;
                row["FFutrueWrinkle_value_01"] = info.FFutrueWrinkle_value_01;
                row["FFutrueWrinkle_value_02"] = info.FFutrueWrinkle_value_02;
                row["FFutrueWrinkle_value_03"] = info.FFutrueWrinkle_value_03;
                row["FFutrueWrinkle_value_04"] = info.FFutrueWrinkle_value_04;
                row["FFutrueWrinkle_value_05"] = info.FFutrueWrinkle_value_05;
                row["FRedness_value_01"] = info.FRedness_value_01;
                row["FRedness_value_02"] = info.FRedness_value_02;
                row["FRedness_value_03"] = info.FRedness_value_03;
                row["FRedness_value_04"] = info.FRedness_value_04;
                row["FRedness_value_05"] = info.FRedness_value_05;
                row["FPigmentation_value_01"] = info.FPigmentation_value_01;
                row["FPigmentation_value_02"] = info.FPigmentation_value_02;
                row["FPigmentation_value_03"] = info.FPigmentation_value_03;
                row["FPigmentation_value_04"] = info.FPigmentation_value_04;
                row["FPigmentation_value_05"] = info.FPigmentation_value_05;
                row["FMelanin_value_01"] = info.FMelanin_value_01;
                row["FMelanin_value_02"] = info.FMelanin_value_02;
                row["FMelanin_value_03"] = info.FMelanin_value_03;
                row["FMelanin_value_04"] = info.FMelanin_value_04;
                row["FMelanin_value_05"] = info.FMelanin_value_05;
                row["FPorphyrin_value_01"] = info.FPorphyrin_value_01;
                row["FPorphyrin_value_02"] = info.FPorphyrin_value_02;
                row["FPorphyrin_value_03"] = info.FPorphyrin_value_03;
                row["FPorphyrin_value_04"] = info.FPorphyrin_value_04;
                row["FPorphyrin_value_05"] = info.FPorphyrin_value_05;
                table.Rows.Add(row);
            }

            table.AcceptChanges();

            return table;
        }

        public string GetSolutionTypeNumber(string t_zone_result, string u_zone_result, List<UC_Result_EllipseText> list_Concern, C_Survey survey)
        {
            string result = string.Empty;

            Result_Solution_RoleData rse = new Result_Solution_RoleData();

            string expression = "";
            string sortOrder = "";
            DataRow[] foundRows;

            //17, 18 , 19번의 경우 포피린과 붉은기가 40점 이하일 경우 사용될 변수
            bool FRedness_40_under = false;
            bool FPorphyrin_40_under = false;


            if (t_zone_result.Contains("건성"))
            {
                rse.tzone_value_01 = true;

                expression = "tzone_value_01 = True ";

            }
            else if (t_zone_result.Contains("중성"))
            {
                rse.tzone_value_02 = true;
                expression = "tzone_value_02 = True ";
            }
            else if (t_zone_result.Contains("지성"))
            {
                rse.tzone_value_03 = true;
                expression = "tzone_value_03 = True ";
            }

            if (u_zone_result.Contains("건성"))
            {
                rse.uzone_value_01 = true;
                expression += " and uzone_value_01 = True ";
            }
            else if (u_zone_result.Contains("중성"))
            {
                rse.uzone_value_02 = true;
                expression += " and uzone_value_02 = True ";
            }
            else if (u_zone_result.Contains("지성"))
            {
                rse.uzone_value_03 = true;
                expression += " and uzone_value_03 = True ";
            }

            #region ConcernRule

            foreach (UC_Result_EllipseText uc_item in list_Concern)
            {
                switch (uc_item.Title)
                {
                    case "주름":
                        if (uc_item.Tooltip_Score >= 80)
                        {
                            rse.FPore_value_01 = true;
                            expression += " and FPore_value_01 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 80 && uc_item.Tooltip_Score >= 60)
                        {
                            rse.FPore_value_02 = true;
                            expression += " and FPore_value_02 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 60 && uc_item.Tooltip_Score >= 40)
                        {
                            rse.FPore_value_03 = true;
                            expression += " and FPore_value_03 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 40 && uc_item.Tooltip_Score >= 20)
                        {
                            rse.FPore_value_04 = true;
                            expression += " and FPore_value_04 = True ";
                        }
                        else
                        {
                            rse.FPore_value_05 = true;
                            expression += " and FPore_value_05 = True ";
                        }
                        break;
                    case "미래주름":
                        if (uc_item.Tooltip_Score >= 80)
                        {
                            rse.FFutrueWrinkle_value_01 = true;
                            expression += " and FFutrueWrinkle_value_01 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 80 && uc_item.Tooltip_Score >= 60)
                        {
                            rse.FFutrueWrinkle_value_02 = true;
                            expression += " and FFutrueWrinkle_value_02 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 60 && uc_item.Tooltip_Score >= 40)
                        {
                            rse.FFutrueWrinkle_value_03 = true;
                            expression += " and FFutrueWrinkle_value_03 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 40 && uc_item.Tooltip_Score >= 20)
                        {
                            rse.FFutrueWrinkle_value_04 = true;
                            expression += " and FFutrueWrinkle_value_04 = True ";
                        }
                        else
                        {
                            rse.FFutrueWrinkle_value_05 = true;
                            expression += " and FFutrueWrinkle_value_05 = True ";
                        }
                        break;
                    case "붉은기":
                    case "홍조":
                        if (uc_item.Tooltip_Score >= 80)
                        {
                            rse.FRedness_value_01 = true;
                            expression += " and FRedness_value_01 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 80 && uc_item.Tooltip_Score >= 60)
                        {
                            rse.FRedness_value_02 = true;
                            expression += " and FRedness_value_02 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 60 && uc_item.Tooltip_Score >= 40)
                        {
                            rse.FRedness_value_03 = true;
                            expression += " and FRedness_value_03 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 40 && uc_item.Tooltip_Score >= 20)
                        {
                            rse.FRedness_value_04 = true;
                            expression += " and FRedness_value_04 = True ";
                            FRedness_40_under = true;
                        }
                        else
                        {
                            rse.FRedness_value_05 = true;
                            expression += " and FRedness_value_05 = True ";
                            FRedness_40_under = true;
                        }
                        break;
                    case "색소침착":
                        if (uc_item.Tooltip_Score >= 80)
                        {
                            rse.FPigmentation_value_01 = true;
                            expression += " and FPigmentation_value_01 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 80 && uc_item.Tooltip_Score >= 60)
                        {
                            rse.FPigmentation_value_02 = true;
                            expression += " and FPigmentation_value_02 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 60 && uc_item.Tooltip_Score >= 40)
                        {
                            rse.FPigmentation_value_03 = true;
                            expression += " and FPigmentation_value_03 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 40 && uc_item.Tooltip_Score >= 20)
                        {
                            rse.FPigmentation_value_04 = true;
                            expression += " and FPigmentation_value_04 = True ";
                        }
                        else
                        {
                            rse.FPigmentation_value_05 = true;
                            expression += " and FPigmentation_value_05 = True ";
                        }
                        break;
                    case "멜라닌":
                        if (uc_item.Tooltip_Score >= 80)
                        {
                            rse.FMelanin_value_01 = true;
                            expression += " and FMelanin_value_01 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 80 && uc_item.Tooltip_Score >= 60)
                        {
                            rse.FMelanin_value_02 = true;
                            expression += " and FMelanin_value_02 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 60 && uc_item.Tooltip_Score >= 40)
                        {
                            rse.FMelanin_value_03 = true;
                            expression += " and FMelanin_value_03 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 40 && uc_item.Tooltip_Score >= 20)
                        {
                            rse.FMelanin_value_04 = true;
                            expression += " and FMelanin_value_04 = True ";
                        }
                        else
                        {
                            rse.FMelanin_value_05 = true;
                            expression += " and FMelanin_value_05 = True ";
                        }
                        break;


                    case "포피린":
                        if (uc_item.Tooltip_Score >= 80)
                        {
                            rse.FPorphyrin_value_01 = true;
                            expression += " and FPorphyrin_value_01 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 80 && uc_item.Tooltip_Score >= 60)
                        {
                            rse.FPorphyrin_value_02 = true;
                            expression += " and FPorphyrin_value_02 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 60 && uc_item.Tooltip_Score >= 40)
                        {
                            rse.FPorphyrin_value_03 = true;
                            expression += " and FPorphyrin_value_03 = True ";
                        }
                        else if (uc_item.Tooltip_Score < 40 && uc_item.Tooltip_Score >= 20)
                        {
                            rse.FPorphyrin_value_04 = true;
                            expression += " and FPorphyrin_value_04 = True ";
                            FPorphyrin_40_under = true;
                        }
                        else
                        {
                            rse.FPorphyrin_value_05 = true;
                            expression += " and FPorphyrin_value_05 = True ";
                            FPorphyrin_40_under = true;
                        }
                        break;
                    default:
                        break;
                }
            }

            #endregion

            if (survey.S1_12 == "Y" && FRedness_40_under == true && FPorphyrin_40_under == true) //19번피부타입은 고민에서 민감과 여드름 선택 이고 포피린과 붉은기가 40점 이하일 경우
            {
                expression = "FRedness_value_04 = True and FPorphyrin_value_04 = True";
                foundRows = datatable_rule.Select(expression, sortOrder);
            }
            else if ( FRedness_40_under == true) //붉은기 점수가 40점 이하일경우
            {
                expression = "FRedness_value_04 = True";
                foundRows = datatable_rule.Select(expression, sortOrder);
            }
            else if (survey.S1_12 == "Y" && FPorphyrin_40_under == true) //18번 피부타입은 고민에서 여드름선택 이고 포피린 점수가 40점 이하일경우
            {
                expression = "FPorphyrin_value_04 = True";
                foundRows = datatable_rule.Select(expression, sortOrder);
            }
            else // 위 해당조건이 일치 하지 않는경우
            {
                foundRows = datatable_rule.Select(expression, sortOrder);
            }

            if (foundRows.Length == 0)
            {
                return LoginSession.Selected_C_ResultPageData.solution_type_number;
            }
            else
            {
                return foundRows[0]["solution_type_number"].ToString();
            }
        }

        public string GetSolution_Beautytips(string solution_number)
        {
            IEnumerable<Result_Solution_Entity> from_rse = list_rsse.Where(item => item.s_type_number == solution_number);

            string result = string.Empty;

            if (from_rse != null)
            {
                foreach (Result_Solution_Entity rse in from_rse)
                {
                    result = rse.s_beauty_tip;
                }
            }
            return result;
        }

        public string GetSolution_Result(string solution_number)
        {
            IEnumerable<Result_Solution_Entity> from_rse = list_rsse.Where(item => item.s_type_number == solution_number);

            string result = string.Empty;

            if (from_rse != null)
            {
                foreach (Result_Solution_Entity rse in from_rse)
                {
                    result = rse.s_result;
                }
            }
            return result;
        }

        public string GetSensitiveTypeResult(string sensitive_type)
        {
            IEnumerable<Result_Sensitive_Entity> from_rse = list_rse.Where(item => item.s_type == sensitive_type);

            string result = string.Empty;

            if (from_rse != null)
            {
                foreach (Result_Sensitive_Entity rse in from_rse)
                {
                    result = rse.s_result;
                }
            }
            return result;
        }

        public double GetSkinConcernScore(string _gender, int _age, string _gubun, double _value)
        {           
            double result = 0;

            int age_area = GetAgeArea(_age);

            IEnumerable<Result_Concern_Entity> from_rce = list_rce.Where(item => item.gender == _gender && item.gubun == _gubun && item.age == age_area);

            if (_gubun == "탄력" && _value == -1)
            {
                result = 50;
                //result = -1;
            }
            else if (_gubun == "탄력" && _value > -1)
            {
                foreach (Result_Concern_Entity rce in from_rce)
                {

                    double 총범위;
                    double 특정값;
                    result = 100;

                    if (_value >= rce.sixth)
                    {
                        총범위 = rce.sixth - rce.fifth;
                        특정값 = _value - rce.fifth;
                        result -= (특정값 / 총범위 * 20 + 80);
                    }
                    else
                    {
                        result = -1;
                    }
                }
            }else if (_gubun == "경피수분손실도" && _value == -1)
            {
                result = 50;
            }
            else
            {
                foreach (Result_Concern_Entity rce in from_rce)
                {

                    double 총범위;
                    double 특정값;
                    result = 100;
                    if (_value >= rce.fifth)
                    {
                        총범위 = rce.sixth - rce.fifth;
                        특정값 = _value - rce.fifth;
                        result -= (특정값 / 총범위 * 20 + 80);
                    }
                    else if (_value >= rce.fourth)
                    {
                        총범위 = rce.fifth - rce.fourth;
                        특정값 = _value - rce.fourth;
                        result -= (특정값 / 총범위 * 20 + 60);
                    }
                    else if (_value >= rce.third)
                    {
                        총범위 = rce.fourth - rce.third;
                        특정값 = _value - rce.third;
                        result -= (특정값 / 총범위 * 20 + 40);
                    }
                    else if (_value >= rce.second)
                    {
                        총범위 = rce.third - rce.second;
                        특정값 = _value - rce.second;
                        result -= (특정값 / 총범위 * 20 + 20);
                    }
                    else if (_value >= rce.first)
                    {
                        총범위 = rce.second - rce.first;
                        특정값 = _value - rce.first;
                        result -= (특정값 / 총범위 * 20);
                    }

                }
            }

            if (result > 100)
            {
                return 100;
            }
            else if (result < 0)
            {
                return 0;
            }

            return result;
        }

        public int GetAgeArea(int _age)
        {
            if (_age <= 19)
            {
                return 19;
            }
            else if (_age >= 20 && _age <= 24)
            {
                return 24;
            }
            else if (_age >= 25 && _age <= 29)
            {
                return 29;
            }
            else if (_age >= 30 && _age <= 34)
            {
                return 34;
            }
            else if (_age >= 35 && _age <= 39)
            {
                return 39;
            }
            else if (_age >= 40 && _age <= 44)
            {
                return 44;
            }
            else if (_age >= 45 && _age <= 49)
            {
                return 49;
            }
            else if (_age >= 50 && _age <= 54)
            {
                return 54;
            }
            else if (_age >= 55 && _age <= 59)
            {
                return 59;
            }
            else if (_age >= 60 && _age <= 69)
            {
                return 69;
            }
            else
            {
                return 70;
            }
        }

        public string GetSkinConcernGrade(string _gender, int _age, string _gubun, double _value)
        {

            if (_gubun == "탄력" && _value == -1)
            {
                return "보통";
            }else if (_gubun == "경피수분손실도" && _value == -1)
            {
                return "보통";
            }
            string result = string.Empty;

            int age_area = GetAgeArea(_age);

            IEnumerable<Result_Concern_Entity> from_rce = list_rce.Where(item => item.gender == _gender && item.gubun == _gubun && item.age == age_area);

            foreach (Result_Concern_Entity rce in from_rce)
            {
                if (rce.second >= _value)
                {
                    //매우좋음
                    result = "매우\r\n좋음";
                }
                else if (rce.second < _value && rce.third >= _value)
                {
                    //좋음
                    result = "좋음";
                }
                else if (rce.third < _value && rce.fourth >= _value)
                {
                    //보통
                    result = "보통";
                }
                else if (rce.fourth <_value && rce.fifth >= _value)
                {
                    //관심필요
                    result = "관심\r\n필요";
                }
                else if (rce.fifth < _value)
                {
                    //집중관리
                    result = "집중\r\n관리";
                }
                          
            }

            //포피린 피지량이 5 % 미만일 경우 포피린의 양과 상관없이 ‘매우 좋음’													
            //피지량이 10 % 미만 일 경우 포피린의 양과 상관 없이 ‘좋음’													

            //다크서클 눈밑 피부톤 평균값-양볼 피부톤 평균값< 0 일 경우 다크서클 '매우 좋음'
            //눈밑 피부톤 평균값 - 양볼 피부톤 평균값≥0 일 경우 위 로직에 따라 5 level 및 점수 산정

            return result;
        }
    }

    public class Result_Concern_Entity
    {
        public string gender { get; set; }
        public int age { get; set; }
        public string gubun { get; set; }
        public double first { get; set; }
        public double second { get; set; }
        public double third { get; set; }
        public double fourth { get; set; }
        public double fifth { get; set; }
        public double sixth { get; set; }
        public double A { get; set; }
        public double B { get; set; }
        public double C { get; set; }
        public double D { get; set; }
        public double E { get; set; }
        public double F { get; set; }
        public double G { get; set; }
        public double H { get; set; }
        public double AVG { get; set; }
    }

    public class Result_Sensitive_Entity
    {
        /// <summary>
        /// 민감도 유형
        /// </summary>
        public string s_type { get; set; }

        /// <summary>
        /// 민감도 유형 이름
        /// </summary>
        public string s_type_name { get; set; }

        /// <summary>
        /// 피부진단결과
        /// </summary>
        public string s_result_skin { get; set; }

        /// <summary>
        /// 분석결과
        /// </summary>
        public string s_result { get; set; }
    }

    public class Result_Solution_Entity
    {
        public string s_type_number { get; set; }
        public string s_type_gomin { get; set; }
        public string s_beauty_tip { get; set; }
        public string s_result { get; set; }
    }

    public class Result_Solution_RoleData
    {
        public string solution_type_number { get; set; }

        public string solution_type_name { get; set; }

        //t존
        public bool tzone_value_01 { get; set; }
        public bool tzone_value_02 { get; set; }
        public bool tzone_value_03 { get; set; }

        //u존
        public bool uzone_value_01 { get; set; }
        public bool uzone_value_02 { get; set; }
        public bool uzone_value_03 { get; set; }

        //주름
        public bool FPore_value_01 { get; set; }
        public bool FPore_value_02 { get; set; }
        public bool FPore_value_03 { get; set; }
        public bool FPore_value_04 { get; set; }
        public bool FPore_value_05 { get; set; }

        //미래주름
        public bool FFutrueWrinkle_value_01 { get; set; }
        public bool FFutrueWrinkle_value_02 { get; set; }
        public bool FFutrueWrinkle_value_03 { get; set; }
        public bool FFutrueWrinkle_value_04 { get; set; }
        public bool FFutrueWrinkle_value_05 { get; set; }

        //붉은기, 붉은기
        public bool FRedness_value_01 { get; set; }
        public bool FRedness_value_02 { get; set; }
        public bool FRedness_value_03 { get; set; }
        public bool FRedness_value_04 { get; set; }
        public bool FRedness_value_05 { get; set; }

        //색소침착
        public bool FPigmentation_value_01 { get; set; }
        public bool FPigmentation_value_02 { get; set; }
        public bool FPigmentation_value_03 { get; set; }
        public bool FPigmentation_value_04 { get; set; }
        public bool FPigmentation_value_05 { get; set; }

        //멜라닌
        public bool FMelanin_value_01 { get; set; }
        public bool FMelanin_value_02 { get; set; }
        public bool FMelanin_value_03 { get; set; }
        public bool FMelanin_value_04 { get; set; }
        public bool FMelanin_value_05 { get; set; }

        //포피린
        public bool FPorphyrin_value_01 { get; set; }
        public bool FPorphyrin_value_02 { get; set; }
        public bool FPorphyrin_value_03 { get; set; }
        public bool FPorphyrin_value_04 { get; set; }
        public bool FPorphyrin_value_05 { get; set; }
    }
}
