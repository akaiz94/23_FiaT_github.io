﻿using IOPE_LAB.Popup;
using IOPE_LAB.UserControls;
using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using IOPE_LAB_REPORT;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Markup; //IAddChild 



//using Amazon;
//using Amazon.S3;
//using Amazon.S3.Transfer;
//using Amazon.S3.Model;

namespace IOPE_LAB.Contents.Result
{
    /// <summary>
    /// ResultPage.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ResultPage : Page
    {
        public enum ResultPageName
        {
            ResultPageName01, ResultPageName02
        }

        public ResultPage()
        {
            InitializeComponent();

            this.Loaded += ResultPage_Loaded;
            this.btn_Submit.Click += Btn_Submit_Click;
            this.btn_Print.Click += Btn_Print_Click;
            this.btn_History.Click += Btn_History_Click;

            LoginSession.SelectedMember.div = "skin";
        }

        private void Btn_History_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (uc_ResultPage01.rpde != null)
                {
                    Popup.Popup_ConcernItemHistory pch = new Popup_ConcernItemHistory(uc_ResultPage01.rpde);

                    pch.Topmost = true;
                    pch.ShowDialog();

                }
            }
            catch (Exception ex)
            {
                if (ex.Data.Count == 0)
                {
                    Common.CommonMessageBox.ShowErrorMessage("해당 고객은 현재 실행중인 Course 의 저장된 측정 결과가 없습니다.");
                }
                else
                {
                    Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                    Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
                }
            }
        }


        //기존 프린트페이지
        /*  
        private void Btn_Print_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Common.CommonBiz.LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 프린터 버튼 클릭");

                if (uc_ResultPage01.rpde.specialtip_img.Length < 1)
                {
                    uc_ResultPage01.rpde.specialtip_img = GetJpgImage(uc_ResultPage01.grid_inkarea, 1, 100);
                }

                if ((LoginSession.SelectedMember.PCCD == "PC001009" || LoginSession.SelectedMember.PCCD == "PC001001" || LoginSession.SelectedMember.PCCD == "PC001013"))
                {
                    IOPE_LAB_REPORT.Report_Form rf = new Report_Form();
                    IOPE_LAB_REPORT.Result_Report_Intensive rr = new Result_Report_Intensive(uc_ResultPage01.rpde);
                    rf.REPORT = rr;
                    rf.ShowDialog();
                }
                else
                {
                    IOPE_LAB_REPORT.Report_Form rf = new Report_Form();
                    IOPE_LAB_REPORT.Result_Report rr = new Result_Report(uc_ResultPage01.rpde);
                    rf.REPORT = rr;
                    rf.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }
        }
       */


     
        private void Btn_Print_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Common.CommonBiz.LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 프린터1 버튼 클릭");

                if (uc_ResultPage01.rpde.specialtip_img.Length < 1)
                {
                    uc_ResultPage01.rpde.specialtip_img = GetJpgImage(uc_ResultPage01.grid_inkarea, 1, 100);
                }

                if ((LoginSession.SelectedMember.PCCD == "PC001009" || LoginSession.SelectedMember.PCCD == "PC001001" || LoginSession.SelectedMember.PCCD == "PC001013"))
                {
                    Window popupWindow = new Window
                    {
                        Title = "MY SKIN RESULT",
                        Width = 820,
                        Height = 1050,
                        Content = new Frame
                        {
                            Content = new MySkin_PrintPage(uc_ResultPage01.rpd)


                        }

                    };
                    popupWindow.ShowDialog();
                }
                else
                {
                    Window popupWindow = new Window
                    {
                        Title = "MY SKIN RESULT",
                        Width = 820,
                        Height = 1050,
                        Content = new Frame
                        {
                            Content = new MySkin_PrintPage(uc_ResultPage01.rpd)
                        }
                    };
                    popupWindow.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }
        }

        private void btn_Print1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Common.CommonBiz.LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 프린터2 버튼 클릭");

                if (uc_ResultPage01.rpde.specialtip_img.Length < 1)
                {
                    uc_ResultPage01.rpde.specialtip_img = GetJpgImage(uc_ResultPage01.grid_inkarea, 1, 100);
                }

                if ((LoginSession.SelectedMember.PCCD == "PC001009" || LoginSession.SelectedMember.PCCD == "PC001001" || LoginSession.SelectedMember.PCCD == "PC001013"))
                {
                    Window popupWindow = new Window
                    {
                        Title = "MY SKIN RESULT",
                        Width = 820,
                        Height = 1050,
                        Content = new Frame
                        {
                            Content = new MySkin_PrintPage_sub1()


                        }

                    };
                    popupWindow.ShowDialog();
                }
                else
                {
                    Window popupWindow = new Window
                    {
                        Title = "MY SKIN RESULT",
                        Width = 820,
                        Height = 1050,
                        Content = new Frame
                        {
                            Content = new MySkin_PrintPage_sub1()
                        }
                    };
                    popupWindow.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }
        }



        private byte[] GetJpgImage(Grid source, int scale, int quality)
        {
            double actualHeight = source.RenderSize.Height;
            double actualWidth = source.RenderSize.Width;

            double renderHeight = actualHeight * scale;
            double renderWidth = actualWidth * scale;

            RenderTargetBitmap renderTarget = new RenderTargetBitmap((int)renderWidth, (int)renderHeight, 96, 96, PixelFormats.Pbgra32);
            VisualBrush sourceBrush = new VisualBrush(source);

            DrawingVisual drawingVisual = new DrawingVisual();
            DrawingContext drawingContext = drawingVisual.RenderOpen();

            using (drawingContext)
            {
                drawingContext.PushTransform(new ScaleTransform(scale, scale));
                drawingContext.DrawRectangle(sourceBrush, null, new Rect(new Point(0, 0), new Point(actualWidth, actualHeight)));
            }
            renderTarget.Render(drawingVisual);
            JpegBitmapEncoder jpgEncoder = new JpegBitmapEncoder();
            jpgEncoder.QualityLevel = quality;
            jpgEncoder.Frames.Add(BitmapFrame.Create(renderTarget));

            Byte[] _imageArray;

            using (MemoryStream outputStream = new MemoryStream())
            {
                jpgEncoder.Save(outputStream);
                _imageArray = outputStream.ToArray();
            }

            return _imageArray;
        }

        private void Btn_Submit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (SkinConcern() != -1 && LoginSession.AdminContentFlag != true)
                {
                    Popup.Popup_ResultSaveManager prs = new Popup.Popup_ResultSaveManager(uc_ResultPage01.rpde);

                    prs.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                    prs.ShowDialog();
                }
                else
                {
                    Common.CommonMessageBox.ShowAlertMessage("관리자 기능 사용중엔 저장기능을 사용 할 수 없습니다.");
                }
            }
            catch (Exception ex)
            {

            }
        }
        private void ResultPage_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private int SkinConcern()
        {
            try
            {
                Result_SkinConcern_Rpt rscr = new Result_SkinConcern_Rpt();
                //피부데이터 담기
                //wcf 생성
                //update 시 기존 존재하는 고객인지 확인 후 데이터 업데이트

                rscr.userkey = uc_ResultPage01.rpde.userKey;
                rscr.surveyNo = uc_ResultPage01.rpde.surveyNo;
                rscr.name = uc_ResultPage01.rpde.name;
                rscr.pore = (Double.Parse(uc_ResultPage01.rpde.list_Consern_Rpt_data["모공"].ToString("N1")));
                rscr.wrinkle = (Double.Parse(uc_ResultPage01.rpde.list_Consern_Rpt_data["주름"].ToString("N1")));
                rscr.futurewrinkles = (Double.Parse(uc_ResultPage01.rpde.list_Consern_Rpt_data["미래주름"].ToString("N1")));
                rscr.pigmentation = (Double.Parse(uc_ResultPage01.rpde.list_Consern_Rpt_data["색소침착"].ToString("N1")));
                rscr.melanin = (Double.Parse(uc_ResultPage01.rpde.list_Consern_Rpt_data["멜라닌"].ToString("N1")));
                //rscr.darkcircles = (Double.Parse(uc_ResultPage01.rpde.list_Consern_Rpt_data["다크서클"].ToString("N1")));
                rscr.transdermal = (Double.Parse(uc_ResultPage01.rpde.list_Consern_Rpt_data["경피수분손실도"].ToString("N1")));
                rscr.redness = (Double.Parse(uc_ResultPage01.rpde.list_Consern_Rpt_data["붉은기"].ToString("N1")));
                rscr.porphyrin = (Double.Parse(uc_ResultPage01.rpde.list_Consern_Rpt_data["포피린"].ToString("N1")));
                rscr.elasticity = uc_ResultPage01.rpde.list_Consern_Rpt_data.Count == 9 ? (Double.Parse(uc_ResultPage01.rpde.list_Consern_Rpt_data["탄력"].ToString("N1"))) : 0;
                rscr.tZone_Moisture = LoginSession.Result_SkinConcern_Rpt.tZone_Moisture;
                rscr.tZone_Oilskin = LoginSession.Result_SkinConcern_Rpt.tZone_Oilskin;
                rscr.uZone_Moisture = LoginSession.Result_SkinConcern_Rpt.uZone_Moisture;
                rscr.uZone_Oilskin = LoginSession.Result_SkinConcern_Rpt.uZone_Oilskin;        

                ResultService.ResultServiceClient rsc = new ResultService.ResultServiceClient();

                int result = rsc.InsertSkinConcern(rscr);

                if (rsc.State != System.ServiceModel.CommunicationState.Closed)
                {
                    rsc.Close();
                }

                if (result > 0)
                {
                    return result;
                }
                else
                {
                    Common.CommonMessageBox.ShowAlertMessage("저장이 실패 하였습니다.\n다시 시도 하여주십시오.");
                    return -1;
                }
                //return -1;

            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
                return -1;
            }
        }

       
    }
}
