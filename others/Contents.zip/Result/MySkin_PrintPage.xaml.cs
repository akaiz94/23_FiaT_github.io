﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Markup; //IAddChild 활용 (동적 생성)
using System.IO;//MemoryStream 활용
using System.Printing; // 해상도 조절용 print ticket 사용
using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using IOPE_LAB_CONTROLS.Entity.MarkVu;
using IOPE_LAB.UserControls;

using System.Data;



namespace IOPE_LAB.Contents.Result
{
    /// <summary>
    /// MySkin_PrintPage.xaml에 대한 상호 작용 논리
    /// </summary>
    /// 


    public partial class MySkin_PrintPage : Page
    {

        //public ResultPage_Data rpd;
        public ResultPage_Data_Entity rpde;

        Result_Logic rl = new Result_Logic();

        public MySkin_PrintPage()
        {
            InitializeComponent();

            //this.Loaded += ResultPage01_Loaded;
            //AnalysisResult();       

        }

        public MySkin_PrintPage(ResultPage_Data rpd)
        {
            InitializeComponent();

            AnalysisResult(rpd);
        }

        private void AnalysisResult(ResultPage_Data rpd)
        {
            MySkin_ViewModel AnalysisResult = this.DataContext as MySkin_ViewModel;
            AnalysisResult.C_Name = LoginSession.SelectedMember.name; // 고객 이름
            AnalysisResult.C_Date = LoginSession.SelectedMember.rsvn_date.ToString("yyyy-MM-dd").Replace("-", "/"); // 측정일자

            MemberService.MemberServiceClient msc = new MemberService.MemberServiceClient();
            DataTable dt = msc.visitCount("IC", LoginSession.SelectedMember.name, LoginSession.SelectedMember.birthdate, LoginSession.SelectedMember.PCCD);

            if (dt.Rows.Count > 0 && LoginSession.Selected_C_ResultPageData != null)
            {
                string visit = dt.Rows.Count > 0 ? dt.Rows[0]["cnt"].ToString() : "0";
                AnalysisResult.C_Visit_Number = dt.Rows[0]["cnt"].ToString();    // 방문 횟수
            }


            /*
            if (dt.Rows.Count > 0)
            {
                string visit = dt.Rows.Count > 0 ? dt.Rows[0]["cnt"].ToString() : "0";
                AnalysisResult.C_Visit_Number = visit;
            }
            */


            /*
            프린트 내용 시작입니다.
            */

            //SKIN SUMMARY : 피부점수
            tb_SkinScore.Text = rpd.skin_score.ToString("N0");

            //SKIN SUMMARY : 피부고민
            tb_skin_gomin.Text = rpd.skin_gomin;

            //--- 1.분석 결과
            AnalysisResult.Skin_Condition_Score = (int)rpd.skin_score; // ##1.분석결과 - 현재 점수 (원형 테두리 자동 반영)



            //--- 2. 피부타입
            AnalysisResult.Skin_Type_Select = rpd.IsComplexity ? 0 : 1; //##2. 피부타입 - 복합성 여부 결정 (1일떄 No, 나머지 Yes)

            AnalysisResult.Sex_Type = LoginSession.SelectedMember.sex.Equals("M") ? 1 : 2; // ##2. 피부타입 - 남자,여자 U-T존 이미지 (1일때 남자, 나머지 여자)

            AnalysisResult.T_zone_Text = rpd.t_zone_result; // ##2.피부타입 - T존 오른쪽 텍스트
            AnalysisResult.U_zone_Text = rpd.u_zone_result; // ##2.피부타입 - U존 오른쪽 텍스트


            AnalysisResult.MySkin_T_Zone_Select = rpd.t_zone_position_num; //## 2. 피부타입 - T존 9칸 내부
            AnalysisResult.MySkin_U_Zone_Select = rpd.u_zone_position_num; //## 2. 피부타입 - U존 9칸 내부




            //--- 3. 피부고민
            //피부고민 프로그레스 바 점수
            AnalysisResult.MySkin_Concerns_Bar = (int)LoginSession.Result_SkinConcern_Rpt.pore;// ##모공
            if (AnalysisResult.MySkin_Concerns_Bar == 0)
            {
                AnalysisResult.MySkin_Concerns_Bar += 1;
            }

            AnalysisResult.MySkin_Concerns_Bar1 = (int)LoginSession.Result_SkinConcern_Rpt.wrinkle; // ##주름
            if (AnalysisResult.MySkin_Concerns_Bar1 == 0)
            {
                AnalysisResult.MySkin_Concerns_Bar1 += 1;
            }


            AnalysisResult.MySkin_Concerns_Bar2 = (int)LoginSession.Result_SkinConcern_Rpt.futurewrinkles; // ##미래주름
            if (AnalysisResult.MySkin_Concerns_Bar2 == 0)
            {
                AnalysisResult.MySkin_Concerns_Bar2 += 1;
            }


            AnalysisResult.MySkin_Concerns_Bar3 = (int)LoginSession.Result_SkinConcern_Rpt.pigmentation; // ##색소침착
            if (AnalysisResult.MySkin_Concerns_Bar3 == 0)
            {
                AnalysisResult.MySkin_Concerns_Bar3 += 1;
            }


            AnalysisResult.MySkin_Concerns_Bar4 = (int)LoginSession.Result_SkinConcern_Rpt.melanin; // ##미래색소침착
            if (AnalysisResult.MySkin_Concerns_Bar4 == 0)
            {
                AnalysisResult.MySkin_Concerns_Bar4 += 1;
            }


            AnalysisResult.MySkin_Concerns_Bar5 = (int)LoginSession.Result_SkinConcern_Rpt.redness; // ##붉은기
            if (AnalysisResult.MySkin_Concerns_Bar5 == 0)
            {
                AnalysisResult.MySkin_Concerns_Bar5 += 1;
            }


            AnalysisResult.MySkin_Concerns_Bar6 = (int)LoginSession.Result_SkinConcern_Rpt.porphyrin; // ##포피린
            if (AnalysisResult.MySkin_Concerns_Bar6 == 0)
            {
                AnalysisResult.MySkin_Concerns_Bar6 += 1;
            }


            AnalysisResult.MySkin_Concerns_Bar7 = (int)LoginSession.Result_SkinConcern_Rpt.transdermal; // ##경피수분손실도
            if (AnalysisResult.MySkin_Concerns_Bar7 == 0)
            {
                AnalysisResult.MySkin_Concerns_Bar7 += 1;
            }


            AnalysisResult.MySkin_Concerns_Bar8 = (int)LoginSession.Result_SkinConcern_Rpt.elasticity; // ##탄력
            if (AnalysisResult.MySkin_Concerns_Bar8 == 0)
            {
                AnalysisResult.MySkin_Concerns_Bar8 += 1;
            }

            if(LoginSession.SelectedMember.PCCD == "PC001014")
            {
                Third_Text8.Visibility = Visibility.Hidden;
                SkinConcerns_Bar8.Visibility = Visibility.Hidden;
                SkinConcerns_Text8.Visibility = Visibility.Hidden;            
            }
          
            




            //--- 4. 민감성 타입
            AnalysisResult.MySkin_Solution_Type = rpd.sensitive_type_number.ToString(); //##솔루션 타입
            AnalysisResult.MySkin_Solution_Text = rpd.sensitive_type_result.ToString(); //##솔루션 내용

            //--- 5. 피부 케어 팁
            Fifth_Text.Text = rpd.specialtip_memo;






            //1.분석결과
            //tb_SkinScore.Text = rpd.skin_score.ToString("N0");
            //rpde.skin_score = rpd.skin_score;



            // 솔루션 타입
            // tb_solution_type_number.Text = rpd.solution_type_number;

            // 분석 결과
            //tb_SensitiveType_result.Text = rpd.sensitive_type_result.ToString();


        }

        private void btn_PrintReady_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            btn_PrintReady.Visibility = Visibility.Collapsed;


            if (printDialog.ShowDialog().GetValueOrDefault())
            {
                Transform originTransform = this.LayoutTransform;
                Size originSize = new Size(this.ActualWidth, this.ActualHeight);

                double xStartPrint = 45;
                double yStartPrint = 50;

                PrintCapabilities capabilities = printDialog.PrintQueue.GetPrintCapabilities(printDialog.PrintTicket);

                double scale = Math.Min(capabilities.PageImageableArea.ExtentWidth / this.ActualWidth, capabilities.PageImageableArea.ExtentHeight /
                                this.ActualHeight);

                this.LayoutTransform = new ScaleTransform(scale, scale);

                Size sz = new Size(capabilities.PageImageableArea.ExtentWidth, capabilities.PageImageableArea.ExtentHeight);

                this.Measure(sz);
                // this.Arrange(new Rect(new Point(capabilities.PageImageableArea.OriginWidth, capabilities.PageImageableArea.OriginHeight), sz));
                this.Arrange(new Rect(new Point(xStartPrint, yStartPrint), sz));


                printDialog.PrintVisual(this, "Print MySkin Result_First");

                this.LayoutTransform = originTransform;
                this.Measure(originSize);
                this.Arrange(new Rect(new Point(0, 0), originSize));
            }

            btn_PrintReady.Visibility = Visibility.Visible;
        }

    }
}
