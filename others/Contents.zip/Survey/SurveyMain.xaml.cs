﻿using IOPE_LAB.Common;
using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Telerik.Windows.Controls;

namespace IOPE_LAB.Contents.Survey
{
    /// <summary>
    /// SurveyMain.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class SurveyMain : Page
    {
        public enum SurveyPageName
        {
            SurveyPage01, SurveyPage02, SurveyPage03
        }

        public SurveyMain()
        {
            InitializeComponent();

            this.btn_Back.Click += Btn_Back_Click;
            this.btn_Next.Click += Btn_Next_Click;
            this.btn_Submit.Click += Btn_Submit_Click;
        }

        private void Btn_Submit_Click(object sender, RoutedEventArgs e)
        {
            if (GetSurveyPageName() == SurveyPageName.SurveyPage02)
            {
                if (uc_SurveyPage01.GetCustomerInputValidation() == true && uc_SurveyPage02.GetCustomerInputValidation() == true)
                {
                    if (LoginSession.AdminContentFlag != true)
                    {
                        SurveyService.SurveyServiceClient ssc = new SurveyService.SurveyServiceClient();

                        //설문결과 변수 저장d
                        int result = ssc.Update_C_Survey(LoginSession.SelectedSurvey);

                        if (ssc.State == System.ServiceModel.CommunicationState.Closed)
                        {
                            ssc.Close();
                        }

                        if (result > 0)
                        {
                            Common.CommonMessageBox.ShowAlertMessage("저장 되었습니다.");
                            CommonBiz.SelectMenu(MainWindow.Menus.DevicePage);
                        }
                    }
                    else
                    {
                        Common.CommonMessageBox.ShowAlertMessage("관리자 기능 사용중엔 저장기능을 사용 할 수 없습니다.");
                    }
                }
                
            }
        }

        private void Btn_Next_Click(object sender, RoutedEventArgs e)
        {
            switch(GetSurveyPageName())
            {
                case SurveyPageName.SurveyPage01:
                    SetSurveyPageUI(SurveyPageName.SurveyPage02);
                    break;
                //case SurveyPageName.SurveyPage01_1:
                //    SetSurveyPageUI(SurveyPageName.SurveyPage02);
                //    break;
                case SurveyPageName.SurveyPage02:                    
                    break;
            }
        }

        private void Btn_Back_Click(object sender, RoutedEventArgs e)
        {
            switch (GetSurveyPageName())
            {
                //case SurveyPageName.SurveyPage01_1:
                //    SetSurveyPageUI(SurveyPageName.SurveyPage01);
                //    break;
                case SurveyPageName.SurveyPage02:
                    SetSurveyPageUI(SurveyPageName.SurveyPage01);
                    break;
            }
        }

        public SurveyPageName GetSurveyPageName()
        {
            SurveyPageName result = SurveyPageName.SurveyPage01;

            if (uc_SurveyPage01.Visibility == Visibility)
            {
                result = SurveyPageName.SurveyPage01;
            }
            //else if (uc_SurveyPage01_1.Visibility == Visibility.Visible)
            //{
            //    result = SurveyPageName.SurveyPage01_1;
            //}
            else if (uc_SurveyPage02.Visibility == Visibility.Visible)
            {
                result = SurveyPageName.SurveyPage02;
            }
            
            return result;
        }

        public void SetSurveyPageUI(SurveyPageName s_pagename)
        {
            switch (s_pagename)
            {
                case SurveyPageName.SurveyPage01:
                    uc_SurveyPage01.Visibility = Visibility.Visible;
                    //uc_SurveyPage01_1.Visibility = Visibility.Collapsed;
                    uc_SurveyPage02.Visibility = Visibility.Collapsed;
                    btn_Next.Visibility = Visibility.Visible;
                    btn_Back.Visibility = Visibility.Collapsed;
                    btn_Submit.Visibility = Visibility.Collapsed;
                    break;
                //case SurveyPageName.SurveyPage01_1:
                //    uc_SurveyPage01.Visibility = Visibility.Collapsed;
                //    uc_SurveyPage01_1.Visibility = Visibility.Visible;
                //    uc_SurveyPage02.Visibility = Visibility.Collapsed;
                //    btn_Next.Visibility = Visibility.Visible;
                //    btn_Back.Visibility = Visibility.Visible;
                //    btn_Submit.Visibility = Visibility.Collapsed;
                //    break;

                case SurveyPageName.SurveyPage02:
                    uc_SurveyPage01.Visibility = Visibility.Collapsed;
                    //uc_SurveyPage01_1.Visibility = Visibility.Collapsed;
                    uc_SurveyPage02.Visibility = Visibility.Visible;
                    btn_Next.Visibility = Visibility.Collapsed;
                    btn_Back.Visibility = Visibility.Visible;
                    btn_Submit.Visibility = Visibility.Visible;
                    break;

            }
        }
    }
}
