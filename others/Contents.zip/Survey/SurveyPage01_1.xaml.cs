﻿using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Survey
{
    /// <summary>
    /// SurveyPage01_1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class SurveyPage01_1 : UserControl
    {
        public SurveyPage01_1()
        {
            InitializeComponent();
            this.Loaded += SurveyPage01_1_Loaded;
            
            foreach (RadioButton rdo in grid_Q03_5_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q03_6_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }   
            //foreach (RadioButton rdo in grid_Q03_7_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            //foreach (RadioButton rdo in grid_Q03_8_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            //foreach (CheckBox cb in grid_Q03_9_checkbox_List.Children) { cb.Checked += new RoutedEventHandler(cb_Checked); }
            //foreach (RadioButton rdo in grid_Q03_10_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            //foreach (RadioButton rdo in grid_Q03_11_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            //foreach (CheckBox cb in grid_Q03_12_checkbox_List.Children) { cb.Checked += new RoutedEventHandler(cb_Checked); }
        }

        private void SurveyPage01_1_Loaded(object sender, RoutedEventArgs e)
        {
            SetData();
        }

        private void SetData()
        {
            if (LoginSession.SelectedSurvey != null)
            {
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_5) != true)
                    SetRadioCheck(grid_Q03_5_RadioList, LoginSession.SelectedSurvey.S3_5);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_6) != true)
                    SetRadioCheck(grid_Q03_6_RadioList, LoginSession.SelectedSurvey.S3_6);

                //if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_7) != true)
                //    SetRadioCheck(grid_Q03_7_RadioList, LoginSession.SelectedSurvey.S3_7);

                //if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_8) != true)
                //    SetRadioCheck(grid_Q03_8_RadioList, LoginSession.SelectedSurvey.S3_8);

                //if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_9) != true)
                //    SetCheckBox(grid_Q03_9_checkbox_List, LoginSession.SelectedSurvey.S3_9);

                //if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_10) != true)
                //    SetRadioCheck(grid_Q03_10_RadioList, LoginSession.SelectedSurvey.S3_10);

                //if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_11) != true)
                //    SetRadioCheck(grid_Q03_11_RadioList, LoginSession.SelectedSurvey.S3_11);

                //if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_12) != true)
                //    SetCheckBox(grid_Q03_12_checkbox_List, LoginSession.SelectedSurvey.S3_12);
            }
        }

        void cb_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                CheckBox cb = sender as CheckBox;
                Grid grid = cb.Parent as Grid;

                if (LoginSession.SelectedSurvey != null)
                {                 
                    switch (grid.Name)
                    {                 
                        case "grid_Q03_9_checkbox_List":
                            LoginSession.SelectedSurvey.S3_9 = (grid.Children.IndexOf(cb)).ToString();
                            break;
                        case "grid_Q03_12_checkbox_List":
                            LoginSession.SelectedSurvey.S3_12 = (grid.Children.IndexOf(cb)).ToString();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }

        }

        void rdo_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                RadioButton rdo = sender as RadioButton;
                Grid grid = rdo.Parent as Grid;

                if (LoginSession.SelectedSurvey != null)
                {
                    switch (grid.Name)
                    {
                        case "grid_Q03_5_RadioList":
                            LoginSession.SelectedSurvey.S3_5 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_6_RadioList":
                            LoginSession.SelectedSurvey.S3_6 = (grid.Children.IndexOf(rdo)).ToString();
                            break;                        
                        case "grid_Q03_7_RadioList":
                            LoginSession.SelectedSurvey.S3_7 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_8_RadioList":
                            LoginSession.SelectedSurvey.S3_8 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_10_RadioList":
                            LoginSession.SelectedSurvey.S3_10 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_11_RadioList":
                            LoginSession.SelectedSurvey.S3_11 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }

        }

        //변수체크
        public bool GetCustomerInputValidation()
        {
            //3-5번
            if (GetRadioCheck(grid_Q03_5_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str01); return false; }
            //3-6번
            if (GetRadioCheck(grid_Q03_6_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str02); return false; }
            ////3-7번
            //if (GetRadioCheck(grid_Q03_7_RadioList) != true)
            //{ Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str03); return false; }
            ////3-8번
            //if (GetRadioCheck(grid_Q03_8_RadioList) != true)
            //{ Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str04); return false; }
            ////3-9번
            //if (GetCheckBoxCheck(grid_Q03_9_checkbox_List) != true)
            //{ Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str05); return false; }
            ////3-10번
            //if (GetRadioCheck(grid_Q03_10_RadioList) != true)
            //{ Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str06); return false; }
            ////3-11번
            //if (GetRadioCheck(grid_Q03_11_RadioList) != true)
            //{ Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str07); return false; }
            ////3-12번
            //if (GetCheckBoxCheck(grid_Q03_12_checkbox_List) != true)
            //{ Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str08); return false; }

            if (LoginSession.SelectedSurvey != null)
            {
                //GetCheckString();
                LoginSession.SelectedSurvey.S3_5 = GetRadioValue(grid_Q03_5_RadioList);
                LoginSession.SelectedSurvey.S3_6 = GetRadioValue(grid_Q03_6_RadioList);
                //LoginSession.SelectedSurvey.S3_7 = GetRadioValue(grid_Q03_7_RadioList);
                //LoginSession.SelectedSurvey.S3_8 = GetRadioValue(grid_Q03_8_RadioList);
                //LoginSession.SelectedSurvey.S3_9 = GetCheckValue(grid_Q03_9_checkbox_List);
                //LoginSession.SelectedSurvey.S3_10 = GetRadioValue(grid_Q03_10_RadioList);
                //LoginSession.SelectedSurvey.S3_11 = GetRadioValue(grid_Q03_11_RadioList);
                //LoginSession.SelectedSurvey.S3_12 = GetCheckValue(grid_Q03_12_checkbox_List);
            }

            return true;
        }

        private void SetCheckBox(Grid grid_list, string checkNum)
        {
            try
            {
                int index = 0;

                if (checkNum.Contains("^"))
                {
                    string[] check_num_list = checkNum.Split('^');
                    foreach (string str in check_num_list)
                    {
                        index = int.Parse(str);
                        (grid_list.Children[index] as CheckBox).IsChecked = true;
                    }
                }
                else
                {
                    index = int.Parse(checkNum);
                    (grid_list.Children[index] as CheckBox).IsChecked = true;
                }
                
            }
            catch (Exception)
            {

            }
        }

        private void SetRadioCheck(Grid grid_list, string checkNum)
        {
            try
            {
                int index = int.Parse(checkNum);
                (grid_list.Children[index] as RadioButton).IsChecked = true;
            }
            catch (Exception)
            {

            }
        }

        //채크여부 가져오기
        public bool GetCheckBoxCheck(Grid grid)
        {
            foreach (CheckBox cb in grid.Children)
            {
                if (cb.IsChecked == true)
                {
                    return true;
                }
            }
            return false;
        }

        public bool GetRadioCheck(Grid grid)
        {
            foreach (RadioButton rdo in grid.Children)
            {
                if (rdo.IsChecked == true)
                {
                    return true;
                }
            }
            return false;
        }

        public string GetCheckValue(Grid grid)
        {
            List<string> countArr = new List<string>();
            string tempArray;

            foreach (CheckBox cb in grid.Children)
            {
                if (cb.IsChecked == true)
                {
                    countArr.Add((grid.Children.IndexOf(cb)).ToString());
                }
            }

            if (countArr.Count > 1)
            {
                tempArray = string.Join("^", countArr);
                return tempArray;
            }
            else
            {
                tempArray = string.Join("", countArr);
                return tempArray;
            }
        }
        public string GetRadioValue(Grid grid)
        {
            int cnt = 0;
            foreach (RadioButton rdo in grid.Children)
            {
                if (rdo.IsChecked == true)
                {
                    cnt = grid.Children.IndexOf(rdo);
                }
            }
            return cnt.ToString();
        }

    }
}
