﻿using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Survey
{
    /// <summary>
    /// SurveyPage02.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class SurveyPage02 : UserControl
    {
        public SurveyPage02()
        {
            InitializeComponent();

            this.Loaded += SurveyPage02_Loaded;

            foreach (RadioButton rdo in grid_Q03_5_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q03_6_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q04_1_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q04_2_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q04_3_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q04_4_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q04_4_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q04_4_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }

        }

        private void SurveyPage02_Loaded(object sender, RoutedEventArgs e)
        {
            SetData();
        }

        private void SetData()
        {
            if (LoginSession.SelectedSurvey != null)
            {
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_5) != true)
                    SetRadioCheck(grid_Q03_5_RadioList, LoginSession.SelectedSurvey.S3_5);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_6) != true)
                    SetRadioCheck(grid_Q03_6_RadioList, LoginSession.SelectedSurvey.S3_6);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S4_1) != true)
                    SetRadioCheck(grid_Q04_1_RadioList, LoginSession.SelectedSurvey.S4_1);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S4_2) != true)
                    SetRadioCheck(grid_Q04_2_RadioList, LoginSession.SelectedSurvey.S4_2);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S4_3) != true)
                    SetRadioCheck(grid_Q04_3_RadioList, LoginSession.SelectedSurvey.S4_3);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S4_4) != true)
                    SetRadioCheck(grid_Q04_4_RadioList, LoginSession.SelectedSurvey.S4_4);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S4_5) != true)
                    SetRadioCheck(grid_Q04_5_RadioList, LoginSession.SelectedSurvey.S4_5);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S4_6) != true)
                    SetRadioCheck(grid_Q04_6_RadioList, LoginSession.SelectedSurvey.S4_6);
            }
        }
        private void SetRadioCheck(Grid grid_list, string checkNum)
        {
            try
            {
                int index = int.Parse(checkNum);
                (grid_list.Children[index] as RadioButton).IsChecked = true;
            }
            catch (Exception ex)
            {

            }
        }

        void rdo_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rdo = sender as RadioButton;
            Grid grid = rdo.Parent as Grid;
            switch (grid.Name)
            {
                case "grid_Q03_5_RadioList":
                    LoginSession.SelectedSurvey.S3_5 = (grid.Children.IndexOf(rdo)).ToString();
                    break;
                case "grid_Q03_6_RadioList":
                    LoginSession.SelectedSurvey.S3_6 = (grid.Children.IndexOf(rdo)).ToString();
                    break;
                case "grid_Q04_1_RadioList":
                    LoginSession.SelectedSurvey.S4_1 = (grid.Children.IndexOf(rdo)).ToString();
                    break;
                case "grid_Q04_2_RadioList":
                    LoginSession.SelectedSurvey.S4_2 = (grid.Children.IndexOf(rdo)).ToString();
                    break;
                case "grid_Q04_3_RadioList":
                    LoginSession.SelectedSurvey.S4_3 = (grid.Children.IndexOf(rdo)).ToString();
                    break;
                case "grid_Q04_4_RadioList":
                    LoginSession.SelectedSurvey.S4_4 = (grid.Children.IndexOf(rdo)).ToString();
                    break;
                case "grid_Q04_5_RadioList":
                    LoginSession.SelectedSurvey.S4_5 = (grid.Children.IndexOf(rdo)).ToString();
                    break;
                case "grid_Q04_6_RadioList":
                    LoginSession.SelectedSurvey.S4_6 = (grid.Children.IndexOf(rdo)).ToString();
                    break;
            }
        }

        //변수체크
        public bool GetCustomerInputValidation()
        {
            //3-5번
            if (GetRadioCheck(grid_Q03_5_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str01); return false; }
            //3-6번
            if (GetRadioCheck(grid_Q03_6_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_1_str02); return false; }
            //4-1번
            if (GetRadioCheck(grid_Q04_1_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str20); return false; }
            //4-2번
            if (GetRadioCheck(grid_Q04_2_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str21); return false; }
            //4-3번
            if (GetRadioCheck(grid_Q04_3_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str22); return false; }
            //4-4번
            if (GetRadioCheck(grid_Q04_4_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str23); return false; }
            //4-5번
            if (GetRadioCheck(grid_Q04_5_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str24); return false; }
            //4-6번
            if (GetRadioCheck(grid_Q04_6_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str25); return false; }

            if (LoginSession.SelectedSurvey != null)
            {
                //GetCheckString();
                LoginSession.SelectedSurvey.S3_5 = GetRadioValue(grid_Q03_5_RadioList);
                LoginSession.SelectedSurvey.S3_6 = GetRadioValue(grid_Q03_6_RadioList);
                LoginSession.SelectedSurvey.S4_1 = GetRadioValue(grid_Q04_1_RadioList);
                LoginSession.SelectedSurvey.S4_2 = GetRadioValue(grid_Q04_2_RadioList);
                LoginSession.SelectedSurvey.S4_3 = GetRadioValue(grid_Q04_3_RadioList);
                LoginSession.SelectedSurvey.S4_4 = GetRadioValue(grid_Q04_4_RadioList);
                LoginSession.SelectedSurvey.S4_5 = GetRadioValue(grid_Q04_5_RadioList);
                LoginSession.SelectedSurvey.S4_6 = GetRadioValue(grid_Q04_6_RadioList);
            }

            return true;
        }

        //채크여부 가져오기
        public bool GetRadioCheck(Grid grid)
        {
            foreach (RadioButton rdo in grid.Children)
            {
                if (rdo.IsChecked == true)
                {
                    return true;
                }
            }
            return false;
        }

        //채크된 번호 가져오기
        public string GetRadioValue(Grid grid)
        {
            int cnt = 0;
            foreach (RadioButton rdo in grid.Children)
            {
                if (rdo.IsChecked == true)
                {
                    cnt = grid.Children.IndexOf(rdo);
                }
            }
            return cnt.ToString();
        }
    }
}
