﻿using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.Survey
{
    /// <summary>
    /// SurveyPage01.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class SurveyPage01 : UserControl
    {
        public SurveyPage01()
        {
            InitializeComponent();

            this.Loaded += SurveyPage01_Loaded;

            foreach (RadioButton rdo in grid_Q02_1_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_2_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_3_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q02_4_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }

            foreach (RadioButton rdo in grid_Q03_1_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q03_2_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q03_3_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
            foreach (RadioButton rdo in grid_Q03_4_RadioList.Children) { rdo.Checked += new RoutedEventHandler(rdo_Checked); }
        }

        private void SurveyPage01_Loaded(object sender, RoutedEventArgs e)
        {
            SetData();
        }

        private void SetData()
        {
            if (LoginSession.SelectedSurvey != null)
            {
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_1) != true)
                    SetCheckBox(cb_Q01, LoginSession.SelectedSurvey.S1_1);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_2) != true)
                    SetCheckBox(cb_Q02, LoginSession.SelectedSurvey.S1_2);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_3) != true)
                    SetCheckBox(cb_Q03, LoginSession.SelectedSurvey.S1_3);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_4) != true)
                    SetCheckBox(cb_Q04, LoginSession.SelectedSurvey.S1_4);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_5) != true)
                    SetCheckBox(cb_Q05, LoginSession.SelectedSurvey.S1_5);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_6) != true)
                    SetCheckBox(cb_Q06, LoginSession.SelectedSurvey.S1_6);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_7) != true)
                    SetCheckBox(cb_Q07, LoginSession.SelectedSurvey.S1_7);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_8) != true)
                    SetCheckBox(cb_Q08, LoginSession.SelectedSurvey.S1_8);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_9) != true)
                    SetCheckBox(cb_Q09, LoginSession.SelectedSurvey.S1_9);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_10) != true)
                    SetCheckBox(cb_Q10, LoginSession.SelectedSurvey.S1_10);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_11) != true)
                    SetCheckBox(cb_Q11, LoginSession.SelectedSurvey.S1_11);
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_12) != true)
                    SetCheckBox(cb_Q12, LoginSession.SelectedSurvey.S1_12);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_First) != true)
                    tb_first.Text = LoginSession.SelectedSurvey.S1_First;
                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S1_Second) != true)
                    tb_second.Text = LoginSession.SelectedSurvey.S1_Second;



                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S2_1) != true)
                    SetRadioCheck(grid_Q02_1_RadioList, LoginSession.SelectedSurvey.S2_1);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S2_2) != true)
                    SetRadioCheck(grid_Q02_2_RadioList, LoginSession.SelectedSurvey.S2_2);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S2_3) != true)
                    SetRadioCheck(grid_Q02_3_RadioList, LoginSession.SelectedSurvey.S2_3);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S2_4) != true)
                    SetRadioCheck(grid_Q02_4_RadioList, LoginSession.SelectedSurvey.S2_4);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_1) != true)
                    SetRadioCheck(grid_Q03_1_RadioList, LoginSession.SelectedSurvey.S3_1);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_2) != true)
                    SetRadioCheck(grid_Q03_2_RadioList, LoginSession.SelectedSurvey.S3_2);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_3) != true)
                    SetRadioCheck(grid_Q03_3_RadioList, LoginSession.SelectedSurvey.S3_3);

                if (string.IsNullOrWhiteSpace(LoginSession.SelectedSurvey.S3_4) != true)
                    SetRadioCheck(grid_Q03_4_RadioList, LoginSession.SelectedSurvey.S3_4);

            }
        }

        private void SetRadioBox(RadioButton radiobox, string str_IsCheckYN)
        {
            if (str_IsCheckYN == "Y")
            {
                radiobox.IsChecked = true;
            }
        }

        private void SetCheckBox(CheckBox checkbox, string str_IsCheckYN)
        {
            if (str_IsCheckYN == "Y")
            {
                checkbox.IsChecked = true;
            }
        }

        void rdo_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                RadioButton rdo = sender as RadioButton;
                Grid grid = rdo.Parent as Grid;

                if (LoginSession.SelectedSurvey != null)
                {
                    switch (grid.Name)
                    {
                        case "grid_Q02_1_RadioList":
                            LoginSession.SelectedSurvey.S2_1 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q02_2_RadioList":
                            LoginSession.SelectedSurvey.S2_2 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q02_3_RadioList":
                            LoginSession.SelectedSurvey.S2_3 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q02_4_RadioList":
                            LoginSession.SelectedSurvey.S2_4 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_1_RadioList":
                            LoginSession.SelectedSurvey.S3_1 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_2_RadioList":
                            LoginSession.SelectedSurvey.S3_2 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_3_RadioList":
                            LoginSession.SelectedSurvey.S3_3 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                        case "grid_Q03_4_RadioList":
                            LoginSession.SelectedSurvey.S3_4 = (grid.Children.IndexOf(rdo)).ToString();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }

        }

        private void SetRadioCheck(Grid grid_list, string checkNum)
        {
            try
            {
                int index = int.Parse(checkNum);
                (grid_list.Children[index] as RadioButton).IsChecked = true;
            }
            catch (Exception)
            {

            }
        }

        //변수체크
        public bool GetCustomerInputValidation()
        {
            //고민부위(체크박스)2개 이상 선택
            int check_count = 0;

            if (cb_Q01.IsChecked == true)
                check_count++;
            if (cb_Q02.IsChecked == true)
                check_count++;
            if (cb_Q03.IsChecked == true)
                check_count++;
            if (cb_Q04.IsChecked == true)
                check_count++;
            if (cb_Q05.IsChecked == true)
                check_count++;
            if (cb_Q06.IsChecked == true)
                check_count++;
            if (cb_Q07.IsChecked == true)
                check_count++;
            if (cb_Q08.IsChecked == true)
                check_count++;
            if (cb_Q09.IsChecked == true)
                check_count++;
            if (cb_Q10.IsChecked == true)
                check_count++;
            if (cb_Q11.IsChecked == true)
                check_count++;
            if (cb_Q12.IsChecked == true)
                check_count++;

            if (check_count < 2)
            {
                Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_12);
                cb_Q01.Focus();
                return false;
            }

            //1순위 텍스트 입력
            if (string.IsNullOrWhiteSpace(tb_first.Text) == true)
            {
                Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_13);
                tb_first.Focus();
                return false;
            }


            //2순위 텍스트 입력
            if (string.IsNullOrWhiteSpace(tb_second.Text) == true)
            {
                Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.showAlert_14);
                tb_second.Focus();
                return false;
            }
           
            //2-1번
            if (GetRadioCheck(grid_Q02_1_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str20); (grid_Q02_1_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //2-2번
            if (GetRadioCheck(grid_Q02_2_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str21); (grid_Q02_2_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //2-3번
            if (GetRadioCheck(grid_Q02_3_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str22); (grid_Q02_3_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //2-4번
            if (GetRadioCheck(grid_Q02_4_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str23); (grid_Q02_4_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //3-1번
            if (GetRadioCheck(grid_Q03_1_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str24); (grid_Q03_1_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //3-2번
            if (GetRadioCheck(grid_Q03_2_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str25); (grid_Q03_2_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //3-3번
            if (GetRadioCheck(grid_Q03_3_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str26); (grid_Q03_3_RadioList.Children[0] as RadioButton).Focus(); return false; }
            //3-4번
            if (GetRadioCheck(grid_Q03_4_RadioList) != true)
            { Common.CommonMessageBox.ShowAlertMessage(IOPE_LAB_LOCALIZATION.Properties.Resources.SurveyPage01_str27); (grid_Q03_4_RadioList.Children[0] as RadioButton).Focus(); return false; }


            if (LoginSession.SelectedSurvey != null)
            {
                //GetCheckString();
                LoginSession.SelectedSurvey.S1_1 = cb_Q01.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_2 = cb_Q02.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_3 = cb_Q03.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_4 = cb_Q04.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_5 = cb_Q05.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_6 = cb_Q06.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_7 = cb_Q07.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_8 = cb_Q08.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_9 = cb_Q09.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_10 = cb_Q10.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_11 = cb_Q11.IsChecked == true ? "Y" : "N";
                LoginSession.SelectedSurvey.S1_12 = cb_Q12.IsChecked == true ? "Y" : "N";

                LoginSession.SelectedSurvey.S1_First = tb_first.Text;
                LoginSession.SelectedSurvey.S1_Second = tb_second.Text;

                LoginSession.SelectedSurvey.S2_1 = GetRadioValue(grid_Q02_1_RadioList);
                LoginSession.SelectedSurvey.S2_2 = GetRadioValue(grid_Q02_2_RadioList);
                LoginSession.SelectedSurvey.S2_3 = GetRadioValue(grid_Q02_3_RadioList);
                LoginSession.SelectedSurvey.S2_4 = GetRadioValue(grid_Q02_4_RadioList);

                LoginSession.SelectedSurvey.S3_1 = GetRadioValue(grid_Q03_1_RadioList);
                LoginSession.SelectedSurvey.S3_2 = GetRadioValue(grid_Q03_2_RadioList);
                LoginSession.SelectedSurvey.S3_3 = GetRadioValue(grid_Q03_3_RadioList);
                LoginSession.SelectedSurvey.S3_4 = GetRadioValue(grid_Q03_4_RadioList);
            }

            return true;
        }

        //채크여부 가져오기
        public bool GetRadioCheck(Grid grid)
        {
            foreach (RadioButton rdo in grid.Children)
            {
                if (rdo.IsChecked == true)
                {
                    return true;
                }
            }
            return false;
        }

        //채크된 번호 가져오기
        public string GetRadioValue(Grid grid)
        {
            int cnt = 0;
            foreach (RadioButton rdo in grid.Children)
            {
                if (rdo.IsChecked == true)
                {
                    cnt = grid.Children.IndexOf(rdo);
                }
            }
            return cnt.ToString();
        }
    }
}
