﻿using IOPE_LAB.Common;
using IOPE_LAB.Popup;
using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using IOPE_LAB_DEVICE;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using Telerik.Windows.Documents.Model.Drawing.Charts;

namespace IOPE_LAB.Contents
{
    /// <summary>
    /// ReservationStateListPage.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ReservationStateListPage : Page
    {
        public Timer ti;
        static HttpClient client = new HttpClient();

        public ReservationStateListPage()
        {
            InitializeComponent();

            if (LoginSession.ProgramCourseflg != "I")
            {
                //두피 프로그램
                if (LoginSession.Background_PCCD == "PC001010")
                {
                    intensive_sch.Visibility = Visibility.Collapsed;
                    intensive_sch_online.Visibility = Visibility.Collapsed;
                    basic_sch.Visibility = Visibility.Collapsed;
                    basic_sch_online.Visibility = Visibility.Collapsed;
                    direct_sch.Visibility = Visibility.Collapsed;
                }
                //Basic 프로그램
                else
                {
                    intensive_sch.Visibility = Visibility.Collapsed;
                    intensive_sch_online.Visibility = Visibility.Collapsed;
                    basic_sch.Visibility = Visibility.Visible;
                    basic_sch_online.Visibility = Visibility.Visible;
                    scalp_sch_online.Visibility = Visibility.Collapsed;
                    scalp_direct.Visibility = Visibility.Collapsed;
                }
            }

            //Intensive 프로그램
            else
            {
                intensive_sch.Visibility = Visibility.Visible;
                intensive_sch_online.Visibility = Visibility.Visible;
                direct_sch.Title = "마이 스킨 솔루션 (Site)";
                basic_sch.Visibility = Visibility.Collapsed;
                basic_sch_online.Visibility = Visibility.Collapsed;
                scalp_sch_online.Visibility = Visibility.Collapsed;
                scalp_direct.Visibility = Visibility.Collapsed;
            }

            InitEvent();
        }

        void ti_Tick(object sender, EventArgs e)
        {
            if (NetworkInterface.GetIsNetworkAvailable())
                GetVisitSchLoad();
            else
            {
                if (ti.Enabled == true)
                {
                    ti.Stop();
                    ti.Dispose();
                }
            }
        }

        private void GetVisitSchLoad()
        {
            try
            {
                DateTime nowDate;

                try
                {
                    nowDate = rad_datepicker.SelectedDate.Value;
                }
                catch (Exception)
                {
                    return;
                }

                //테스트
                //nowDate = Convert.ToDateTime("2020-05-13");
                //DateTime nowDate = Convert.ToDateTime("2018-01-11");

                basic_sch.ClearItems();
                basic_sch_online.ClearItems();

                intensive_sch.ClearItems();
                intensive_sch_online.ClearItems();

                direct_sch.ClearItems();

                scalp_sch_online.ClearItems();
                scalp_direct.ClearItems();

                MemberService.MemberServiceClient msc = new MemberService.MemberServiceClient();
                //시티랩 경우 현재 예약정보가 없습니다.
                List<VisitSch> visit = msc.Get_C_VisitSch(nowDate.ToString("yyyy-MM-dd"), nowDate.ToString("yyyy-MM-dd")).ToList();
                //List<VisitSch> visit = new List<VisitSch> { };

                List<VisitDirect> visit_direct = msc.Get_C_VisitDirect(nowDate.ToString("yyyy-MM-dd"), nowDate.ToString("yyyy-MM-dd")).ToList();

                if (msc.State != System.ServiceModel.CommunicationState.Closed)
                {
                    msc.Close();
                }

                if (visit.Count > 0)
                {

                    List<VisitSch> basic_list = visit.Where(data =>
                    data.PCCD.ToString() == "PC001002"
                    || data.PCCD.ToString() == "PC001003"
                    || data.PCCD.ToString() == "PC001004"
                    || data.PCCD.ToString() == "PC001005"
                    ).ToList();

                    List<VisitSch> basic_list_online = visit.Where(data =>
                    data.PCCD.ToString() == "PC001014"
                    ).ToList();

                    basic_sch.SetBind(basic_list, Member.ENUM_COURSE.BASIC);
                    basic_sch.Sortitems();

                    basic_sch_online.SetBind(basic_list_online, Member.ENUM_COURSE.BASIC);
                    basic_sch_online.Sortitems();

                    //List<VisitSch> intensive_list = visit.Where(data => data.course_flg.ToString() == "I" ).ToList();
                    List<VisitSch> intensive_list = visit.Where(data =>
                        data.PCCD.ToString() == "PC001009"
                    ).ToList();

                    List<VisitSch> intensive_list_online = visit.Where(data =>
                        data.PCCD.ToString() == "PC001013"
                    ).ToList();

                    //List<VisitSch> intensive_list_orderby = intensive_list.OrderBy(p => p.rsvn_time).ToList();
                    intensive_sch.SetBind(intensive_list, Member.ENUM_COURSE.INTENSIVE);
                    intensive_sch.Sortitems();

                    intensive_sch_online.SetBind(intensive_list_online, Member.ENUM_COURSE.INTENSIVE);
                    intensive_sch_online.Sortitems();

                    //두피 온라인 예약
                    List<VisitSch> scalp_list_online = visit.Where(data =>
                        data.PCCD.ToString() == "PC001010"
                    ).ToList();

                    scalp_sch_online.SetBind(scalp_list_online, Member.ENUM_COURSE.BASIC);
                    scalp_sch_online.Sortitems();

                }

                if (visit_direct.Count > 0)
                {
                    direct_sch.ClearItems();

                    List<VisitDirect> direct_list = null;

                    if (LoginSession.ProgramCourseflg == "B")
                    {
                        if (LoginSession.Background_PCCD == "PC001010")
                        {
                            direct_list = visit_direct.Where(data => data.course_flg.ToString() == "B" && data.brandCourse.Equals("IC") && data.PCCD.Equals("PC001010")).ToList();
                            scalp_direct.SetBind(direct_list, Member.ENUM_COURSE.DIRECT);
                        }
                        else
                        {
                            direct_list = visit_direct.Where(data => data.course_flg.ToString() == "B" && data.brandCourse.Equals("IC") && !data.PCCD.Equals("PC001010")).ToList();
                            //direct_list = visit_direct.Where(data => data.course_flg.ToString() == "B").ToList();
                            direct_sch.SetBind(direct_list, Member.ENUM_COURSE.DIRECT);
                        }
                    }
                    else
                    {
                        direct_list = visit_direct.Where(data => data.course_flg.ToString() == "I" && data.brandCourse.Equals("IC") && !data.PCCD.Equals("PC001010")).ToList();
                        //direct_list = visit_direct.Where(data => data.course_flg.ToString() == "I").ToList();
                        direct_sch.SetBind(direct_list, Member.ENUM_COURSE.DIRECT);
                    }
                }

            }
            catch (Exception ex)
            {
                if (ti != null)
                {
                    if (ti.Enabled == true)
                    {
                        ti.Stop();
                        ti.Dispose();
                    }
                }

                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        void ReservationStateListPage_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                LoginSession.SelectedVisitSchMember = null;
                LoginSession.SelectedMember = null;
                LoginSession.SelectedSurvey = null;
                LoginSession.SelectedSurvey_M = null;
                LoginSession.SelectedM_Antera = null;
                LoginSession.SelectedM_CNK_Customer = null;
                LoginSession.SelectedM_CNK_Sebumeter = null;
                LoginSession.SelectedM_Vapometer = null;
                LoginSession.SelectedM_Markvu_ResultData = null;
                LoginSession.SelectedM_Markvu_Capture = null;
                LoginSession.Selected_C_ResultPageData = null;
                LoginSession.Selected_C_ResultPageData_M = null;

                LoginSession.AdminContentFlag = false;

                CommonBiz.SetMemberTopText(null);

                rad_datepicker.SelectedDate = DateTime.Now;

                GetVisitSchLoad();
            }
            catch (Exception ex)
            {
                if (ti != null)
                {
                    if (ti.Enabled == true)
                    {
                        ti.Stop();
                        ti.Dispose();
                    }
                }

                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        private void InitEvent()
        {
            this.Loaded += new RoutedEventHandler(ReservationStateListPage_Loaded);
            this.btn_Refresh.Click += Btn_Refresh_Click;
            this.btn_Customer_Input.Click += new RoutedEventHandler(btn_Customer_Input_Click);

            this.basic_sch.reservationListBox_DoubleClick += new UserControls.ReservationListBox.ReservationListBox_DoubleClick(reservationListBox_DoubleClick);
            this.basic_sch_online.reservationListBox_DoubleClick += new UserControls.ReservationListBox.ReservationListBox_DoubleClick(reservationListBox_DoubleClick);

            this.intensive_sch.reservationListBox_DoubleClick += new UserControls.ReservationListBox.ReservationListBox_DoubleClick(reservationListBox_DoubleClick);
            this.intensive_sch_online.reservationListBox_DoubleClick += new UserControls.ReservationListBox.ReservationListBox_DoubleClick(reservationListBox_DoubleClick);

            //두피예약고객 아직 미정
            this.scalp_sch_online.reservationListBox_DoubleClick += new UserControls.ReservationListBox.ReservationListBox_DoubleClick(reservationListBox_DoubleClick);

            this.scalp_direct.reservationListBox_DoubleClick += new UserControls.ReservationListBox.ReservationListBox_DoubleClick(reservationListBox_DoubleClick);

            //this.added_sch.reservationListBox_DoubleClick += new UserControls.ReservationListBox.ReservationListBox_DoubleClick(reservationListBox_DoubleClick);

            this.direct_sch.reservationListBox_DoubleClick += new UserControls.ReservationListBox.ReservationListBox_DoubleClick(reservationListBox_DoubleClick);

            this.rad_datepicker.KeyDown += Rad_datepicker_KeyDown;
        }


        private void Rad_datepicker_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {



            switch (e.Key)
            {
                case Key.Enter:
                    basic_sch.ClearItems();
                    direct_sch.ClearItems();
                    GetVisitSchLoad();
                    break;
            }
        }

        private void Btn_Refresh_Click(object sender, RoutedEventArgs e)
        {
            GetVisitSchLoad();
        }

        //Header 통신 설정 및 유전자 결과조회 API 통신
        public async Task<MySolutionViewModel> RunBarcodeAsync(string ucstmid)
        {
            //운영
            string config_Url = "https://citylab.amorepacific.com";

            //개발
            //string config_Url = "https://dev-geno.iope.com";
            string resultString = string.Empty;
            string returnString = string.Empty;
            string logTimes = DateTime.Now.ToString("yyyy-MM-dd-HH시mm분ss초");
            MySolutionViewModel genoResultList = new MySolutionViewModel();

            try
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                
                var response = await client.GetAsync(config_Url + "/gpiopeApi/genoResult?btCustIdNo=" + ucstmid + "&btCustIdNoClassifiCode=01").ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                {
                    resultString = await response.Content.ReadAsStringAsync();
                    var output1 = JObject.Parse(resultString);
                    var arrData = output1["result"];

                    if (arrData.Count() > 0)
                    {
                        if (!string.IsNullOrEmpty(resultString))
                        {

                            foreach (var objData in arrData)
                            {
                                try
                                {
                                    if (objData["skin_pigmentation"] != null)
                                    {
                                        genoResultList.Item1 = objData["skin_pigmentation"].ToString(); //item1 
                                    }
                                    else if (objData["skin_aging"] != null)
                                    {
                                        genoResultList.Item2 = objData["skin_aging"].ToString(); //item2 
                                    }
                                    else if (objData["androgenetic_alopecia"] != null)
                                    {
                                        genoResultList.Item3 = objData["androgenetic_alopecia"].ToString(); //item3
                                    }

                                    else if (objData["hair_thickness"] != null)
                                    {
                                        genoResultList.Item4 = objData["hair_thickness"].ToString(); //item4
                                    }

                                    else if (objData["freckles"] != null)
                                    {
                                        genoResultList.Item5 = objData["freckles"].ToString(); //item5
                                    }

                                    else if (objData["acne"] != null)
                                    {
                                        genoResultList.Item6 = objData["acne"].ToString(); //item6
                                    }

                                    else if (objData["skin_inflammation"] != null)
                                    {
                                        genoResultList.Item7 = objData["skin_inflammation"].ToString(); //item7
                                    }

                                    else if (objData["tanning"] != null)
                                    {
                                        genoResultList.Item8 = objData["tanning"].ToString(); //item8
                                    }

                                    else if (objData["dead_skin_cells"] != null)
                                    {
                                        genoResultList.Item9 = objData["dead_skin_cells"].ToString();   //item9
                                    }

                                    else if (objData["aplopecia_areata"] != null)
                                    {
                                        genoResultList.Item10 = objData["aplopecia_areata"].ToString(); //item10
                                    }

                                    else if (objData["hair_greying"] != null)
                                    {
                                        genoResultList.Item11 = objData["hair_greying"].ToString(); //item11
                                    }

                                    else if (objData["vitamin_c"] != null)
                                    {
                                        genoResultList.Item12 = objData["vitamin_c"].ToString(); //item12
                                    }

                                    else if (objData["vitamin_d"] != null)
                                    {
                                        genoResultList.Item13 = objData["vitamin_d"].ToString(); //item13
                                    }

                                    else if (objData["coenzyme_q10"] != null)
                                    {
                                        genoResultList.Item14 = objData["coenzyme_q10"].ToString(); //item14
                                    }

                                    else if (objData["magnesium"] != null)
                                    {
                                        genoResultList.Item15 = objData["magnesium"].ToString(); //item15
                                    }

                                    else if (objData["zinc"] != null)
                                    {
                                        genoResultList.Item16 = objData["zinc"].ToString();//item16
                                    }

                                    else if (objData["iron"] != null)
                                    {
                                        genoResultList.Item17 = objData["iron"].ToString(); //item17
                                    }

                                    else if (objData["potassium"] != null)
                                    {
                                        genoResultList.Item18 = objData["potassium"].ToString();  //item18
                                    }

                                    else if (objData["calcium"] != null)
                                    {
                                        genoResultList.Item19 = objData["calcium"].ToString();  //item19
                                    }

                                    else if (objData["arginine"] != null)
                                    {
                                        genoResultList.Item20 = objData["arginine"].ToString();  //item20
                                    }

                                    else if (objData["fatty_acid"] != null)
                                    {
                                        genoResultList.Item21 = objData["fatty_acid"].ToString();  //item21
                                    }

                                    else if (objData["vitamin_a"] != null)
                                    {
                                        genoResultList.Item22 = objData["vitamin_a"].ToString();   //item22
                                    }
                                    else if (objData["vitamin_b6"] != null)
                                    {
                                        genoResultList.Item23 = objData["vitamin_b6"].ToString();  //item23
                                    }

                                    else if (objData["vitamin_e"] != null)
                                    {
                                        genoResultList.Item24 = objData["vitamin_e"].ToString();  //item24
                                    }

                                    else if (objData["vitamin_k"] != null)
                                    {
                                        genoResultList.Item25 = objData["vitamin_k"].ToString();  //item25
                                    }
                                    else if (objData["vitamin_b12"] != null)
                                    {
                                        genoResultList.Item26 = objData["vitamin_b12"].ToString();  //item26
                                    }

                                    else if (objData["tyrosine"] != null)
                                    {
                                        genoResultList.Item27 = objData["tyrosine"].ToString();  //item27
                                    }

                                    else if (objData["betaine"] != null)
                                    {
                                        genoResultList.Item28 = objData["betaine"].ToString();  //item28
                                    }

                                    else if (objData["selenium"] != null)
                                    {
                                        genoResultList.Item29 = objData["selenium"].ToString();  //item29
                                    }

                                    else if (objData["lutein"] != null)
                                    {
                                        genoResultList.Item30 = objData["lutein"].ToString();  //item30
                                    }
                                    else if (objData["triglycerides"] != null)
                                    {
                                        genoResultList.Item31 = objData["triglycerides"].ToString();  //item31
                                    }

                                    else if (objData["bmi"] != null)
                                    {
                                        genoResultList.Item32 = objData["bmi"].ToString();  //item32
                                    }

                                    else if (objData["cholesterol"] != null)
                                    {
                                        genoResultList.Item33 = objData["cholesterol"].ToString();  //item33
                                    }

                                    else if (objData["blood_sugar"] != null)
                                    {
                                        genoResultList.Item34 = objData["blood_sugar"].ToString();  //item34
                                    }

                                    else if (objData["blood_pressure"] != null)
                                    {
                                        genoResultList.Item35 = objData["blood_pressure"].ToString();  //item35
                                    }

                                    else if (objData["obesity"] != null)
                                    {
                                        genoResultList.Item36 = objData["obesity"].ToString();  //item36
                                    }

                                    else if (objData["motion_sickness"] != null)
                                    {
                                        genoResultList.Item37 = objData["motion_sickness"].ToString();  //item37
                                    }

                                    else if (objData["bone_density"] != null)
                                    {
                                        genoResultList.Item38 = objData["bone_density"].ToString();  //item38
                                    }

                                    else if (objData["osteoarthritis"] != null)
                                    {
                                        genoResultList.Item39 = objData["osteoarthritis"].ToString();  //item39
                                    }

                                    else if (objData["uric_acid"] != null)
                                    {
                                        genoResultList.Item40 = objData["uric_acid"].ToString();  //item40
                                    }

                                    else if (objData["body_fat_percentage"] != null)
                                    {
                                        genoResultList.Item41 = objData["body_fat_percentage"].ToString();  //item41
                                    }

                                    else if (objData["abdominal_obesity"] != null)
                                    {
                                        genoResultList.Item42 = objData["abdominal_obesity"].ToString();  //item42
                                    }

                                    else if (objData["weight_loss"] != null)
                                    {
                                        genoResultList.Item43 = objData["weight_loss"].ToString();  //item43
                                    }

                                    else if (objData["yoyo_effect"] != null)
                                    {
                                        genoResultList.Item44 = objData["yoyo_effect"].ToString();  //item44
                                    }

                                    else if (objData["caffein_matebolism"] != null)
                                    {
                                        genoResultList.Item45 = objData["caffein_matebolism"].ToString();  //item45
                                    }

                                    else if (objData["alcohol_metabolism"] != null)
                                    {
                                        genoResultList.Item46 = objData["alcohol_metabolism"].ToString();  //item46
                                    }

                                    else if (objData["alcohol_dependency"] != null)
                                    {
                                        genoResultList.Item47 = objData["alcohol_dependency"].ToString();  //item47
                                    }

                                    else if (objData["alcohol_flushing"] != null)
                                    {
                                        genoResultList.Item48 = objData["alcohol_flushing"].ToString();  //item48
                                    }

                                    else if (objData["wine_preference"] != null)
                                    {
                                        genoResultList.Item49 = objData["wine_preference"].ToString();  //item49
                                    }

                                    else if (objData["nicotine_metabolism"] != null)
                                    {
                                        genoResultList.Item50 = objData["nicotine_metabolism"].ToString();  //item50
                                    }

                                    else if (objData["nicotine_dependency"] != null)
                                    {
                                        genoResultList.Item51 = objData["nicotine_dependency"].ToString();  //item51
                                    }

                                    else if (objData["caffein_dependency"] != null)
                                    {
                                        genoResultList.Item52 = objData["caffein_dependency"].ToString();  //item52
                                    }

                                    else if (objData["insomnia"] != null)
                                    {
                                        genoResultList.Item53 = objData["insomnia"].ToString();  //item53
                                    }

                                    else if (objData["sleep_duration"] != null)
                                    {
                                        genoResultList.Item54 = objData["sleep_duration"].ToString();  //item54
                                    }

                                    else if (objData["morning_person"] != null)
                                    {
                                        genoResultList.Item55 = objData["morning_person"].ToString();  //item55
                                    }

                                    else if (objData["pain_sensitivity"] != null)
                                    {
                                        genoResultList.Item56 = objData["pain_sensitivity"].ToString();  //item56
                                    }

                                    else if (objData["power_exercise"] != null)
                                    {
                                        genoResultList.Item57 = objData["power_exercise"].ToString();  //item57
                                    }

                                    else if (objData["aerobic_exercise"] != null)
                                    {
                                        genoResultList.Item58 = objData["aerobic_exercise"].ToString();  //item58
                                    }

                                    else if (objData["endurance_exercise"] != null)
                                    {
                                        genoResultList.Item59 = objData["endurance_exercise"].ToString();  //item59
                                    }

                                    else if (objData["muscle_develop"] != null)
                                    {
                                        genoResultList.Item60 = objData["muscle_develop"].ToString();  //item60
                                    }

                                    else if (objData["sprint"] != null)
                                    {
                                        genoResultList.Item61 = objData["sprint"].ToString();  //item61
                                    }

                                    else if (objData["ankle_injury"] != null)
                                    {
                                        genoResultList.Item62 = objData["ankle_injury"].ToString();  //item62
                                    }

                                    else if (objData["grip_strength"] != null)
                                    {
                                        genoResultList.Item63 = objData["grip_strength"].ToString();  //item63
                                    }

                                    else if (objData["recovery"] != null)
                                    {
                                        genoResultList.Item64 = objData["recovery"].ToString();  //item64
                                    }

                                    else if (objData["appetite"] != null)
                                    {
                                        genoResultList.Item65 = objData["appetite"].ToString();  //item65
                                    }

                                    else if (objData["satiety"] != null)
                                    {
                                        genoResultList.Item66 = objData["satiety"].ToString();  //item66
                                    }

                                    else if (objData["sweetness_sensitivity"] != null)
                                    {
                                        genoResultList.Item67 = objData["sweetness_sensitivity"].ToString();  //item67
                                    }

                                    else if (objData["bitterness_sensitivity"] != null)
                                    {
                                        genoResultList.Item68 = objData["bitterness_sensitivity"].ToString();  //item68
                                    }

                                    else if (objData["salt_taste_sensitivity"] != null)
                                    {
                                        genoResultList.Item69 = objData["salt_taste_sensitivity"].ToString();  //item69
                                    }

                                }
                                catch (Exception ex2)
                                {
                                    genoResultList = null;
                                    Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex2.Message);
                                }
                            }
                        }
                    }
                    else
                    {
                        genoResultList = null;
                    }
                }
                else
                {
                    genoResultList = null;
                }

            }
            catch (Exception e)
            {
                genoResultList = null;
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, e.Message);
            }

            return genoResultList;
        }


        //스케쥴 예약 선택 이동
        void reservationListBox_DoubleClick(Member member)
        {
            LoginSession.SelectedVisitSchMember = null;
            LoginSession.SelectedMember = null;
            LoginSession.SelectedSurvey = null;
            LoginSession.SelectedSurvey_M = null;
            LoginSession.SelectedM_Antera = null;
            LoginSession.SelectedM_Vapometer = null;
            LoginSession.SelectedM_CNK_Customer = null;
            LoginSession.SelectedM_CNK_Sebumeter = null;
            LoginSession.SelectedM_Markvu_ResultData = null;
            LoginSession.SelectedM_Markvu_Capture = null;
            LoginSession.Selected_C_ResultPageData = null;
            LoginSession.Selected_C_ResultPageData_M = null;
            LoginSession.MySolution_ViewModel = null;
            LoginSession.Result_SkinConcern_Rpt = null;

            try
            {
                if (member.progress_flg == "")
                    member.progress_flg = "0";

                if (member.surveyNo != 0 && member.surveyNo > 0)
                {
                    //맴버 정보 선택
                    LoginSession.SelectedMember = member;

                    if (LoginSession.Background_PCCD.Equals("PC001013") && member.ucstmid != null)
                    {
                        if (RunBarcodeAsync(LoginSession.SelectedMember.ucstmid).GetAwaiter().GetResult() != null)
                        {
                            LoginSession.MySolution_ViewModel = RunBarcodeAsync(LoginSession.SelectedMember.ucstmid).GetAwaiter().GetResult();
                            LoginSession.MySolution_ViewModel.C_Name = member.name;
                        }
                        else
                        {
                            LoginSession.MySolution_ViewModel = RunBarcodeAsync(LoginSession.SelectedMember.ucstmid).GetAwaiter().GetResult();
                        }

                    }

                    SurveyService.SurveyServiceClient ssc = new SurveyService.SurveyServiceClient();

                    //문진 데이터 조회(피부)
                    //LoginSession.SelectedSurvey = ssc.Get_C_SurveyResult_surveyNo(member.surveyNo);
                    LoginSession.SelectedSurvey = ssc.Get_C_SurveyResult_surveyNo(member.surveyNo);
                    //문진 데이터 조회(두피)
                    LoginSession.SelectedSurvey_M = ssc.Get_C_SurveyResult_Scalp_surveyNo(member.surveyNo);

                    if (ssc.State != System.ServiceModel.CommunicationState.Closed)
                    {
                        ssc.Close();
                    }


                    //기기 데이터 조회
                    DeviceService.DeviceServiceClient dsc = new DeviceService.DeviceServiceClient();
                    LoginSession.SelectedM_Markvu_ResultData = dsc.Get_C_ResultMarkVu(member.surveyNo);

                    DataTable dv = dsc.SelectVapometer(member.surveyNo, member.userkey);
                    if (dv != null && dv.Rows.Count > 0)
                    {
                        M_Vapometer Data = new M_Vapometer();

                        foreach (DataRow dr in dv.Rows)
                        {
                            Data.surveyNo = Convert.ToInt32(dr["surveyNo"].ToString());
                            Data.userkey = Convert.ToInt32(dr["userkey"].ToString());
                            Data.C_Left = dr["C_Left"].ToString();
                            Data.C_Right = dr["C_Right"].ToString();
                        }

                        LoginSession.SelectedM_Vapometer = Data;
                    }

                    if (LoginSession.ProgramCourseflg == "I")
                    {
                        DataTable dt = dsc.Select_CNK_Cutometer(member.surveyNo, member.userkey);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            M_CNK_Cutometer Data = new M_CNK_Cutometer();

                            foreach (DataRow dr in dt.Rows)
                            {
                                Data.surveyNo = Convert.ToInt32(dr["surveyNo"].ToString());
                                Data.userkey = Convert.ToInt32(dr["userkey"].ToString());
                                Data.eye_area = dr["eye_area"].ToString();
                                Data.cheek = dr["cheek"].ToString();
                            }

                            LoginSession.SelectedM_CNK_Customer = Data;
                        }
                    }

                    if (dsc.State != System.ServiceModel.CommunicationState.Closed)
                    {
                        dsc.Close();
                    }

                    ResultService.ResultServiceClient rsc = new ResultService.ResultServiceClient();

                    // 결과(피부)
                    LoginSession.Selected_C_ResultPageData = rsc.Get_C_Result_Rpt(member.surveyNo, member.userkey.ToString());

                    // 결과(두피)
                    LoginSession.Selected_C_ResultPageData_M = rsc.Get_C_Result_Rpt_Scalp(member.surveyNo, member.userkey.ToString());

                    //결과(마이스킨솔루션) 테스트
                    DataTable mySkin_dt = rsc.SelectSkinConcern(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedMember.userkey);
                    Result_SkinConcern_Rpt rsr = new Result_SkinConcern_Rpt();

                    if (mySkin_dt.Rows.Count > 0)
                    {
                        DataRow mySkin_dr = mySkin_dt.Rows[0];

                        rsr.pore = (double)mySkin_dr["pore"];
                        rsr.wrinkle = (double)mySkin_dr["wrinkle"];
                        rsr.futurewrinkles = (double)mySkin_dr["futurewrinkles"];
                        rsr.pigmentation = (double)mySkin_dr["pigmentation"];
                        rsr.melanin = (double)mySkin_dr["melanin"];
                        rsr.transdermal = (double)mySkin_dr["transdermal"];
                        rsr.redness = (double)mySkin_dr["redness"];
                        rsr.porphyrin = (double)mySkin_dr["porphyrin"];
                        rsr.elasticity = (double)mySkin_dr["elasticity"];
                        rsr.tZone_Moisture = Convert.IsDBNull(mySkin_dr["tZone_Moisture"]) ? LoginSession.SelectedM_Markvu_ResultData.FSubun_A : (double)mySkin_dr["tZone_Moisture"];
                        rsr.tZone_Oilskin = Convert.IsDBNull(mySkin_dr["tZone_Oilskin"]) ? (LoginSession.SelectedM_Markvu_ResultData.FSebum_A + LoginSession.SelectedM_Markvu_ResultData.FSebum_B)/2 : (double)mySkin_dr["tZone_Oilskin"];
                        rsr.uZone_Moisture = Convert.IsDBNull(mySkin_dr["uZone_Moisture"]) ? (LoginSession.SelectedM_Markvu_ResultData.FSubun_G + LoginSession.SelectedM_Markvu_ResultData.FSubun_H) / 2 : (double)mySkin_dr["uZone_Moisture"];
                        rsr.uZone_Oilskin = Convert.IsDBNull(mySkin_dr["uZone_Oilskin"]) ? (LoginSession.SelectedM_Markvu_ResultData.FSebum_G + LoginSession.SelectedM_Markvu_ResultData.FSebum_H) / 2 : (double)mySkin_dr["uZone_Oilskin"];

                        LoginSession.Result_SkinConcern_Rpt = rsr;
                    }
                    else
                    {
                        LoginSession.Result_SkinConcern_Rpt = rsr;
                    }

                    if (LoginSession.Selected_C_ResultPageData_M.surveyNo == 0 )
                    {
                        LoginSession.Selected_C_ResultPageData_M = LoginSession.Selected_C_ResultPageData;
                    }

                    if (rsc.State != System.ServiceModel.CommunicationState.Closed)
                    {
                        rsc.Close();
                    }


                    //string markvu_data_path = DeviceManager.GetDevicePath("tb_device_MarkVu_DataPath");
                    //MarkVu mv = new MarkVu(markvu_data_path);
                    //ResultMarkVu rmv = null;
                    //rmv = mv.GetResultData(LoginSession.SelectedMember.name, LoginSession.SelectedMember.sex, LoginSession.SelectedMember.birthdate);
                    //if (rmv != null)
                    //{
                    //    rmv.surveyNo = LoginSession.SelectedMember.surveyNo;
                    //    rmv.userkey = LoginSession.SelectedMember.userkey;
                    //    LoginSession.SelectedM_Markvu_ResultData = rmv;
                    //    //CommonMessageBox.ShowAlertMessage("마크뷰 데이터를 정상적으로 가져왔습니다.");

                    //    //CustInfo c_info = mv.GetCustInfo(LoginSession.SelectedMember.name, LoginSession.SelectedMember.sex, LoginSession.SelectedMember.birthdate);
                    //    //List<Analyze> c_analyze = mv.GetAnalyze(c_info.DBID);
                    //    //List<Capture> c_capture = mv.GetCapture(c_info.DBID);
                    //    //List<Complete> c_complete = mv.GetComplete(c_info.DBID);

                    //    //c_info.surveyNo = LoginSession.SelectedMember.surveyNo;
                    //    //c_info.userkey = LoginSession.SelectedMember.userkey;
                    //}
                    CommonBiz.SetMemberTopText(member);

                    Popup.Popup_CustomerIdentification pop_customer = new Popup_CustomerIdentification(member, true);
                    pop_customer.ShowDialog();

                }
                else
                {
                    Popup.Popup_CustomerIdentification pop_customer = new Popup_CustomerIdentification(member, false);
                    pop_customer.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);

            }
        }

        //직접방문 버튼 클릭
        void btn_Customer_Input_Click(object sender, RoutedEventArgs e)
        {
            //if (ti.Enabled == true)
            //{
            //    ti.Stop();
            //    ti.Dispose();
            //}

            LoginSession.SelectedVisitSchMember = null;
            LoginSession.SelectedMember = null;
            LoginSession.SelectedSurvey = null;
            LoginSession.SelectedSurvey_M = null;
            LoginSession.SelectedM_Antera = null;
            LoginSession.SelectedM_Vapometer = null;
            LoginSession.SelectedM_CNK_Customer = null;
            LoginSession.SelectedM_CNK_Sebumeter = null;
            LoginSession.SelectedM_Markvu_ResultData = null;
            LoginSession.SelectedM_Markvu_Capture = null;
            LoginSession.Selected_C_ResultPageData = null;
            LoginSession.Selected_C_ResultPageData_M = null;

            if (LoginSession.LoginManagerInfo.ManagerRoleCD != "MR001003")
            {
                PopupSelectCourse psc = new PopupSelectCourse();
                psc.selectedComplate += new PopupSelectCourse.SelectedComplate(psc_selectedComplate);
                psc.ShowDialog();
            }
        }

        void psc_selectedComplate(string strCouse)
        {
            //NavigationService ns = NavigationService.GetNavigationService(this);
            //ns.Navigate(new CustomerIdentificationPage(strCouse));
        }
    }
}
