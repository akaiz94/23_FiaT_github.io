﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Markup; //IAddChild 활용 (동적 생성)
using System.IO;//MemoryStream 활용
using System.Printing; // 해상도 조절용 print ticket 사용
using IOPE_LAB_CONTROLS.Base;
using System.Data;

namespace IOPE_LAB.Contents.SkinSolution
{
    /// <summary>
    /// MySolution_PrintPage.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MySolution_PrintPage : Page
    {
        public MySolution_PrintPage()
        {
            InitializeComponent();

            Skin_Score_P();
            Research_List_P();

        }

        private void Research_List_P()
        {
            MySolution_ViewModel Research_List = this.DataContext as MySolution_ViewModel;

            MemberService.MemberServiceClient msc = new MemberService.MemberServiceClient();
            DataTable dt = msc.visitCount("IC", LoginSession.SelectedMember.name, LoginSession.SelectedMember.birthdate, LoginSession.SelectedMember.PCCD);
            string searchDate = LoginSession.SelectedMember.rsvn_date.ToString("yyyy-MM-dd").Replace("-", "/");

            Research_List.C_Name = LoginSession.MySolution_ViewModel.C_Name; // No1.고객 이름
            Research_List.C_Date = searchDate; //  No2. 측정일자
            //Research_List.C_Visit_Number = 11;// No3

            if (dt.Rows.Count > 0)
            {
                string visit = dt.Rows.Count > 0 ? dt.Rows[0]["cnt"].ToString() : "0";
                Research_List.C_Visit_Number = Int32.Parse(visit);
            }


            //생활 습관 조사 Bar
            Research_List.Research_Bar = Research_List.C_Age / 10;
            Research_List.Research_Bar2 = Int32.Parse(LoginSession.SelectedSurvey.S3_1); // No3. 자외선 차단제를 사용해요 값 
            Research_List.Research_Bar3 = Int32.Parse(LoginSession.SelectedSurvey.S3_2); // No4. 담배를 피우거나 간접흡연에 노출되어 있어요 값
            Research_List.Research_Bar4 = Int32.Parse(LoginSession.SelectedSurvey.S3_3); // No5. 스트레스를 많이 받아요 값
            Research_List.Research_Bar5 = Int32.Parse(LoginSession.SelectedSurvey.S3_4); // No6.  충분히 잠을 자요 값

        }




        private void Skin_Score_P()
        {
            MySolution_ViewModel Skin_Score = this.DataContext as MySolution_ViewModel;

            /* sring값으로 가져올때, "  " 를 통해 가져온 후, ViewModel에서 int -> string으로 변환.
             Skin_Score.Me_Score = "70";
            Skin_Score.Me_Slider = Skin_Score.Me_Score;

            */

            // 현재 점수 : 피부측정값만 받아옴 (기본값)
            int SKinMeasure_Moisture = (int)LoginSession.Result_SkinConcern_Rpt.uZone_Moisture;
            int SKinMeasure_Oilskin = (int)LoginSession.Result_SkinConcern_Rpt.uZone_Oilskin;
            int SKinMeasure_redskin = (int)LoginSession.Result_SkinConcern_Rpt.redness;
            int SKinMeasure_darkskin = (int)LoginSession.Result_SkinConcern_Rpt.pigmentation;
            int SKinMeasure_Wrinkle = (int)LoginSession.Result_SkinConcern_Rpt.wrinkle;


            //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
            int FurtureGene_Wrinkle = Int32.Parse(LoginSession.MySolution_ViewModel.Me_Score);
            int FurtureGene_redskin = Int32.Parse(LoginSession.MySolution_ViewModel.Me_Score2);
            int FurtureGene_darkskin = Int32.Parse(LoginSession.MySolution_ViewModel.Me_Score3);
            int FurtureGene_Oilskin = Int32.Parse(LoginSession.MySolution_ViewModel.Me_Score4);
            int FurtureGene_Moisture = Int32.Parse(LoginSession.MySolution_ViewModel.Me_Score5);


            //--------------------------------


            // 현재 점수 : 피부측정값만 받아옴 (기본값)
            Skin_Score.Me_Score = SKinMeasure_Moisture;  //현재 - 수분 점수 => Skin_Score.Me_Score / Skin_Score.Me_Slider / distances[0] 3개와 연동
            Skin_Score.Me_Score2 = SKinMeasure_Oilskin; // 현재 - 유분 점수
            Skin_Score.Me_Score3 = SKinMeasure_redskin; // 현재 - 민감 점수
            Skin_Score.Me_Score4 = SKinMeasure_darkskin; // 현재 - 색소 점수
            Skin_Score.Me_Score5 = SKinMeasure_Wrinkle; //  현재 - 주름 점수


            //------ 현재 점수 Bar 입니다.  
            Skin_Score.Me_Slider = Skin_Score.Me_Score;
            Skin_Score.Me_Slider2 = Skin_Score.Me_Score2;
            Skin_Score.Me_Slider3 = Skin_Score.Me_Score3;
            Skin_Score.Me_Slider4 = Skin_Score.Me_Score4;
            Skin_Score.Me_Slider5 = Skin_Score.Me_Score5;




            //  미래 점수 : 피부측정값 + 유전자 점수 + 문진 받아옴 (기본값)
            // 문진 란, 진단하기 클릭 시 반영되는 값은 private void Analyze_Button_Click 안에 구현해 두었습니다.

            Skin_Score.Future_Score = FurtureGene_Moisture; // 미래 - 수분 점수
            Skin_Score.Future_Score2 = FurtureGene_Oilskin;// 미래 - 유분 점수
            Skin_Score.Future_Score3 = FurtureGene_redskin;// 미래 - 민감 점수
            Skin_Score.Future_Score4 = FurtureGene_darkskin;// 미래 - 색소 점수
            Skin_Score.Future_Score5 = FurtureGene_Wrinkle;//미래 - 주름 점수

            //------ 미래 점수 Bar 입니다.  
            Skin_Score.Skin_Future_Bar = Skin_Score.Future_Score;
            Skin_Score.Skin_Future_Bar2 = Skin_Score.Future_Score2;
            Skin_Score.Skin_Future_Bar3 = Skin_Score.Future_Score3;
            Skin_Score.Skin_Future_Bar4 = Skin_Score.Future_Score4;
            Skin_Score.Skin_Future_Bar5 = Skin_Score.Future_Score5;


            // 3. '나' 점수가 가장 낮은 2개를 선정하여 텍스트를 반영하는

            int[] meScores = new int[5];
            string[] meScoreItems = new string[5];

            /*
            meScores[0] = Skin_Score.Me_Score; // 수분   3
            meScores[1] = Skin_Score.Me_Score2; // 유분   4
            meScores[2] = Skin_Score.Me_Score3; // 민감   5 
            meScores[3] = Skin_Score.Me_Score4; // 색소   2
            meScores[4] = Skin_Score.Me_Score5; // 주름   1
           */

            meScores[0] = Skin_Score.Me_Score3; // 민감
            meScores[1] = Skin_Score.Me_Score4; // 색소 
            meScores[2] = Skin_Score.Me_Score5; // 주름
            meScores[3] = Skin_Score.Me_Score2; // 유분
            meScores[4] = Skin_Score.Me_Score; // 수분



            meScoreItems[0] = "민감";
            meScoreItems[1] = "색소";
            meScoreItems[2] = "주름";
            meScoreItems[3] = "유분";
            meScoreItems[4] = "수분";


            Array.Sort(meScores, meScoreItems);


            /*

            if (meScores[1] == meScores[2])
            {
                if (meScoreItems[1] == "민감" || meScoreItems[2] == "민감")
                {
                    int index = Array.IndexOf(meScoreItems, "민감");
                    if (index == 1)
                    {
                        Skin_Score.Worst_Score_Text = meScoreItems[1];
                    }
                    else
                    {
                        Skin_Score.Worst_Score_Text = meScoreItems[2];
                    }
                }

                else
                {
                    if (meScoreItems[1] == "색소" || meScoreItems[2] == "색소")
                    {
                        int index1 = Array.IndexOf(meScoreItems, "색소");
                        if (index1 == 1)
                        {
                            Skin_Score.Worst_Score_Text = meScoreItems[1];
                        }
                        else
                        {
                            Skin_Score.Worst_Score_Text = meScoreItems[2];
                        }
                    }

                    else
                    {
                        if (meScoreItems[1] == "주름" || meScoreItems[2] == "주름")
                        {
                            int index2 = Array.IndexOf(meScoreItems, "주름");
                            if (index2 == 1)
                            {
                                Skin_Score.Worst_Score_Text = meScoreItems[1];
                            }
                            else
                            {
                                Skin_Score.Worst_Score_Text = meScoreItems[2];
                            }
                        }

                        else
                        {
                            if (meScoreItems[1] == "유분" || meScoreItems[2] == "유분")
                            {
                                int index3 = Array.IndexOf(meScoreItems, "유분");
                                if (index3 == 1)
                                {
                                    Skin_Score.Worst_Score_Text = meScoreItems[1];
                                }
                                else
                                {
                                    Skin_Score.Worst_Score_Text = meScoreItems[2];
                                }
                            }
                        }
                    }

                }
            }          
            */



            //---0순위에서 동점 처리
            if (meScores[0] == meScores[1])
            {
                if (meScoreItems[0] == "민감" || meScoreItems[1] == "민감")
                {
                    int index = Array.IndexOf(meScoreItems, "민감");
                    if (index == 0)
                    {
                        Skin_Score.Worst_Score_Text = meScoreItems[0];
                        Skin_Score.Worst_Score2_Text = meScoreItems[1];
                    }
                    else
                    {
                        Skin_Score.Worst_Score_Text = meScoreItems[1];
                        Skin_Score.Worst_Score2_Text = meScoreItems[0];
                    }
                }

                else
                {
                    if (meScoreItems[0] == "색소" || meScoreItems[1] == "색소")
                    {
                        int index1 = Array.IndexOf(meScoreItems, "색소");
                        if (index1 == 0)
                        {
                            Skin_Score.Worst_Score_Text = meScoreItems[0];
                            Skin_Score.Worst_Score2_Text = meScoreItems[1];
                        }
                        else
                        {
                            Skin_Score.Worst_Score_Text = meScoreItems[1];
                            Skin_Score.Worst_Score2_Text = meScoreItems[0];
                        }
                    }

                    else
                    {
                        if (meScoreItems[0] == "주름" || meScoreItems[1] == "주름")
                        {
                            int index2 = Array.IndexOf(meScoreItems, "주름");
                            if (index2 == 0)
                            {
                                Skin_Score.Worst_Score_Text = meScoreItems[0];
                                Skin_Score.Worst_Score2_Text = meScoreItems[1];
                            }
                            else
                            {
                                Skin_Score.Worst_Score_Text = meScoreItems[1];
                                Skin_Score.Worst_Score2_Text = meScoreItems[0];
                            }
                        }

                        else
                        {
                            if (meScoreItems[0] == "유분" || meScoreItems[1] == "유분")
                            {
                                int index3 = Array.IndexOf(meScoreItems, "유분");
                                if (index3 == 0)
                                {
                                    Skin_Score.Worst_Score_Text = meScoreItems[0];
                                    Skin_Score.Worst_Score2_Text = meScoreItems[1];
                                }
                                else
                                {
                                    Skin_Score.Worst_Score_Text = meScoreItems[1];
                                    Skin_Score.Worst_Score2_Text = meScoreItems[0];
                                }
                            }
                        }
                    }

                }
            }


            else
            {
                Skin_Score.Worst_Score_Text = meScoreItems[0];
                Skin_Score.Worst_Score2_Text = meScoreItems[1];
            }





            // 3. 오각형 방사형 그래프 그리기 (현재, 미래점수)
            Point centerPoint = new Point(165 * 2 / 3, 165 * 2 / 3); // 예시로 가정한 오각형의 가운데 점

            double[] distances = new double[5]; // 현재 피부 점수 
            distances[0] = Skin_Score.Me_Score3; // 민감
            distances[1] = Skin_Score.Me_Score4; // 색소
            distances[2] = Skin_Score.Me_Score5; // 주름
            distances[3] = Skin_Score.Me_Score; // 수분
            distances[4] = Skin_Score.Me_Score2; // 유분

            double[] distances2 = new double[5]; // 미래 피부 점수 
            distances2[0] = Skin_Score.Future_Score3; // 민감
            distances2[1] = Skin_Score.Future_Score4; // 색소
            distances2[2] = Skin_Score.Future_Score5; // 주름
            distances2[3] = Skin_Score.Future_Score; // 수분
            distances2[4] = Skin_Score.Future_Score2; // 유분

            for (int i = 0; i < 5; i++)
            {
                double angle = 72 * i + 54; // 오각형의 각도
                double distance = distances[i]; // 오각형의 각 꼭짓점으로부터의 거리
                double distance2 = distances2[i];


                double x1 = centerPoint.X + distance * Math.Cos(Math.PI * angle / 180);
                double y1 = centerPoint.Y + distance * Math.Sin(Math.PI * angle / 180);

                double x2 = centerPoint.X + distance2 * Math.Cos(Math.PI * angle / 180);
                double y2 = centerPoint.Y + distance2 * Math.Sin(Math.PI * angle / 180);

                Skin_Score.PolygonPoints.Add(new Point(x1 * 1.5, y1 * 1.5));
                Skin_Score.PolygonPoints2.Add(new Point(x2 * 1.5, y2 * 1.5));

            }
        }



        /*
        private void btn_PrintReady_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {
                // Create a new instance of the page to be printed
                MySolution_PrintPage printPage = new MySolution_PrintPage();

                // Print the page using PrintVisual
                printDialog.PrintVisual(printPage, "My Printable Page");
            }
        }
        */


        private void btn_PrintReady_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            btn_PrintReady.Visibility = Visibility.Collapsed;


            if (printDialog.ShowDialog().GetValueOrDefault())
            {
                Transform originTransform = this.LayoutTransform;
                Size originSize = new Size(this.ActualWidth, this.ActualHeight);

                double xStartPrint = 45;
                double yStartPrint = 50;

                PrintCapabilities capabilities = printDialog.PrintQueue.GetPrintCapabilities(printDialog.PrintTicket);

                double scale = Math.Min(capabilities.PageImageableArea.ExtentWidth / this.ActualWidth, capabilities.PageImageableArea.ExtentHeight /
                                this.ActualHeight);

                this.LayoutTransform = new ScaleTransform(scale, scale);

                Size sz = new Size(capabilities.PageImageableArea.ExtentWidth, capabilities.PageImageableArea.ExtentHeight);

                this.Measure(sz);
                // this.Arrange(new Rect(new Point(capabilities.PageImageableArea.OriginWidth, capabilities.PageImageableArea.OriginHeight), sz));
                this.Arrange(new Rect(new Point(xStartPrint, yStartPrint), sz));


                printDialog.PrintVisual(this, "Print Skin Solution Result");

                this.LayoutTransform = originTransform;
                this.Measure(originSize);
                this.Arrange(new Rect(new Point(0, 0), originSize));
            }

            btn_PrintReady.Visibility = Visibility.Visible;
        }




        /*
        private void btn_PrintReady_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            btn_PrintReady.Visibility = Visibility.Collapsed;

            if (printDialog.ShowDialog() == true)
            {
                // UI를 이미지로 캡쳐
                RenderTargetBitmap bmp = new RenderTargetBitmap((int)PrintGrid.ActualWidth, (int)PrintGrid.ActualHeight, 96, 96, PixelFormats.Pbgra32);
                bmp.Render(PrintGrid);

                // 이미지 소스를 생성
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bmp));
                MemoryStream stream = new MemoryStream();
                encoder.Save(stream);
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.StreamSource = stream;
                bitmap.EndInit();

                // 이미지 요소 생성 (저장, 비트맵 이미지로)
                Image img = new Image();
                img.Source = bitmap;

                // 문서에 이미지를 추가
                FixedPage page = new FixedPage();
                page.Width = printDialog.PrintableAreaWidth;
                page.Height = printDialog.PrintableAreaHeight;
                page.Children.Add(img);

                PageContent pageContent = new PageContent();
                ((IAddChild)pageContent).AddChild(page);

                FixedDocument document = new FixedDocument();
                document.DocumentPaginator.PageSize = new Size(printDialog.PrintableAreaWidth, printDialog.PrintableAreaHeight);
                document.Pages.Add(pageContent);



                // PrintTicket에서 DPI 설정
                PrintTicket printTicket = printDialog.PrintTicket;
                printTicket.PageResolution = new PageResolution(600, 600);

                printDialog.PrintTicket = printTicket;
                // 프린트 문서
                printDialog.PrintDocument(document.DocumentPaginator, "MY SKIN SOLUTION RESULT");
            }

            btn_PrintReady.Visibility = Visibility.Visible;
        }
        */

    }
}
