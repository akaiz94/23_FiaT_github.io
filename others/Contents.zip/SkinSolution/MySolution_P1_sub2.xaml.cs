﻿using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace IOPE_LAB.Contents.SkinSolution
{
    /// <summary>
    /// MainPage4.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MySolution_P1_sub2 : UserControl
    {
        // 점수 및 항목을 저장할 변수
        int[] GradeValue_A = new int[8];
        string[] Item_A = new string[8];


    

        public MySolution_P1_sub2()
        {
            InitializeComponent();
            this.DataContext = new MySolution_ViewModel();

            ClientName();
            Items();
            GradeValueControl();               
               

        }

        //  "   "님의 마이 솔루션 - 이름
        private void ClientName()
        {
            MySolution_ViewModel Client = this.DataContext as MySolution_ViewModel;
            Client.C_Name = LoginSession.MySolution_ViewModel.C_Name;   // No1. 고객 이름

        }

        private void Items()
        {          
            MySolution_ViewModel Items = this.DataContext as MySolution_ViewModel;
            // 항목별 이름

            Items.Item1 = "근력운동적합성";
            Items.Item2 = "유산소운동적합성";
            Items.Item3 = "지구력운동적합성";
            Items.Item4 = "근육발달능력";
            Items.Item5 = "단거리 질주능력";
            Items.Item6 = "발목부상 위험도";
            Items.Item7 = "악력";
            Items.Item8 = "운동 후 회복능력";


            Item_A[0] = Items.Item1;
            Item_A[1] = Items.Item2;
            Item_A[2] = Items.Item3;
            Item_A[3] = Items.Item4;
            Item_A[4] = Items.Item5;
            Item_A[5] = Items.Item6;
            Item_A[6] = Items.Item7;
            Item_A[7] = Items.Item8;           


        }

        private void GradeValueControl()
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;
            // 각 항목별 점수 입니다.
            viewModel.GradeValue = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item57); // No2. 근력 운동 적합성
            viewModel.GradeValue2 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item58); // No3. 유산소 운동 적합성
            viewModel.GradeValue3 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item59); // No4. 지구력 운동 적합성
            viewModel.GradeValue4 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item60); // No5. 근육발달능력
            viewModel.GradeValue5 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item61); // No6. 단거리 질주 능력
            viewModel.GradeValue6 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item62); // No7. 발목 부상 위험도
            viewModel.GradeValue7 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item63); // No8. 악력
            viewModel.GradeValue8 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item64); // No9. 운동 후 회복능력


            viewModel.GradeValue_Bar = 101 - viewModel.GradeValue;
            GradeValue_A[0] = viewModel.GradeValue;

            viewModel.GradeValue2_Bar = 101 - viewModel.GradeValue2;
            GradeValue_A[1] = viewModel.GradeValue2;

            viewModel.GradeValue3_Bar = 101 - viewModel.GradeValue3;
            GradeValue_A[2] = viewModel.GradeValue3;

            viewModel.GradeValue4_Bar = 101 - viewModel.GradeValue4;
            GradeValue_A[3] = viewModel.GradeValue4;

            viewModel.GradeValue5_Bar = 101 - viewModel.GradeValue5;
            GradeValue_A[4] = viewModel.GradeValue5;

            viewModel.GradeValue6_Bar = 101 - viewModel.GradeValue6;
            GradeValue_A[5] = viewModel.GradeValue6;

            viewModel.GradeValue7_Bar = 101 - viewModel.GradeValue7;
            GradeValue_A[6] = viewModel.GradeValue7;

            viewModel.GradeValue8_Bar = 101 - viewModel.GradeValue8;
            GradeValue_A[7] = viewModel.GradeValue8;


        }


        // 양호한 순서대로 정렬 (점수가 높은 순서대로)
             private void Sort_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            int[] GradeValue_Sort = new int[8];
            string[] Item_Sort = new string[8];
            for(int i = 0; i < 8; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1];  viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
            viewModel.GradeValue6 = GradeValue_Sort[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_Sort[5]; viewModel.Item6 = Item_Sort[5];
            viewModel.GradeValue7 = GradeValue_Sort[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_Sort[6]; viewModel.Item7 = Item_Sort[6];
            viewModel.GradeValue8 = GradeValue_Sort[7]; viewModel.GradeValue8_Bar = 101 - GradeValue_Sort[7]; viewModel.Item8 = Item_Sort[7];
      
        }


        // 주의를 요하는 순서대로 정렬 (점수가 낮은 순서대로)
        private void Ascending_Sort_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            int[] GradeValue_Sort = new int[8];
            string[] Item_Sort = new string[8];
            for (int i = 0; i < 8; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);
            Array.Reverse(GradeValue_Sort);
            Array.Reverse(Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1]; viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
            viewModel.GradeValue6 = GradeValue_Sort[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_Sort[5]; viewModel.Item6 = Item_Sort[5];
            viewModel.GradeValue7 = GradeValue_Sort[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_Sort[6]; viewModel.Item7 = Item_Sort[6];
            viewModel.GradeValue8 = GradeValue_Sort[7]; viewModel.GradeValue8_Bar = 101 - GradeValue_Sort[7]; viewModel.Item8 = Item_Sort[7];
        
        }



        // 초기값으로 정렬
        private void Origin_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            viewModel.GradeValue = GradeValue_A[0]; viewModel.GradeValue_Bar = 101 - GradeValue_A[0]; viewModel.Item1 = Item_A[0];
            viewModel.GradeValue2 = GradeValue_A[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_A[1]; viewModel.Item2 = Item_A[1];
            viewModel.GradeValue3 = GradeValue_A[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_A[2]; viewModel.Item3 = Item_A[2];
            viewModel.GradeValue4 = GradeValue_A[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_A[3]; viewModel.Item4 = Item_A[3];
            viewModel.GradeValue5 = GradeValue_A[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_A[4]; viewModel.Item5 = Item_A[4];
            viewModel.GradeValue6 = GradeValue_A[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_A[5]; viewModel.Item6 = Item_A[5];
            viewModel.GradeValue7 = GradeValue_A[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_A[6]; viewModel.Item7 = Item_A[6];
            viewModel.GradeValue8 = GradeValue_A[7]; viewModel.GradeValue8_Bar = 101 - GradeValue_A[7]; viewModel.Item8 = Item_A[7];
        

        }
    }

      
    
}
