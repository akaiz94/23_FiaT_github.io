﻿using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace IOPE_LAB.Contents.SkinSolution
{
    /// <summary>
    /// MainPage4.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MySolution_P1_sub4 : UserControl
    {
        // 점수 및 항목을 저장할 변수
        int[] GradeValue_A = new int[12];
        string[] Item_A = new string[12];


    

        public MySolution_P1_sub4()
        {
            InitializeComponent();
            this.DataContext = new MySolution_ViewModel();

            ClientName();
            Items();
            GradeValueControl();               
               

        }

        //  "   "님의 마이 솔루션 - 이름
        private void ClientName()
        {
            MySolution_ViewModel Client = this.DataContext as MySolution_ViewModel;
            Client.C_Name = LoginSession.MySolution_ViewModel.C_Name;  // No1. 고객 이름

        }

        private void Items()
        {
            MySolution_ViewModel Items = this.DataContext as MySolution_ViewModel;
            // 항목별 이름입니다.

            Items.Item1 = "와인 선호도";
            Items.Item2 = "카페인 대사";
            Items.Item3 = "알코올 대사";
            Items.Item4 = "알코올 의존성";
            Items.Item5 = "알코올 홍조";
            Items.Item6 = "니코틴 대사";
            Items.Item7 = "니코틴 의존성";
            Items.Item8 = "카페인 의존성";
            Items.Item9 = "불면증";
            Items.Item10 = "아침형저녁형인간";
            Items.Item11 = "수면습관";
            Items.Item12 = "통증 민감성";
   



            Item_A[0] = Items.Item1;
            Item_A[1] = Items.Item2;
            Item_A[2] = Items.Item3;
            Item_A[3] = Items.Item4;
            Item_A[4] = Items.Item5;
            Item_A[5] = Items.Item6;
            Item_A[6] = Items.Item7;
            Item_A[7] = Items.Item8;
            Item_A[8] = Items.Item9;
            Item_A[9] = Items.Item10;
            Item_A[10] = Items.Item11;
            Item_A[11] = Items.Item12;
       


        }

        private void GradeValueControl()
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;
            // 각 항목별 점수 입니다.
            viewModel.GradeValue = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item49); // No2. 와인 선호도
            viewModel.GradeValue2 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item45); // No3. 카페인 대사
            viewModel.GradeValue3 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item46); // No4. 알코올 대사
            viewModel.GradeValue4 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item47); // No5. 알코올 의존성
            viewModel.GradeValue5 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item48); // No6. 알코올 홍조
            viewModel.GradeValue6 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item50); // No7. 니코틴 대사
            viewModel.GradeValue7 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item51); // No8. 니코틴 의존성
            viewModel.GradeValue8 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item52); // No9. 카페인 의존성
            viewModel.GradeValue9 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item53); // No10. 불면증
            viewModel.GradeValue10 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item55); // No11. 아침형저녁형인간
            viewModel.GradeValue11 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item54); // No12. 수면습관
            viewModel.GradeValue12 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item56); // No13. 통증 민감성


            viewModel.GradeValue_Bar = 101 - viewModel.GradeValue;
            GradeValue_A[0] = viewModel.GradeValue;

            viewModel.GradeValue2_Bar = 101 - viewModel.GradeValue2;
            GradeValue_A[1] = viewModel.GradeValue2;

            viewModel.GradeValue3_Bar = 101 - viewModel.GradeValue3;
            GradeValue_A[2] = viewModel.GradeValue3;

            viewModel.GradeValue4_Bar = 101 - viewModel.GradeValue4;
            GradeValue_A[3] = viewModel.GradeValue4;

            viewModel.GradeValue5_Bar = 101 - viewModel.GradeValue5;
            GradeValue_A[4] = viewModel.GradeValue5;

            viewModel.GradeValue6_Bar = 101 - viewModel.GradeValue6;
            GradeValue_A[5] = viewModel.GradeValue6;

            viewModel.GradeValue7_Bar = 101 - viewModel.GradeValue7;
            GradeValue_A[6] = viewModel.GradeValue7;

            viewModel.GradeValue8_Bar = 101 - viewModel.GradeValue8;
            GradeValue_A[7] = viewModel.GradeValue8;

            viewModel.GradeValue9_Bar = 101 - viewModel.GradeValue9;
            GradeValue_A[8] = viewModel.GradeValue9;

            viewModel.GradeValue10_Bar = 101 - viewModel.GradeValue10;
            GradeValue_A[9] = viewModel.GradeValue10;

            viewModel.GradeValue11_Bar = 101 - viewModel.GradeValue11;
            GradeValue_A[10] = viewModel.GradeValue11;

            viewModel.GradeValue12_Bar = 101 - viewModel.GradeValue12;
            GradeValue_A[11] = viewModel.GradeValue12;

       


        }


        // 양호한 순서대로 정렬 (점수가 높은 순서대로)
        private void Sort_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            int[] GradeValue_Sort = new int[12];
            string[] Item_Sort = new string[12];
            for (int i = 0; i < 12; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1]; viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
            viewModel.GradeValue6 = GradeValue_Sort[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_Sort[5]; viewModel.Item6 = Item_Sort[5];
            viewModel.GradeValue7 = GradeValue_Sort[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_Sort[6]; viewModel.Item7 = Item_Sort[6];
            viewModel.GradeValue8 = GradeValue_Sort[7]; viewModel.GradeValue8_Bar = 101 - GradeValue_Sort[7]; viewModel.Item8 = Item_Sort[7];
            viewModel.GradeValue9 = GradeValue_Sort[8]; viewModel.GradeValue9_Bar = 101 - GradeValue_Sort[8]; viewModel.Item9 = Item_Sort[8];
            viewModel.GradeValue10 = GradeValue_Sort[9]; viewModel.GradeValue10_Bar = 101 - GradeValue_Sort[9]; viewModel.Item10 = Item_Sort[9];
            viewModel.GradeValue11 = GradeValue_Sort[10]; viewModel.GradeValue11_Bar = 101 - GradeValue_Sort[10]; viewModel.Item11 = Item_Sort[10];
            viewModel.GradeValue12 = GradeValue_Sort[11]; viewModel.GradeValue12_Bar = 101 - GradeValue_Sort[11]; viewModel.Item12 = Item_Sort[11];
        

        }


        // 주의를 요하는 순서대로 정렬 (점수가 낮은 순서대로)
        private void Ascending_Sort_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            int[] GradeValue_Sort = new int[12];
            string[] Item_Sort = new string[12];
            for (int i = 0; i < 12; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);
            Array.Reverse(GradeValue_Sort);
            Array.Reverse(Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1]; viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
            viewModel.GradeValue6 = GradeValue_Sort[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_Sort[5]; viewModel.Item6 = Item_Sort[5];
            viewModel.GradeValue7 = GradeValue_Sort[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_Sort[6]; viewModel.Item7 = Item_Sort[6];
            viewModel.GradeValue8 = GradeValue_Sort[7]; viewModel.GradeValue8_Bar = 101 - GradeValue_Sort[7]; viewModel.Item8 = Item_Sort[7];
            viewModel.GradeValue9 = GradeValue_Sort[8]; viewModel.GradeValue9_Bar = 101 - GradeValue_Sort[8]; viewModel.Item9 = Item_Sort[8];
            viewModel.GradeValue10 = GradeValue_Sort[9]; viewModel.GradeValue10_Bar = 101 - GradeValue_Sort[9]; viewModel.Item10 = Item_Sort[9];
            viewModel.GradeValue11 = GradeValue_Sort[10]; viewModel.GradeValue11_Bar = 101 - GradeValue_Sort[10]; viewModel.Item11 = Item_Sort[10];
            viewModel.GradeValue12 = GradeValue_Sort[11]; viewModel.GradeValue12_Bar = 101 - GradeValue_Sort[11]; viewModel.Item12 = Item_Sort[11];
       

        }

    }


}
