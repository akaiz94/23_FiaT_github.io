﻿using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace IOPE_LAB.Contents.SkinSolution
{
    /// <summary>
    /// MainPage4.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MySolution_P1_sub1 : UserControl
    {
        // 점수 및 항목을 저장할 변수
        int[] GradeValue_A = new int[19];   
        string[] Item_A = new string[19];



    

        public MySolution_P1_sub1()
        {
            InitializeComponent();
            this.DataContext = new MySolution_ViewModel();

            ClientName();
            Items();
            GradeValueControl();               
               

        }

        //  "   "님의 마이 솔루션 - 이름
        private void ClientName()
        {
            MySolution_ViewModel Client = this.DataContext as MySolution_ViewModel;
            Client.C_Name = LoginSession.MySolution_ViewModel.C_Name;  // No1. 고객 이름

        }

        private void Items()
        {          
            MySolution_ViewModel Items = this.DataContext as MySolution_ViewModel;
            // 항목별 이름입니다.

            Items.Item1 = "비타민 C";
            Items.Item2 = "비타민 D";
            Items.Item3 = "코엔자임Q10"; 
            Items.Item4 = "마그네슘";
            Items.Item5 = "아연";
            Items.Item6 = "철";
            Items.Item7 = "칼륨";
            Items.Item8 = "칼슘";
            Items.Item9 = "아르기닌";
            Items.Item10 = "지방산";
            Items.Item11 = "비타민 B6";
            Items.Item12 = "비타민 A";
            Items.Item13 = "비타민 E";
            Items.Item14 = "비타민 K";
            Items.Item15 = "비타민 B12";
            Items.Item16 = "베타인";
            Items.Item17 = "타이로신";
            Items.Item18 = "셀레늄";
            Items.Item19 = "루테인&지아잔틴"; 


            Item_A[0] = Items.Item1;    
            Item_A[1] = Items.Item2;
            Item_A[2] = Items.Item3;          
            Item_A[3] = Items.Item4;            
            Item_A[4] = Items.Item5;          
            Item_A[5] = Items.Item6;          
            Item_A[6] = Items.Item7;           
            Item_A[7] = Items.Item8;        
            Item_A[8] = Items.Item9;          
            Item_A[9] = Items.Item10;          
            Item_A[10] = Items.Item11;
            Item_A[11] = Items.Item12;
            Item_A[12] = Items.Item13;
            Item_A[13] = Items.Item14;
            Item_A[14] = Items.Item15;
            Item_A[15] = Items.Item16;
            Item_A[16] = Items.Item17;
            Item_A[17] = Items.Item18;
            Item_A[18] = Items.Item19;

        }

        private void GradeValueControl()
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;
            // 각 항목별 점수 입니다.
            viewModel.GradeValue = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item12); // No2. 비타민C
            viewModel.GradeValue2 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item13); // No3. 비타민 D
            viewModel.GradeValue3 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item14); // No4. 코엔자임Q10
            viewModel.GradeValue4 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item15); // No5. 마그네슘
            viewModel.GradeValue5 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item16); // No6. 아연
            viewModel.GradeValue6 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item17); // No7. 철
            viewModel.GradeValue7 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item18); // No8. 칼륨
            viewModel.GradeValue8 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item19); // No9. 칼슘
            viewModel.GradeValue9 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item20); // No10. 아르기닌
            viewModel.GradeValue10 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item21); // No11. 지방산
            viewModel.GradeValue11 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item23); // No12. 비타민 B6
            viewModel.GradeValue12 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item22); // No13. 비타민 A
            viewModel.GradeValue13 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item24); // No14. 비타민 E
            viewModel.GradeValue14 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item25); // No15. 비타민 K
            viewModel.GradeValue15 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item26); // No16. 비타민 B12
            viewModel.GradeValue16 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item28); // No17. 베타인
            viewModel.GradeValue17 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item27); // No18. 타이로신
            viewModel.GradeValue18 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item29); // No19. 셀레늄
            viewModel.GradeValue19 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item30); // No20. 루테인&지아잔틴

            viewModel.GradeValue_Bar = 101 - viewModel.GradeValue;
            GradeValue_A[0] = viewModel.GradeValue;
          
            viewModel.GradeValue2_Bar = 101 - viewModel.GradeValue2;
            GradeValue_A[1] = viewModel.GradeValue2;
        
            viewModel.GradeValue3_Bar = 101 - viewModel.GradeValue3;
            GradeValue_A[2] = viewModel.GradeValue3;
      
            viewModel.GradeValue4_Bar = 101 - viewModel.GradeValue4;
            GradeValue_A[3] = viewModel.GradeValue4;
       
            viewModel.GradeValue5_Bar = 101 - viewModel.GradeValue5;
            GradeValue_A[4] = viewModel.GradeValue5;
          
            viewModel.GradeValue6_Bar = 101 - viewModel.GradeValue6;
            GradeValue_A[5] = viewModel.GradeValue6;
           
            viewModel.GradeValue7_Bar = 101 - viewModel.GradeValue7;
            GradeValue_A[6] = viewModel.GradeValue7;
          
            viewModel.GradeValue8_Bar = 101 - viewModel.GradeValue8;
            GradeValue_A[7] = viewModel.GradeValue8;
          
            viewModel.GradeValue9_Bar = 101 - viewModel.GradeValue9;
            GradeValue_A[8] = viewModel.GradeValue9;
        
            viewModel.GradeValue10_Bar = 101 - viewModel.GradeValue10;
            GradeValue_A[9] = viewModel.GradeValue10;
           
            viewModel.GradeValue11_Bar = 101 - viewModel.GradeValue11;
            GradeValue_A[10] = viewModel.GradeValue11;

            viewModel.GradeValue12_Bar = 101 - viewModel.GradeValue12;
            GradeValue_A[11] = viewModel.GradeValue12;

            viewModel.GradeValue13_Bar = 101 - viewModel.GradeValue13;
            GradeValue_A[12] = viewModel.GradeValue13;

            viewModel.GradeValue14_Bar = 101 - viewModel.GradeValue14;
            GradeValue_A[13] = viewModel.GradeValue14;

            viewModel.GradeValue15_Bar = 101 - viewModel.GradeValue15;
            GradeValue_A[14] = viewModel.GradeValue15;

            viewModel.GradeValue16_Bar = 101 - viewModel.GradeValue16;
            GradeValue_A[15] = viewModel.GradeValue16;

            viewModel.GradeValue17_Bar = 101 - viewModel.GradeValue17;
            GradeValue_A[16] = viewModel.GradeValue17;

            viewModel.GradeValue18_Bar = 101 - viewModel.GradeValue18;
            GradeValue_A[17] = viewModel.GradeValue18;

            viewModel.GradeValue19_Bar = 101 - viewModel.GradeValue19;
            GradeValue_A[18] = viewModel.GradeValue19;


        }


        // 양호한 순서대로 정렬 (점수가 높은 순서대로)
             private void Sort_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            int[] GradeValue_Sort = new int[19];
            string[] Item_Sort = new string[19];
            for(int i = 0; i < 19; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1];  viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
            viewModel.GradeValue6 = GradeValue_Sort[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_Sort[5]; viewModel.Item6 = Item_Sort[5];
            viewModel.GradeValue7 = GradeValue_Sort[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_Sort[6]; viewModel.Item7 = Item_Sort[6];
            viewModel.GradeValue8 = GradeValue_Sort[7]; viewModel.GradeValue8_Bar = 101 - GradeValue_Sort[7]; viewModel.Item8 = Item_Sort[7];
            viewModel.GradeValue9 = GradeValue_Sort[8]; viewModel.GradeValue9_Bar = 101 - GradeValue_Sort[8]; viewModel.Item9 = Item_Sort[8];
            viewModel.GradeValue10 = GradeValue_Sort[9]; viewModel.GradeValue10_Bar = 101 - GradeValue_Sort[9]; viewModel.Item10 = Item_Sort[9];
            viewModel.GradeValue11 = GradeValue_Sort[10]; viewModel.GradeValue11_Bar = 101 - GradeValue_Sort[10]; viewModel.Item11 = Item_Sort[10];
            viewModel.GradeValue12 = GradeValue_Sort[11]; viewModel.GradeValue12_Bar = 101 - GradeValue_Sort[11]; viewModel.Item12 = Item_Sort[11];
            viewModel.GradeValue13 = GradeValue_Sort[12]; viewModel.GradeValue13_Bar = 101 - GradeValue_Sort[12]; viewModel.Item13 = Item_Sort[12];
            viewModel.GradeValue14 = GradeValue_Sort[13]; viewModel.GradeValue14_Bar = 101 - GradeValue_Sort[13]; viewModel.Item14 = Item_Sort[13];
            viewModel.GradeValue15 = GradeValue_Sort[14]; viewModel.GradeValue15_Bar = 101 - GradeValue_Sort[14]; viewModel.Item15 = Item_Sort[14];
            viewModel.GradeValue16 = GradeValue_Sort[15]; viewModel.GradeValue16_Bar = 101 - GradeValue_Sort[15]; viewModel.Item16 = Item_Sort[15];
            viewModel.GradeValue17 = GradeValue_Sort[16]; viewModel.GradeValue17_Bar = 101 - GradeValue_Sort[16]; viewModel.Item17 = Item_Sort[16];
            viewModel.GradeValue18 = GradeValue_Sort[17]; viewModel.GradeValue18_Bar = 101 - GradeValue_Sort[17]; viewModel.Item18 = Item_Sort[17];
            viewModel.GradeValue19 = GradeValue_Sort[18]; viewModel.GradeValue19_Bar = 101 - GradeValue_Sort[18]; viewModel.Item19 = Item_Sort[18];
        }


        // 주의를 요하는 순서대로 정렬 (점수가 낮은 순서대로)
        private void Ascending_Sort_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            int[] GradeValue_Sort = new int[19];
            string[] Item_Sort = new string[19];
            for (int i = 0; i < 19; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);
            Array.Reverse(GradeValue_Sort);
            Array.Reverse(Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1]; viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
            viewModel.GradeValue6 = GradeValue_Sort[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_Sort[5]; viewModel.Item6 = Item_Sort[5];
            viewModel.GradeValue7 = GradeValue_Sort[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_Sort[6]; viewModel.Item7 = Item_Sort[6];
            viewModel.GradeValue8 = GradeValue_Sort[7]; viewModel.GradeValue8_Bar = 101 - GradeValue_Sort[7]; viewModel.Item8 = Item_Sort[7];
            viewModel.GradeValue9 = GradeValue_Sort[8]; viewModel.GradeValue9_Bar = 101 - GradeValue_Sort[8]; viewModel.Item9 = Item_Sort[8];
            viewModel.GradeValue10 = GradeValue_Sort[9]; viewModel.GradeValue10_Bar = 101 - GradeValue_Sort[9]; viewModel.Item10 = Item_Sort[9];
            viewModel.GradeValue11 = GradeValue_Sort[10]; viewModel.GradeValue11_Bar = 101 - GradeValue_Sort[10]; viewModel.Item11 = Item_Sort[10];
            viewModel.GradeValue12 = GradeValue_Sort[11]; viewModel.GradeValue12_Bar = 101 - GradeValue_Sort[11]; viewModel.Item12 = Item_Sort[11];
            viewModel.GradeValue13 = GradeValue_Sort[12]; viewModel.GradeValue13_Bar = 101 - GradeValue_Sort[12]; viewModel.Item13 = Item_Sort[12];
            viewModel.GradeValue14 = GradeValue_Sort[13]; viewModel.GradeValue14_Bar = 101 - GradeValue_Sort[13]; viewModel.Item14 = Item_Sort[13];
            viewModel.GradeValue15 = GradeValue_Sort[14]; viewModel.GradeValue15_Bar = 101 - GradeValue_Sort[14]; viewModel.Item15 = Item_Sort[14];
            viewModel.GradeValue16 = GradeValue_Sort[15]; viewModel.GradeValue16_Bar = 101 - GradeValue_Sort[15]; viewModel.Item16 = Item_Sort[15];
            viewModel.GradeValue17 = GradeValue_Sort[16]; viewModel.GradeValue17_Bar = 101 - GradeValue_Sort[16]; viewModel.Item17 = Item_Sort[16];
            viewModel.GradeValue18 = GradeValue_Sort[17]; viewModel.GradeValue18_Bar = 101 - GradeValue_Sort[17]; viewModel.Item18 = Item_Sort[17];
            viewModel.GradeValue19 = GradeValue_Sort[18]; viewModel.GradeValue19_Bar = 101 - GradeValue_Sort[18]; viewModel.Item19 = Item_Sort[18];
        }



        /*
        // 초기값으로 정렬
        private void Origin_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            viewModel.GradeValue = GradeValue_A[0]; viewModel.GradeValue_Bar = 101 - GradeValue_A[0]; viewModel.Item1 = Item_A[0];
            viewModel.GradeValue2 = GradeValue_A[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_A[1]; viewModel.Item2 = Item_A[1];
            viewModel.GradeValue3 = GradeValue_A[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_A[2]; viewModel.Item3 = Item_A[2];
            viewModel.GradeValue4 = GradeValue_A[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_A[3]; viewModel.Item4 = Item_A[3];
            viewModel.GradeValue5 = GradeValue_A[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_A[4]; viewModel.Item5 = Item_A[4];
            viewModel.GradeValue6 = GradeValue_A[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_A[5]; viewModel.Item6 = Item_A[5];
            viewModel.GradeValue7 = GradeValue_A[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_A[6]; viewModel.Item7 = Item_A[6];
            viewModel.GradeValue8 = GradeValue_A[7]; viewModel.GradeValue8_Bar = 101 - GradeValue_A[7]; viewModel.Item8 = Item_A[7];
            viewModel.GradeValue9 = GradeValue_A[8]; viewModel.GradeValue9_Bar = 101 - GradeValue_A[8]; viewModel.Item9 = Item_A[8];
            viewModel.GradeValue10 = GradeValue_A[9]; viewModel.GradeValue10_Bar = 101 - GradeValue_A[9]; viewModel.Item10 = Item_A[9];

        }
      */



    }        
}
