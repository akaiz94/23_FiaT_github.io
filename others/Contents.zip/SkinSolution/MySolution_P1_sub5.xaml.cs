﻿using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace IOPE_LAB.Contents.SkinSolution
{
    /// <summary>
    /// MainPage4.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MySolution_P1_sub5 : UserControl
    {
        // 점수 및 항목을 저장할 변수
        int[] GradeValue_A = new int[5];
        string[] Item_A = new string[5];


    

        public MySolution_P1_sub5()
        {
            InitializeComponent();
            this.DataContext = new MySolution_ViewModel();

            ClientName();
            Items();
            GradeValueControl();               
               

        }

        //  "   "님의 마이 솔루션 - 이름
        private void ClientName()
        {
            MySolution_ViewModel Client = this.DataContext as MySolution_ViewModel;
            Client.C_Name = LoginSession.MySolution_ViewModel.C_Name; // No1. 고객 이름

        }

        private void Items()
        {
            MySolution_ViewModel Items = this.DataContext as MySolution_ViewModel;
            // 항목별 이름입니다.

            Items.Item1 = "식욕";
            Items.Item2 = "포만감";
            Items.Item3 = "단맛 민감도";
            Items.Item4 = "쓴맛 민감도";
            Items.Item5 = "짠맛 민감도";

            Item_A[0] = Items.Item1;
            Item_A[1] = Items.Item2;
            Item_A[2] = Items.Item3;
            Item_A[3] = Items.Item4;
            Item_A[4] = Items.Item5;
      
        }

        private void GradeValueControl()
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;
            // 각 항목별 점수 입니다.
            viewModel.GradeValue = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item65); // No1. 식욕
            viewModel.GradeValue2 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item66); // No2. 포만감
            viewModel.GradeValue3 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item67); // No3. 단맛 민감도
            viewModel.GradeValue4 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item68); // No4. 쓴맛 민감도
            viewModel.GradeValue5 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item69); // No5. 짠맛 민감도

            viewModel.GradeValue_Bar = 101 - viewModel.GradeValue;
            GradeValue_A[0] = viewModel.GradeValue;

            viewModel.GradeValue2_Bar = 101 - viewModel.GradeValue2;
            GradeValue_A[1] = viewModel.GradeValue2;

            viewModel.GradeValue3_Bar = 101 - viewModel.GradeValue3;
            GradeValue_A[2] = viewModel.GradeValue3;

            viewModel.GradeValue4_Bar = 101 - viewModel.GradeValue4;
            GradeValue_A[3] = viewModel.GradeValue4;

            viewModel.GradeValue5_Bar = 101 - viewModel.GradeValue5;
            GradeValue_A[4] = viewModel.GradeValue5;

     




        }


        // 양호한 순서대로 정렬 (점수가 높은 순서대로)
        private void Sort_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            int[] GradeValue_Sort = new int[5];
            string[] Item_Sort = new string[5];
            for (int i = 0; i < 5; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1]; viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
      


        }


        // 주의를 요하는 순서대로 정렬 (점수가 낮은 순서대로)
        private void Ascending_Sort_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            int[] GradeValue_Sort = new int[5];
            string[] Item_Sort = new string[5];
            for (int i = 0; i < 5; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);
            Array.Reverse(GradeValue_Sort);
            Array.Reverse(Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1]; viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
          

        }

    }


}