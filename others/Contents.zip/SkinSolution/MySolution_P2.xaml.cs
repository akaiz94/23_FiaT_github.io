﻿using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media; // PointCollection 네임스페이스 활용하기 위함
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.SkinSolution
{
    /// <summary>
    /// MySolution_P2.xaml에 대한 상호 작용 논리
    /// </summary>
    /// 
    /// 
    /// 

    public partial class MySolution_P2 : UserControl
    {


        // 설문조사란의 슬라이더 움직일 시, 그 값을 저장하는 배열
        //int[] ResearchBarValue  = new int[5];
        private static HttpClient client = new HttpClient();
        private MySolutionViewModel skinFutureResultList = null;
        private Boolean isChecked = false;

        // 설문조사란의 슬라이더 움직일 시, 그 값을 저장하는 변수
        int ResearchBarValue = 0;

        int ResearchBarValue1 = 0;

        int ResearchBarValue2 = 0;

        int ResearchBarValue3 = 0;

        int ResearchBarValue4 = 0;



        private MySolution_ViewModel viewModel; // MySolution_ViewModel 객체를 저장할 private 변수
        public MySolution_P2()
        {
            InitializeComponent();
            RunBarcodeAsync(LoginSession.SelectedMember.Age_Group, Int32.Parse(LoginSession.SelectedSurvey.S3_1), Int32.Parse(LoginSession.SelectedSurvey.S3_2), Int32.Parse(LoginSession.SelectedSurvey.S3_3), Int32.Parse(LoginSession.SelectedSurvey.S3_4)).GetAwaiter().GetResult();
            viewModel = new MySolution_ViewModel(); // MySolution_ViewModel 객체 생성
            this.DataContext = viewModel;


            Skin_Score();
            Research_List();

            // 설문조사 항목 슬라이더
            slider.ValueChanged += Slider_ValueChanged; // 나이 값 변동 처리
            slider_Copy.ValueChanged += Slider1_ValueChanged; // 자외선 차단제를 사용해요 값 변동 처리
            slider_Copy1.ValueChanged += Slider2_ValueChanged; // 담배를 피우거나 간접흡연에 노출되어 있어요 값 변동 처리
            slider_Copy2.ValueChanged += Slider3_ValueChanged; // 스트레스를 많이 받아요 값 변동 처리
            slider_Copy3.ValueChanged += Slider4_ValueChanged; // 충분히 잠을 자요 값 변동 처리
        }

        //Header 통신 설정 및 유전자 결과조회 API 통신
        public async Task RunBarcodeAsync(int future_Age, int future_Sunscreen, int future_Smoke, int future_Stress, int future_Sleep)
        {
            //운영
            string config_Url = "https://citylab.amorepacific.com";

            //개발
            //string config_Url = "https://dev-geno.iope.com";

            // 현재 점수 : 피부측정값만 받아옴 (기본값)
            string ucstmid = LoginSession.SelectedMember.ucstmid;

            int elasticity_score = (int)LoginSession.Result_SkinConcern_Rpt.elasticity == 0 ? 1 : (int)LoginSession.Result_SkinConcern_Rpt.elasticity;
            int sensitivity_score = (int)LoginSession.Result_SkinConcern_Rpt.redness == 0 ? 1 : (int)LoginSession.Result_SkinConcern_Rpt.redness;
            int pigment_score = (int)LoginSession.Result_SkinConcern_Rpt.pigmentation == 0 ? 1 : (int)LoginSession.Result_SkinConcern_Rpt.pigmentation;

            int oiliness_score = (int)LoginSession.Result_SkinConcern_Rpt.uZone_Oilskin == 0 ? 1 : (int)LoginSession.Result_SkinConcern_Rpt.uZone_Oilskin;            
            int dryness_score = (int)LoginSession.Result_SkinConcern_Rpt.uZone_Moisture == 0 ? 1 : (int)LoginSession.Result_SkinConcern_Rpt.uZone_Moisture;
            oiliness_score = (int)(oiliness_score * 100/ 40); 
            dryness_score = (int)(dryness_score * 100/ 60); 

            //int elasticity_score = (int)LoginSession.Result_SkinConcern_Rpt.elasticity;
            //int sensitivity_score = (int)LoginSession.Result_SkinConcern_Rpt.redness;
            //int pigment_score = (int)LoginSession.Result_SkinConcern_Rpt.pigmentation;
            //int oiliness_score = (int)LoginSession.Result_SkinConcern_Rpt.uZone_Oilskin;
            //int dryness_score = (int)LoginSession.Result_SkinConcern_Rpt.uZone_Moisture;

            int age = LoginSession.SelectedMember.Age_Group;

            int sunscreen = (Int32.Parse(LoginSession.SelectedSurvey.S3_1) + 1); // No3. 자외선 차단제를 사용해요 값 
            int smoke = (Int32.Parse(LoginSession.SelectedSurvey.S3_2) + 1); // No4. 담배를 피우거나 간접흡연에 노출되어 있어요 값
            int stress = (Int32.Parse(LoginSession.SelectedSurvey.S3_3) + 1); // No5. 스트레스를 많이 받아요 값
            int sleep = (Int32.Parse(LoginSession.SelectedSurvey.S3_4) + 1); // No6.  충분히 잠을 자요 값

            //수정값
            int modified_age = future_Age;
            int modified_sunscreen = (future_Sunscreen + 1);
            int modified_smoke = (future_Smoke + 1);
            int modified_stress = (future_Stress + 1);
            int modified_sleep = (future_Sleep + 1);

            string resultString = string.Empty;
            string SelectURL = $"{config_Url}/gpiopeApi/genoFuture?btCustIdNo={ucstmid}&btCustIdNoClassifiCode=01&elasticity_score={elasticity_score}&sensitivity_score={sensitivity_score}&pigment_score={pigment_score}&oiliness_score={oiliness_score}&dryness_score={dryness_score}&age={age}&sunscreen={sunscreen}&smoke={smoke}&stress={stress}&sleep={sleep}&modified_age={modified_age}&modified_sunscreen={modified_sunscreen}&modified_smoke={modified_smoke}&modified_stress={modified_stress}&modified_sleep={modified_sleep}";
            //string SelectURL = $"{config_Url}/gpiopeApi/genoFuture?btCustIdNo={ucstmid}&btCustIdNoClassifiCode=01&elasticity_score=80&sensitivity_score=81&pigment_score=82&oiliness_score=83&dryness_score=84&age={age}&sunscreen={sunscreen}&smoke={smoke}&stress={stress}&sleep={sleep}&modified_age={modified_age}&modified_sunscreen={modified_sunscreen}&modified_smoke={modified_smoke}&modified_stress={modified_stress}&modified_sleep={modified_sleep}";
            skinFutureResultList = new MySolutionViewModel();

            try
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var response = await client.GetAsync(SelectURL).ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                {
                    resultString = await response.Content.ReadAsStringAsync();
                    var output1 = JObject.Parse(resultString);
                    var arrData = output1["result"];

                    if (arrData.Count() > 0)
                    {
                        if (!string.IsNullOrEmpty(resultString))
                        {
                            try
                            {
                                if (arrData["pred_elasticity_score"] != null)
                                {
                                    skinFutureResultList.Me_Score = arrData["pred_elasticity_score"].ToString();
                                }

                                if (arrData["pred_sensitivity_score"] != null)
                                {
                                    skinFutureResultList.Me_Score2 = arrData["pred_sensitivity_score"].ToString();
                                }

                                if (arrData["pred_pigment_score"] != null)
                                {
                                    skinFutureResultList.Me_Score3 = arrData["pred_pigment_score"].ToString();
                                }

                                if (arrData["pred_oiliness_score"] != null)
                                {
                                    skinFutureResultList.Me_Score4 = arrData["pred_oiliness_score"].ToString();
                                }

                                if (arrData["pred_dryness_score"] != null)
                                {
                                    skinFutureResultList.Me_Score5 = arrData["pred_dryness_score"].ToString();
                                }

                            }
                            catch (Exception ex2)
                            {
                                skinFutureResultList = null;
                                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex2.Message);
                            }
                        }
                    }
                    else
                    {
                        //미래피부 데이터 x
                        skinFutureResultList = null;
                        Common.CommonMessageBox.ShowAlertMessage("미래피부 데이터가 없습니다.");
                    }
                }
                else
                {
                    //API 통신에러
                    skinFutureResultList = null;
                    Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                }

            }
            catch (Exception e)
            {
                skinFutureResultList = null;
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, e.Message);
            }
        }


        // 설문조사 항목 슬라이더 값 가져옴
        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            viewModel.Research_Bar_Value = (int)e.NewValue;
            ResearchBarValue = viewModel.Research_Bar_Value;

        }

        private void Slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            viewModel.Research_Bar_Value1 = (int)e.NewValue;
            ResearchBarValue1 = viewModel.Research_Bar_Value1;
            //  int ResearchSecond = ResearchBarValue1 - 두번째 문진항목 저장 (뷰티테크 보낼용)
        }
        private void Slider2_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

            viewModel.Research_Bar_Value2 = (int)e.NewValue;
            ResearchBarValue2 = viewModel.Research_Bar_Value2;
            //  int ResearchThird = ResearchBarValue2 - 세번째 문진항목 저장 (뷰티테크 보낼용)
        }
        private void Slider3_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            viewModel.Research_Bar_Value3 = (int)e.NewValue;
            ResearchBarValue3 = viewModel.Research_Bar_Value3;
            //  int ResearchFourth = ResearchBarValue3 - 네번째 문진항목 저장 (뷰티테크 보낼용)
        }
        private void Slider4_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            viewModel.Research_Bar_Value4 = (int)e.NewValue;
            ResearchBarValue4 = viewModel.Research_Bar_Value4;
            //  int ResearchFifth= ResearchBarValue4 - 다섯번째 문진항목 저장 (뷰티테크 보낼용)
        }

        // 기본 프로퍼티 선언




        private void Research_List()
        {
            MySolution_ViewModel Research_List = this.DataContext as MySolution_ViewModel;

            Research_List.C_Age = LoginSession.SelectedMember.Age_Group; // No1. 고객 나이
            Research_List.C_Name = LoginSession.MySolution_ViewModel.C_Name; // No2. 고객 이름


            //생활 습관 조사 Bar (초기값)
            Research_List.Research_Bar = Research_List.C_Age / 10;
            Research_List.Research_Bar2 = Int32.Parse(LoginSession.SelectedSurvey.S3_1); // No3. 자외선 차단제를 사용해요 값 
            Research_List.Research_Bar3 = Int32.Parse(LoginSession.SelectedSurvey.S3_2); // No4. 담배를 피우거나 간접흡연에 노출되어 있어요 값
            Research_List.Research_Bar4 = Int32.Parse(LoginSession.SelectedSurvey.S3_3); // No5. 스트레스를 많이 받아요 값
            Research_List.Research_Bar5 = Int32.Parse(LoginSession.SelectedSurvey.S3_4); // No6.  충분히 잠을 자요 값

        }




        private void Skin_Score()
        {
            MySolution_ViewModel Skin_Score = this.DataContext as MySolution_ViewModel;

            // int[] SKinMeasure = new int[5];


            // 현재 점수 : 피부측정값만 받아옴 (기본값)
            int SKinMeasure_Moisture = (int)LoginSession.Result_SkinConcern_Rpt.uZone_Moisture;
            int SKinMeasure_Oilskin = (int)LoginSession.Result_SkinConcern_Rpt.uZone_Oilskin;
            SKinMeasure_Oilskin = (int)(SKinMeasure_Oilskin *100 / 40);
            SKinMeasure_Moisture = (int)(SKinMeasure_Moisture *100 / 60);


            int SKinMeasure_redskin = (int)LoginSession.Result_SkinConcern_Rpt.redness;
            int SKinMeasure_darkskin = (int)LoginSession.Result_SkinConcern_Rpt.pigmentation;
            int SKinMeasure_Wrinkle = (int)LoginSession.Result_SkinConcern_Rpt.wrinkle;


            //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
            int FurtureGene_Wrinkle = Int32.Parse(skinFutureResultList.Me_Score);
            int FurtureGene_redskin = Int32.Parse(skinFutureResultList.Me_Score2);
            int FurtureGene_darkskin = Int32.Parse(skinFutureResultList.Me_Score3);
            int FurtureGene_Oilskin = Int32.Parse(skinFutureResultList.Me_Score4);
            int FurtureGene_Moisture = Int32.Parse(skinFutureResultList.Me_Score5);

            if (!isChecked)
            {
                LoginSession.MySolution_ViewModel.Me_Score = skinFutureResultList.Me_Score;
                LoginSession.MySolution_ViewModel.Me_Score2 = skinFutureResultList.Me_Score2;
                LoginSession.MySolution_ViewModel.Me_Score3 = skinFutureResultList.Me_Score3;
                LoginSession.MySolution_ViewModel.Me_Score4 = skinFutureResultList.Me_Score4;
                LoginSession.MySolution_ViewModel.Me_Score5 = skinFutureResultList.Me_Score5;
                isChecked = false;
            }

            //--------------------------------


            // 현재 점수 : 피부측정값만 받아옴 (기본값)
            Skin_Score.Me_Score = SKinMeasure_Moisture;  //현재 - 수분 점수 => Skin_Score.Me_Score / Skin_Score.Me_Slider / distances[0] 3개와 연동
            Skin_Score.Me_Score2 = SKinMeasure_Oilskin; // 현재 - 유분 점수
            Skin_Score.Me_Score3 = SKinMeasure_redskin; // 현재 - 민감 점수
            Skin_Score.Me_Score4 = SKinMeasure_darkskin; // 현재 - 색소 점수
            Skin_Score.Me_Score5 = SKinMeasure_Wrinkle; //  현재 - 주름 점수


            //------ 현재 점수 Bar 입니다.  
            Skin_Score.Me_Slider = Skin_Score.Me_Score;
            Skin_Score.Me_Slider2 = Skin_Score.Me_Score2;
            Skin_Score.Me_Slider3 = Skin_Score.Me_Score3;
            Skin_Score.Me_Slider4 = Skin_Score.Me_Score4;
            Skin_Score.Me_Slider5 = Skin_Score.Me_Score5;




            //  미래 점수 : 피부측정값 + 유전자 점수 + 문진 받아옴 (기본값)
            // 문진 란, 진단하기 클릭 시 반영되는 값은 private void Analyze_Button_Click 안에 구현해 두었습니다.

            viewModel.Future_Score = FurtureGene_Moisture; // 미래 - 수분 점수
            viewModel.Future_Score2 = FurtureGene_Oilskin;// 미래 - 유분 점수
            viewModel.Future_Score3 = FurtureGene_redskin;// 미래 - 민감 점수
            viewModel.Future_Score4 = FurtureGene_darkskin;// 미래 - 색소 점수
            viewModel.Future_Score5 = FurtureGene_Wrinkle;//미래 - 주름 점수

            //------ 미래 점수 Bar 입니다.  
            viewModel.Skin_Future_Bar = viewModel.Future_Score;
            viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
            viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
            viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
            viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;



            // 2. '나' 점수가 가장 낮은 2개를 선정하는 코드입니다.
            int[] meScores = new int[5];
            string[] meScoreItems = new string[5];

            meScores[0] = viewModel.Me_Score;
            meScoreItems[0] = "수분";

            meScores[1] = viewModel.Me_Score2;
            meScoreItems[1] = "유분";

            meScores[2] = viewModel.Me_Score3;
            meScoreItems[2] = "민감";

            meScores[3] = viewModel.Me_Score4;
            meScoreItems[3] = "색소";

            meScores[4] = viewModel.Me_Score5;
            meScoreItems[4] = "주름";


            Array.Sort(meScores, meScoreItems);

            // 2-2.가장 관리가 필요한 영역은 '0순위'  '1순위'
            viewModel.Worst_Score_Text = meScoreItems[0];
            viewModel.Worst_Score2_Text = meScoreItems[1];




            // 3. 오각형 방사형 그래프 그리기 (현재, 미래점수)
            Point centerPoint = new Point(165 * 2 / 3, 165 * 2 / 3); // 예시로 가정한 오각형의 가운데 점

            double[] distances = new double[5]; // 현재 피부 점수 
            distances[0] = viewModel.Me_Score3; // 민감
            distances[1] = viewModel.Me_Score4; // 색소
            distances[2] = viewModel.Me_Score5; // 주름
            distances[3] = viewModel.Me_Score; // 수분
            distances[4] = viewModel.Me_Score2; // 유분

            double[] distances2 = new double[5]; // 미래 피부 점수 
            distances2[0] = viewModel.Future_Score3; // 민감
            distances2[1] = viewModel.Future_Score4; // 색소
            distances2[2] = viewModel.Future_Score5; // 주름
            distances2[3] = viewModel.Future_Score; // 수분
            distances2[4] = viewModel.Future_Score2; // 유분

            for (int i = 0; i < 5; i++)
            {
                double angle = 72 * i + 54; // 오각형의 각도
                double distance = distances[i]; // 오각형의 각 꼭짓점으로부터의 거리
                double distance2 = distances2[i];


                double x1 = centerPoint.X + distance * Math.Cos(Math.PI * angle / 180);
                double y1 = centerPoint.Y + distance * Math.Sin(Math.PI * angle / 180);

                double x2 = centerPoint.X + distance2 * Math.Cos(Math.PI * angle / 180);
                double y2 = centerPoint.Y + distance2 * Math.Sin(Math.PI * angle / 180);

                viewModel.PolygonPoints.Add(new Point(x1 * 1.5, y1 * 1.5)); // 회색 방사형(현재점수)에 반영되는 값입니다.
                viewModel.PolygonPoints2.Add(new Point(x2 * 1.5, y2 * 1.5)); // 분홍색 방사형(미래점수)에 반영되는 값입니다. (초기값)

            }
        }






        //-----------------------------------------------------------------


        int count = 0;

        //  2. 미래 점수( 문진 연동버전) : 피부측정값 + 문진 + 유전자 점수 받아옴 (기본값)
        public void Analyze_Button_Click(object sender, RoutedEventArgs e)
        {
            count++;
            Point centerPoint = new Point(165 * 2 / 3, 165 * 2 / 3); // 오각형의 가운데 점

            isChecked = true;

            int modified_age = (Int32.Parse(SearchScore.Text) * 10);
            int modified_sunscreen = Int32.Parse(SearchScore1.Text);
            int modified_smoke = Int32.Parse(SearchScore2.Text);
            int modified_stress = Int32.Parse(SearchScore3.Text);
            int modified_sleep = Int32.Parse(SearchScore4.Text);

            RunBarcodeAsync(modified_age, modified_sunscreen, modified_smoke, modified_stress, modified_sleep).GetAwaiter().GetResult();


            int modified_FurtureGene_Moisture = Int32.Parse(skinFutureResultList.Me_Score5);
            int modified_FurtureGene_Oilskin = Int32.Parse(skinFutureResultList.Me_Score4);
            int modified_FurtureGene_redskin = Int32.Parse(skinFutureResultList.Me_Score2);
            int modified_FurtureGene_darkskin = Int32.Parse(skinFutureResultList.Me_Score3);
            int modified_FurtureGene_Wrinkle = Int32.Parse(skinFutureResultList.Me_Score);

            switch (count)
            {
                case 1:

                    Skin_Polygon2.Visibility = Visibility.Collapsed;
                    Skin_Polygon3.Visibility = Visibility.Visible;

                    viewModel.C_Age = ResearchBarValue * 10; // 고객의 나이 업데이트


                    //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
                    int FurtureGene_Moisture1 = modified_FurtureGene_Moisture;
                    int FurtureGene_Oilskin1 = modified_FurtureGene_Oilskin;
                    int FurtureGene_redskin1 = modified_FurtureGene_redskin;
                    int FurtureGene_darkskin1 = modified_FurtureGene_darkskin;
                    int FurtureGene_Wrinkle1 = modified_FurtureGene_Wrinkle;

                    viewModel.Future_Score = FurtureGene_Moisture1; // 미래 - 수분 점수
                    viewModel.Future_Score2 = FurtureGene_Oilskin1;// 미래 - 유분 점수
                    viewModel.Future_Score3 = FurtureGene_redskin1;// 미래 - 민감 점수
                    viewModel.Future_Score4 = FurtureGene_darkskin1;// 미래 - 색소 점수
                    viewModel.Future_Score5 = FurtureGene_Wrinkle1;// 미래 - 주름 점수                

                    //------ 미래 점수 Bar 입니다. 
                    viewModel.Skin_Future_Bar = viewModel.Future_Score;
                    viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
                    viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
                    viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
                    viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;



                    // 3. 오각형 방사형 그래프 그리기 (진단하기 반영 미래점수)          

                    // double[] distancesV2 = new double[5]; // 미래 피부 점수 
                    double[] distancesV1 = new double[5];
                    // double distancesV2[5] = { 1, 2, 3, 4, 5 };

                    distancesV1[0] = viewModel.Future_Score3; // 민감
                    distancesV1[1] = viewModel.Future_Score4; // 색소
                    distancesV1[2] = viewModel.Future_Score5; // 주름
                    distancesV1[3] = viewModel.Future_Score; // 수분
                    distancesV1[4] = viewModel.Future_Score2; // 유분


                    for (int i = 0; i < 5; i++)
                    {
                        double angle = 72 * i + 54; // 오각형의 각도                       


                        double x2 = centerPoint.X + distancesV1[i] * Math.Cos(Math.PI * angle / 180);
                        double y2 = centerPoint.Y + distancesV1[i] * Math.Sin(Math.PI * angle / 180);

                        viewModel.PolygonPoints3.Add(new Point(x2 * 1.5, y2 * 1.5));
                    }
                    break;



                case 2:
                    Skin_Polygon3.Visibility = Visibility.Collapsed;
                    Skin_Polygon4.Visibility = Visibility.Visible;

                    viewModel.C_Age = ResearchBarValue * 10; // 고객의 나이 업데이트

                    //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
                    int FurtureGene_Moisture2 = modified_FurtureGene_Moisture;
                    int FurtureGene_Oilskin2 = modified_FurtureGene_Oilskin;
                    int FurtureGene_redskin2 = modified_FurtureGene_redskin;
                    int FurtureGene_darkskin2 = modified_FurtureGene_darkskin;
                    int FurtureGene_Wrinkle2 = modified_FurtureGene_Wrinkle;

                    viewModel.Future_Score = FurtureGene_Moisture2; // 미래 - 수분 점수
                    viewModel.Future_Score2 = FurtureGene_Oilskin2;// 미래 - 유분 점수
                    viewModel.Future_Score3 = FurtureGene_redskin2;// 미래 - 민감 점수
                    viewModel.Future_Score4 = FurtureGene_darkskin2;// 미래 - 색소 점수
                    viewModel.Future_Score5 = FurtureGene_Wrinkle2;// 미래 - 주름 점수          


                    //------ 미래 점수 Bar 입니다. 
                    viewModel.Skin_Future_Bar = viewModel.Future_Score;
                    viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
                    viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
                    viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
                    viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;




                    // 3. 오각형 방사형 그래프 그리기 (진단하기 반영 미래점수)          


                    // double[] distancesV2 = new double[5]; // 미래 피부 점수 
                    double[] distancesV2 = new double[5];
                    // double distancesV2[5] = { 1, 2, 3, 4, 5 };

                    distancesV2[0] = viewModel.Future_Score3; // 민감
                    distancesV2[1] = viewModel.Future_Score4; // 색소
                    distancesV2[2] = viewModel.Future_Score5; // 주름
                    distancesV2[3] = viewModel.Future_Score; // 수분
                    distancesV2[4] = viewModel.Future_Score2; // 유분


                    for (int i = 0; i < 5; i++)
                    {
                        double angle = 72 * i + 54; // 오각형의 각도                       


                        double x2 = centerPoint.X + distancesV2[i] * Math.Cos(Math.PI * angle / 180);
                        double y2 = centerPoint.Y + distancesV2[i] * Math.Sin(Math.PI * angle / 180);

                        viewModel.PolygonPoints4.Add(new Point(x2 * 1.5, y2 * 1.5));
                    }
                    break;



                case 3:
                    Skin_Polygon4.Visibility = Visibility.Collapsed;
                    Skin_Polygon5.Visibility = Visibility.Visible;

                    viewModel.C_Age = ResearchBarValue * 10; // 고객의 나이 업데이트

                    //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
                    int FurtureGene_Moisture3 = modified_FurtureGene_Moisture;
                    int FurtureGene_Oilskin3 = modified_FurtureGene_Oilskin;
                    int FurtureGene_redskin3 = modified_FurtureGene_redskin;
                    int FurtureGene_darkskin3 = modified_FurtureGene_darkskin;
                    int FurtureGene_Wrinkle3 = modified_FurtureGene_Wrinkle;

                    viewModel.Future_Score = FurtureGene_Moisture3; // 미래 - 수분 점수
                    viewModel.Future_Score2 = FurtureGene_Oilskin3;// 미래 - 유분 점수
                    viewModel.Future_Score3 = FurtureGene_redskin3;// 미래 - 민감 점수
                    viewModel.Future_Score4 = FurtureGene_darkskin3;// 미래 - 색소 점수
                    viewModel.Future_Score5 = FurtureGene_Wrinkle3;// 미래 - 주름 점수   


                    //------ 미래 점수 Bar 입니다. 
                    viewModel.Skin_Future_Bar = viewModel.Future_Score;
                    viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
                    viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
                    viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
                    viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;




                    // 3. 오각형 방사형 그래프 그리기 (진단하기 반영 미래점수)  

                    double[] distancesV3 = new double[5];


                    distancesV3[0] = viewModel.Future_Score3; // 민감
                    distancesV3[1] = viewModel.Future_Score4; // 색소
                    distancesV3[2] = viewModel.Future_Score5; // 주름
                    distancesV3[3] = viewModel.Future_Score; // 수분
                    distancesV3[4] = viewModel.Future_Score2; // 유분


                    for (int i = 0; i < 5; i++)
                    {
                        double angle = 72 * i + 54; // 오각형의 각도                       


                        double x2 = centerPoint.X + distancesV3[i] * Math.Cos(Math.PI * angle / 180);
                        double y2 = centerPoint.Y + distancesV3[i] * Math.Sin(Math.PI * angle / 180);

                        viewModel.PolygonPoints5.Add(new Point(x2 * 1.5, y2 * 1.5));
                    }
                    break;


                case 4:
                    Skin_Polygon5.Visibility = Visibility.Collapsed;
                    Skin_Polygon6.Visibility = Visibility.Visible;

                    viewModel.C_Age = ResearchBarValue * 10; // 고객의 나이 업데이트

                    //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
                    int FurtureGene_Moisture4 = modified_FurtureGene_Moisture;
                    int FurtureGene_Oilskin4 = modified_FurtureGene_Oilskin;
                    int FurtureGene_redskin4 = modified_FurtureGene_redskin;
                    int FurtureGene_darkskin4 = modified_FurtureGene_darkskin;
                    int FurtureGene_Wrinkle4 = modified_FurtureGene_Wrinkle;

                    viewModel.Future_Score = FurtureGene_Moisture4; // 미래 - 수분 점수
                    viewModel.Future_Score2 = FurtureGene_Oilskin4;// 미래 - 유분 점수
                    viewModel.Future_Score3 = FurtureGene_redskin4;// 미래 - 민감 점수
                    viewModel.Future_Score4 = FurtureGene_darkskin4;// 미래 - 색소 점수
                    viewModel.Future_Score5 = FurtureGene_Wrinkle4;// 미래 - 주름 점수   


                    //------ 미래 점수 Bar 입니다. 
                    viewModel.Skin_Future_Bar = viewModel.Future_Score;
                    viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
                    viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
                    viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
                    viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;




                    // 3. 오각형 방사형 그래프 그리기 (진단하기 반영 미래점수)  

                    double[] distancesV4 = new double[5];


                    distancesV4[0] = viewModel.Future_Score3; // 민감
                    distancesV4[1] = viewModel.Future_Score4; // 색소
                    distancesV4[2] = viewModel.Future_Score5; // 주름
                    distancesV4[3] = viewModel.Future_Score; // 수분
                    distancesV4[4] = viewModel.Future_Score2; // 유분


                    for (int i = 0; i < 5; i++)
                    {
                        double angle = 72 * i + 54; // 오각형의 각도                       


                        double x2 = centerPoint.X + distancesV4[i] * Math.Cos(Math.PI * angle / 180);
                        double y2 = centerPoint.Y + distancesV4[i] * Math.Sin(Math.PI * angle / 180);

                        viewModel.PolygonPoints6.Add(new Point(x2 * 1.5, y2 * 1.5));
                    }
                    break;



                case 5:
                    Skin_Polygon6.Visibility = Visibility.Collapsed;
                    Skin_Polygon7.Visibility = Visibility.Visible;

                    viewModel.C_Age = ResearchBarValue * 10; // 고객의 나이 업데이트


                    //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
                    int FurtureGene_Moisture5 = modified_FurtureGene_Moisture;
                    int FurtureGene_Oilskin5 = modified_FurtureGene_Oilskin;
                    int FurtureGene_redskin5 = modified_FurtureGene_redskin;
                    int FurtureGene_darkskin5 = modified_FurtureGene_darkskin;
                    int FurtureGene_Wrinkle5 = modified_FurtureGene_Wrinkle;

                    viewModel.Future_Score = FurtureGene_Moisture5; // 미래 - 수분 점수
                    viewModel.Future_Score2 = FurtureGene_Oilskin5;// 미래 - 유분 점수
                    viewModel.Future_Score3 = FurtureGene_redskin5;// 미래 - 민감 점수
                    viewModel.Future_Score4 = FurtureGene_darkskin5;// 미래 - 색소 점수
                    viewModel.Future_Score5 = FurtureGene_Wrinkle5;// 미래 - 주름 점수   


                    //------ 미래 점수 Bar 입니다. 
                    viewModel.Skin_Future_Bar = viewModel.Future_Score;
                    viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
                    viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
                    viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
                    viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;




                    // 3. 오각형 방사형 그래프 그리기 (진단하기 반영 미래점수)  

                    double[] distancesV5 = new double[5];


                    distancesV5[0] = viewModel.Future_Score3; // 민감
                    distancesV5[1] = viewModel.Future_Score4; // 색소
                    distancesV5[2] = viewModel.Future_Score5; // 주름
                    distancesV5[3] = viewModel.Future_Score; // 수분
                    distancesV5[4] = viewModel.Future_Score2; // 유분


                    for (int i = 0; i < 5; i++)
                    {
                        double angle = 72 * i + 54; // 오각형의 각도                       


                        double x2 = centerPoint.X + distancesV5[i] * Math.Cos(Math.PI * angle / 180);
                        double y2 = centerPoint.Y + distancesV5[i] * Math.Sin(Math.PI * angle / 180);

                        viewModel.PolygonPoints7.Add(new Point(x2 * 1.5, y2 * 1.5));
                    }
                    break;


                case 6:
                    Skin_Polygon7.Visibility = Visibility.Collapsed;
                    Skin_Polygon8.Visibility = Visibility.Visible;

                    viewModel.C_Age = ResearchBarValue * 10; // 고객의 나이 업데이트

                    //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
                    int FurtureGene_Moisture6 = modified_FurtureGene_Moisture;
                    int FurtureGene_Oilskin6 = modified_FurtureGene_Oilskin;
                    int FurtureGene_redskin6 = modified_FurtureGene_redskin;
                    int FurtureGene_darkskin6 = modified_FurtureGene_darkskin;
                    int FurtureGene_Wrinkle6 = modified_FurtureGene_Wrinkle;

                    viewModel.Future_Score = FurtureGene_Moisture6; // 미래 - 수분 점수
                    viewModel.Future_Score2 = FurtureGene_Oilskin6;// 미래 - 유분 점수
                    viewModel.Future_Score3 = FurtureGene_redskin6;// 미래 - 민감 점수
                    viewModel.Future_Score4 = FurtureGene_darkskin6;// 미래 - 색소 점수
                    viewModel.Future_Score5 = FurtureGene_Wrinkle6;// 미래 - 주름 점수   



                    //------ 미래 점수 Bar 입니다. 
                    viewModel.Skin_Future_Bar = viewModel.Future_Score;
                    viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
                    viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
                    viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
                    viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;




                    // 3. 오각형 방사형 그래프 그리기 (진단하기 반영 미래점수)  

                    double[] distancesV6 = new double[5];


                    distancesV6[0] = viewModel.Future_Score3; // 민감
                    distancesV6[1] = viewModel.Future_Score4; // 색소
                    distancesV6[2] = viewModel.Future_Score5; // 주름
                    distancesV6[3] = viewModel.Future_Score; // 수분
                    distancesV6[4] = viewModel.Future_Score2; // 유분


                    for (int i = 0; i < 5; i++)
                    {
                        double angle = 72 * i + 54; // 오각형의 각도                       


                        double x2 = centerPoint.X + distancesV6[i] * Math.Cos(Math.PI * angle / 180);
                        double y2 = centerPoint.Y + distancesV6[i] * Math.Sin(Math.PI * angle / 180);

                        viewModel.PolygonPoints8.Add(new Point(x2 * 1.5, y2 * 1.5));
                    }
                    break;

                case 7:
                    Skin_Polygon8.Visibility = Visibility.Collapsed;
                    Skin_Polygon9.Visibility = Visibility.Visible;

                    viewModel.C_Age = ResearchBarValue * 10; // 고객의 나이 업데이트


                    //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
                    int FurtureGene_Moisture7 = modified_FurtureGene_Moisture;
                    int FurtureGene_Oilskin7 = modified_FurtureGene_Oilskin;
                    int FurtureGene_redskin7 = modified_FurtureGene_redskin;
                    int FurtureGene_darkskin7 = modified_FurtureGene_darkskin;
                    int FurtureGene_Wrinkle7 = modified_FurtureGene_Wrinkle;

                    viewModel.Future_Score = FurtureGene_Moisture7; // 미래 - 수분 점수
                    viewModel.Future_Score3 = FurtureGene_redskin7;// 미래 - 민감 점수
                    viewModel.Future_Score2 = FurtureGene_Oilskin7;// 미래 - 유분 점수
                    viewModel.Future_Score4 = FurtureGene_darkskin7;// 미래 - 색소 점수
                    viewModel.Future_Score5 = FurtureGene_Wrinkle7;// 미래 - 주름 점수   



                    //------ 미래 점수 Bar 입니다. 
                    viewModel.Skin_Future_Bar = viewModel.Future_Score;
                    viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
                    viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
                    viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
                    viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;




                    // 3. 오각형 방사형 그래프 그리기 (진단하기 반영 미래점수)  

                    double[] distancesV7 = new double[5];


                    distancesV7[0] = viewModel.Future_Score3; // 민감
                    distancesV7[1] = viewModel.Future_Score4; // 색소
                    distancesV7[2] = viewModel.Future_Score5; // 주름
                    distancesV7[3] = viewModel.Future_Score; // 수분
                    distancesV7[4] = viewModel.Future_Score2; // 유분


                    for (int i = 0; i < 5; i++)
                    {
                        double angle = 72 * i + 54; // 오각형의 각도                       


                        double x2 = centerPoint.X + distancesV7[i] * Math.Cos(Math.PI * angle / 180);
                        double y2 = centerPoint.Y + distancesV7[i] * Math.Sin(Math.PI * angle / 180);

                        viewModel.PolygonPoints9.Add(new Point(x2 * 1.5, y2 * 1.5));
                    }
                    break;



                case 8:
                    Skin_Polygon9.Visibility = Visibility.Collapsed;
                    Skin_Polygon10.Visibility = Visibility.Visible;

                    viewModel.C_Age = ResearchBarValue * 10; // 고객의 나이 업데이트

                    //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
                    int FurtureGene_Moisture8 = modified_FurtureGene_Moisture;
                    int FurtureGene_Oilskin8 = modified_FurtureGene_Oilskin;
                    int FurtureGene_redskin8 = modified_FurtureGene_redskin;
                    int FurtureGene_darkskin8 = modified_FurtureGene_darkskin;
                    int FurtureGene_Wrinkle8 = modified_FurtureGene_Wrinkle;

                    viewModel.Future_Score = FurtureGene_Moisture8; // 미래 - 수분 점수
                    viewModel.Future_Score2 = FurtureGene_Oilskin8;// 미래 - 유분 점수
                    viewModel.Future_Score3 = FurtureGene_redskin8;// 미래 - 민감 점수
                    viewModel.Future_Score4 = FurtureGene_darkskin8;// 미래 - 색소 점수
                    viewModel.Future_Score5 = FurtureGene_Wrinkle8;// 미래 - 주름 점수   

                    //------ 미래 점수 Bar 입니다. 
                    viewModel.Skin_Future_Bar = viewModel.Future_Score;
                    viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
                    viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
                    viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
                    viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;




                    // 3. 오각형 방사형 그래프 그리기 (진단하기 반영 미래점수)  

                    double[] distancesV8 = new double[5];


                    distancesV8[0] = viewModel.Future_Score3; // 민감
                    distancesV8[1] = viewModel.Future_Score4; // 색소
                    distancesV8[2] = viewModel.Future_Score5; // 주름
                    distancesV8[3] = viewModel.Future_Score; // 수분
                    distancesV8[4] = viewModel.Future_Score2; // 유분


                    for (int i = 0; i < 5; i++)
                    {
                        double angle = 72 * i + 54; // 오각형의 각도                       


                        double x2 = centerPoint.X + distancesV8[i] * Math.Cos(Math.PI * angle / 180);
                        double y2 = centerPoint.Y + distancesV8[i] * Math.Sin(Math.PI * angle / 180);

                        viewModel.PolygonPoints10.Add(new Point(x2 * 1.5, y2 * 1.5));
                    }
                    break;


                case 9:
                    Skin_Polygon10.Visibility = Visibility.Collapsed;
                    Skin_Polygon11.Visibility = Visibility.Visible;

                    viewModel.C_Age = ResearchBarValue * 10; // 고객의 나이 업데이트


                    //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
                    int FurtureGene_Moisture9 = modified_FurtureGene_Moisture;
                    int FurtureGene_Oilskin9 = modified_FurtureGene_Oilskin;
                    int FurtureGene_redskin9 = modified_FurtureGene_redskin;
                    int FurtureGene_darkskin9 = modified_FurtureGene_darkskin;
                    int FurtureGene_Wrinkle9 = modified_FurtureGene_Wrinkle;

                    viewModel.Future_Score = FurtureGene_Moisture9; // 미래 - 수분 점수
                    viewModel.Future_Score2 = FurtureGene_Oilskin9;// 미래 - 유분 점수
                    viewModel.Future_Score3 = FurtureGene_redskin9;// 미래 - 민감 점수
                    viewModel.Future_Score4 = FurtureGene_darkskin9;// 미래 - 색소 점수
                    viewModel.Future_Score5 = FurtureGene_Wrinkle9;// 미래 - 주름 점수   

                    //------ 미래 점수 Bar 입니다. 
                    viewModel.Skin_Future_Bar = viewModel.Future_Score;
                    viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
                    viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
                    viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
                    viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;




                    // 3. 오각형 방사형 그래프 그리기 (진단하기 반영 미래점수)  

                    double[] distancesV9 = new double[5];


                    distancesV9[0] = viewModel.Future_Score3; // 민감
                    distancesV9[1] = viewModel.Future_Score4; // 색소
                    distancesV9[2] = viewModel.Future_Score5; // 주름
                    distancesV9[3] = viewModel.Future_Score; // 수분
                    distancesV9[4] = viewModel.Future_Score2; // 유분


                    for (int i = 0; i < 5; i++)
                    {
                        double angle = 72 * i + 54; // 오각형의 각도                       


                        double x2 = centerPoint.X + distancesV9[i] * Math.Cos(Math.PI * angle / 180);
                        double y2 = centerPoint.Y + distancesV9[i] * Math.Sin(Math.PI * angle / 180);

                        viewModel.PolygonPoints11.Add(new Point(x2 * 1.5, y2 * 1.5));
                    }
                    break;



                case 10:
                    Skin_Polygon11.Visibility = Visibility.Collapsed;
                    Skin_Polygon12.Visibility = Visibility.Visible;

                    viewModel.C_Age = ResearchBarValue * 10; // 고객의 나이 업데이트


                    //  미래 점수 : (피부측정값 + 유전자 점수 + 문진 받아옴) (기본값)
                    int FurtureGene_Moisture10 = modified_FurtureGene_Moisture;
                    int FurtureGene_Oilskin10 = modified_FurtureGene_Oilskin;
                    int FurtureGene_redskin10 = modified_FurtureGene_redskin;
                    int FurtureGene_darkskin10 = modified_FurtureGene_darkskin;
                    int FurtureGene_Wrinkle10 = modified_FurtureGene_Wrinkle;

                    viewModel.Future_Score = FurtureGene_Moisture10; // 미래 - 수분 점수
                    viewModel.Future_Score2 = FurtureGene_Oilskin10;// 미래 - 유분 점수
                    viewModel.Future_Score3 = FurtureGene_redskin10;// 미래 - 민감 점수
                    viewModel.Future_Score4 = FurtureGene_darkskin10;// 미래 - 색소 점수
                    viewModel.Future_Score5 = FurtureGene_Wrinkle10;// 미래 - 주름 점수   

                    //------ 미래 점수 Bar 입니다. 
                    viewModel.Skin_Future_Bar = viewModel.Future_Score;
                    viewModel.Skin_Future_Bar2 = viewModel.Future_Score2;
                    viewModel.Skin_Future_Bar3 = viewModel.Future_Score3;
                    viewModel.Skin_Future_Bar4 = viewModel.Future_Score4;
                    viewModel.Skin_Future_Bar5 = viewModel.Future_Score5;




                    // 3. 오각형 방사형 그래프 그리기 (진단하기 반영 미래점수)  

                    double[] distancesV10 = new double[5];


                    distancesV10[0] = viewModel.Future_Score3; // 민감
                    distancesV10[1] = viewModel.Future_Score4; // 색소
                    distancesV10[2] = viewModel.Future_Score5; // 주름
                    distancesV10[3] = viewModel.Future_Score; // 수분
                    distancesV10[4] = viewModel.Future_Score2; // 유분


                    for (int i = 0; i < 5; i++)
                    {
                        double angle = 72 * i + 54; // 오각형의 각도                       


                        double x2 = centerPoint.X + distancesV10[i] * Math.Cos(Math.PI * angle / 180);
                        double y2 = centerPoint.Y + distancesV10[i] * Math.Sin(Math.PI * angle / 180);

                        viewModel.PolygonPoints12.Add(new Point(x2 * 1.5, y2 * 1.5));
                    }
                    break;



                default:

                    break;
            }


        }
    }
}
