﻿using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace IOPE_LAB.Contents.SkinSolution
{
    /// <summary>
    /// MainPage4.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MySolution_P1 : UserControl
    {
        // 점수 및 항목을 저장할 변수
        int[] GradeValue_A = new int[11];
        string[] Item_A = new string[11];




        public MySolution_P1()
        {
            InitializeComponent();
            this.DataContext = new MySolution_ViewModel();

            ClientName();
            Items();
            GradeValueControl();


        }

        //  "   "님의 마이 솔루션 - 이름
        private void ClientName()
        {
            MySolution_ViewModel Client = this.DataContext as MySolution_ViewModel;
            Client.C_Name = LoginSession.MySolution_ViewModel.C_Name; // No1. 고객 이름

        }

        private void Items()
        {
            MySolution_ViewModel Items = this.DataContext as MySolution_ViewModel;
            // 항목별 이름


            Items.Item1 = "색소침착"; //피부
            Items.Item2 = "피부노화";  //피부
            Items.Item3 = "기미/주근깨";  //피부
            Items.Item4 = "여드름 발생";  //피부
            Items.Item5 = "피부염증";  //피부
            Items.Item6 = "태닝반응";  //피부
            Items.Item7 = "튼살/각질";  //피부

            Items.Item8 = "남성형탈모"; // --모발
            Items.Item9 = "모발굵기"; // --모발
            Items.Item10 = "원형 탈모"; // --모발
            Items.Item11 = "새치"; // --모발



            Item_A[0] = Items.Item1;
            Item_A[1] = Items.Item2;           
            Item_A[2] = Items.Item3;                 
            Item_A[3] = Items.Item4;          
            Item_A[4] = Items.Item5;         
            Item_A[5] = Items.Item6;            
            Item_A[6] = Items.Item7;             
                    
            Item_A[7] = Items.Item8;                
            Item_A[8] = Items.Item9;                       
            Item_A[9] = Items.Item10;   
            Item_A[10] = Items.Item11;
        }

        private void GradeValueControl()
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;
            // 등수
            viewModel.GradeValue = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item1); // No1. 색소침착 
            viewModel.GradeValue2 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item2); // No2. 피부노화 
            viewModel.GradeValue3 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item5); // No3. 기미/주근깨 
            viewModel.GradeValue4 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item6); // No4. 여드름 발생
            viewModel.GradeValue5 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item7); // No5. 피부염증
            viewModel.GradeValue6 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item8); // No6. 태닝반응
            viewModel.GradeValue7 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item9); // No7. 튼살/각질
                
            viewModel.GradeValue8 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item3); // No8. 남성형탈모
            viewModel.GradeValue9 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item4); // No9. 모발굵기
            viewModel.GradeValue10 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item10); // No10. 원형 탈모
            viewModel.GradeValue11 = 100 - Int32.Parse(LoginSession.MySolution_ViewModel.Item11); // No11. 새치


            viewModel.GradeValue_Bar = 101 - viewModel.GradeValue;
            GradeValue_A[0] = viewModel.GradeValue;

            viewModel.GradeValue2_Bar = 101 - viewModel.GradeValue2;
            GradeValue_A[1] = viewModel.GradeValue2;                 
      
       
            viewModel.GradeValue3_Bar = 101 - viewModel.GradeValue3;
            GradeValue_A[2] = viewModel.GradeValue3;


            viewModel.GradeValue4_Bar = 101 - viewModel.GradeValue4;
            GradeValue_A[3] = viewModel.GradeValue4;

            viewModel.GradeValue5_Bar = 101 - viewModel.GradeValue5;
            GradeValue_A[4] = viewModel.GradeValue5;
            
            viewModel.GradeValue6_Bar = 101 - viewModel.GradeValue6;
            GradeValue_A[5] = viewModel.GradeValue6;

    
            viewModel.GradeValue7_Bar = 101 - viewModel.GradeValue7;
            GradeValue_A[6] = viewModel.GradeValue7;

            viewModel.GradeValue8_Bar = 101 - viewModel.GradeValue8;
            GradeValue_A[7] = viewModel.GradeValue8;

   
            viewModel.GradeValue9_Bar = 101 - viewModel.GradeValue9;
            GradeValue_A[8] = viewModel.GradeValue9;

            viewModel.GradeValue10_Bar = 101 - viewModel.GradeValue10;
            GradeValue_A[9] = viewModel.GradeValue10;

            viewModel.GradeValue11_Bar = 101 - viewModel.GradeValue11;
            GradeValue_A[10] = viewModel.GradeValue11;

        


        }


        // 양호한 순서대로 정렬 (점수가 높은 순서대로)
        private void Sort_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            int[] GradeValue_Sort = new int[7];
            string[] Item_Sort = new string[7];


            for (int i = 0; i < 7; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1]; viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
            viewModel.GradeValue6 = GradeValue_Sort[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_Sort[5]; viewModel.Item6 = Item_Sort[5];
            viewModel.GradeValue7 = GradeValue_Sort[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_Sort[6]; viewModel.Item7 = Item_Sort[6];
       

            int[] GradeValue_Sort_V2 = new int[4];
            string[] Item_Sort_V2 = new string[4];


            for (int i = 0; i < 4; i++)
            {
                GradeValue_Sort_V2[i] = GradeValue_A[i+7];
                Item_Sort_V2[i] = Item_A[i + 7];
            }

            Array.Sort(GradeValue_Sort_V2, Item_Sort_V2);
         
            viewModel.GradeValue8 = GradeValue_Sort_V2[0]; viewModel.GradeValue8_Bar = 101 - GradeValue_Sort_V2[0]; viewModel.Item8 = Item_Sort_V2[0];
            viewModel.GradeValue9 = GradeValue_Sort_V2[1]; viewModel.GradeValue9_Bar = 101 - GradeValue_Sort_V2[1]; viewModel.Item9 = Item_Sort_V2[1];
            viewModel.GradeValue10 = GradeValue_Sort_V2[2]; viewModel.GradeValue10_Bar = 101 - GradeValue_Sort_V2[2]; viewModel.Item10 = Item_Sort_V2[2];
            viewModel.GradeValue11 = GradeValue_Sort_V2[3]; viewModel.GradeValue11_Bar = 101 - GradeValue_Sort_V2[3]; viewModel.Item11 = Item_Sort_V2[3];



        }


        // 주의를 요하는 순서대로 정렬 (점수가 낮은 순서대로)
        private void Ascending_Sort_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            /*
            int[] GradeValue_Sort = new int[11];
            string[] Item_Sort = new string[11];
            for (int i = 0; i < 11; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);
            Array.Reverse(GradeValue_Sort);
            Array.Reverse(Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1]; viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
            viewModel.GradeValue6 = GradeValue_Sort[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_Sort[5]; viewModel.Item6 = Item_Sort[5];
            viewModel.GradeValue7 = GradeValue_Sort[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_Sort[6]; viewModel.Item7 = Item_Sort[6];
            viewModel.GradeValue8 = GradeValue_Sort[7]; viewModel.GradeValue8_Bar = 101 - GradeValue_Sort[7]; viewModel.Item8 = Item_Sort[7];
            viewModel.GradeValue9 = GradeValue_Sort[8]; viewModel.GradeValue9_Bar = 101 - GradeValue_Sort[8]; viewModel.Item9 = Item_Sort[8];
            viewModel.GradeValue10 = GradeValue_Sort[9]; viewModel.GradeValue10_Bar = 101 - GradeValue_Sort[9]; viewModel.Item10 = Item_Sort[9];
            viewModel.GradeValue11 = GradeValue_Sort[10]; viewModel.GradeValue11_Bar = 101 - GradeValue_Sort[10]; viewModel.Item11 = Item_Sort[10];
            */


            int[] GradeValue_Sort = new int[7];
            string[] Item_Sort = new string[7];

            for (int i = 0; i < 7; i++)
            {
                GradeValue_Sort[i] = GradeValue_A[i];
                Item_Sort[i] = Item_A[i];
            }

            Array.Sort(GradeValue_Sort, Item_Sort);
            Array.Reverse(GradeValue_Sort);
            Array.Reverse(Item_Sort);

            viewModel.GradeValue = GradeValue_Sort[0]; viewModel.GradeValue_Bar = 101 - GradeValue_Sort[0]; viewModel.Item1 = Item_Sort[0];
            viewModel.GradeValue2 = GradeValue_Sort[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_Sort[1]; viewModel.Item2 = Item_Sort[1];
            viewModel.GradeValue3 = GradeValue_Sort[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_Sort[2]; viewModel.Item3 = Item_Sort[2];
            viewModel.GradeValue4 = GradeValue_Sort[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_Sort[3]; viewModel.Item4 = Item_Sort[3];
            viewModel.GradeValue5 = GradeValue_Sort[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_Sort[4]; viewModel.Item5 = Item_Sort[4];
            viewModel.GradeValue6 = GradeValue_Sort[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_Sort[5]; viewModel.Item6 = Item_Sort[5];
            viewModel.GradeValue7 = GradeValue_Sort[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_Sort[6]; viewModel.Item7 = Item_Sort[6];


            int[] GradeValue_Sort_V2 = new int[4];
            string[] Item_Sort_V2 = new string[4];


            for (int i = 0; i < 4; i++)
            {
                GradeValue_Sort_V2[i] = GradeValue_A[i + 7];
                Item_Sort_V2[i] = Item_A[i + 7];
            }

            Array.Sort(GradeValue_Sort_V2, Item_Sort_V2);
            Array.Reverse(GradeValue_Sort_V2);
            Array.Reverse(Item_Sort_V2);

            viewModel.GradeValue8 = GradeValue_Sort_V2[0]; viewModel.GradeValue8_Bar = 101 - GradeValue_Sort_V2[0]; viewModel.Item8 = Item_Sort_V2[0];
            viewModel.GradeValue9 = GradeValue_Sort_V2[1]; viewModel.GradeValue9_Bar = 101 - GradeValue_Sort_V2[1]; viewModel.Item9 = Item_Sort_V2[1];
            viewModel.GradeValue10 = GradeValue_Sort_V2[2]; viewModel.GradeValue10_Bar = 101 - GradeValue_Sort_V2[2]; viewModel.Item10 = Item_Sort_V2[2];
            viewModel.GradeValue11 = GradeValue_Sort_V2[3]; viewModel.GradeValue11_Bar = 101 - GradeValue_Sort_V2[3]; viewModel.Item11 = Item_Sort_V2[3];


        }








        /*

        // 초기값으로 정렬
        private void Origin_Button_Click(object sender, RoutedEventArgs e)
        {
            MySolution_ViewModel viewModel = this.DataContext as MySolution_ViewModel;

            viewModel.GradeValue = GradeValue_A[0]; viewModel.GradeValue_Bar = 101 - GradeValue_A[0]; viewModel.Item1 = Item_A[0];
            viewModel.GradeValue2 = GradeValue_A[1]; viewModel.GradeValue2_Bar = 101 - GradeValue_A[1]; viewModel.Item2 = Item_A[1];
            viewModel.GradeValue3 = GradeValue_A[2]; viewModel.GradeValue3_Bar = 101 - GradeValue_A[2]; viewModel.Item3 = Item_A[2];
            viewModel.GradeValue4 = GradeValue_A[3]; viewModel.GradeValue4_Bar = 101 - GradeValue_A[3]; viewModel.Item4 = Item_A[3];
            viewModel.GradeValue5 = GradeValue_A[4]; viewModel.GradeValue5_Bar = 101 - GradeValue_A[4]; viewModel.Item5 = Item_A[4];
            viewModel.GradeValue6 = GradeValue_A[5]; viewModel.GradeValue6_Bar = 101 - GradeValue_A[5]; viewModel.Item6 = Item_A[5];
            viewModel.GradeValue7 = GradeValue_A[6]; viewModel.GradeValue7_Bar = 101 - GradeValue_A[6]; viewModel.Item7 = Item_A[6];
            viewModel.GradeValue8 = GradeValue_A[7]; viewModel.GradeValue8_Bar = 101 - GradeValue_A[7]; viewModel.Item8 = Item_A[7];
            viewModel.GradeValue9 = GradeValue_A[8]; viewModel.GradeValue9_Bar = 101 - GradeValue_A[8]; viewModel.Item9 = Item_A[8];
            viewModel.GradeValue10 = GradeValue_A[9]; viewModel.GradeValue10_Bar = 101 - GradeValue_A[9]; viewModel.Item10 = Item_A[9];

        }  

    */

    }
}
