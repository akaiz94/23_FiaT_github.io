﻿using IOPE_LAB_CONTROLS.Base;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IOPE_LAB.Contents.SkinSolution
{
    /// <summary>
    /// MySolution_Main.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MySolution_Main : Page
    {

        public enum MySolution_PageName
        {
            MySolution_P1, MySolution_P1_sub1, MySolution_P1_sub2, MySolution_P1_sub3, MySolution_P1_sub4, MySolution_P1_sub5, MySolution_P2
        }

        public MySolution_Main()
        {
            InitializeComponent();

            ClientName();


            this.btn_Back.Click += Btn_Back_Click;
            this.btn_Next.Click += Btn_Next_Click;
            this.btn_Print.Click += Btn_Print_Click;
        }

        //  "   "님의 마이 솔루션 - 이름
        private void ClientName()
        {
            //MySolution_ViewModel Client = this.DataContext as MySolution_ViewModel;
            //Client.C_Name = "홍길동";
            //Client.C_Date = "2023-05-04";
            //Client.C_Visit_Number = 11;

            MySolution_ViewModel Client = this.DataContext as MySolution_ViewModel;
            MemberService.MemberServiceClient msc = new MemberService.MemberServiceClient();
            DataTable dt = msc.visitCount("IC", LoginSession.SelectedMember.name, LoginSession.SelectedMember.birthdate, LoginSession.SelectedMember.PCCD);
            string searchDate = LoginSession.SelectedMember.rsvn_date.ToString("yyyy-MM-dd").Replace("-", "/");

            Client.C_Name = LoginSession.MySolution_ViewModel.C_Name; // No1.고객 이름
            Client.C_Date = searchDate; //  No2. 측정일자
            //Client.C_Visit_Number = 11; //  No3.측정 날짜
            Client.ResercherName = LoginSession.Selected_C_ResultPageData.manager_value != null ? LoginSession.Selected_C_ResultPageData.manager_value : ""; //  No4.연구원 이름


            if (dt.Rows.Count > 0)
            {
                string visit = dt.Rows.Count > 0 ? dt.Rows[0]["cnt"].ToString() : "0";
                Client.C_Visit_Number = Int32.Parse(visit);
            }
        }

        private void Btn_Print_Click(object sender, RoutedEventArgs e)
        {
            Window popupWindow = new Window
            {
                Title = "MY SKINSOLUTION",
                Width = 720,
                Height = 1050,              
                Content = new MySolution_PrintPage()               

            };
            popupWindow.ShowDialog();
        }


        private void Btn_Next_Click(object sender, RoutedEventArgs e)
        {
            switch (GetMySolution_PageName())
            {
                case MySolution_PageName.MySolution_P1:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1_sub1);
                    break;

                case MySolution_PageName.MySolution_P1_sub1:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1_sub2);
                    break;

                case MySolution_PageName.MySolution_P1_sub2:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1_sub3);
                    break;

                case MySolution_PageName.MySolution_P1_sub3:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1_sub4);
                    break;

                case MySolution_PageName.MySolution_P1_sub4:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1_sub5);
                    break;

                case MySolution_PageName.MySolution_P1_sub5:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P2);
                    break;

                case MySolution_PageName.MySolution_P2:
                    break;
            }
        }

        private void Btn_Back_Click(object sender, RoutedEventArgs e)
        {
            switch (GetMySolution_PageName())
            {
                case MySolution_PageName.MySolution_P2:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1_sub5);
                    break;

                case MySolution_PageName.MySolution_P1_sub5:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1_sub4);
                    break;

                case MySolution_PageName.MySolution_P1_sub4:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1_sub3);
                    break;

                case MySolution_PageName.MySolution_P1_sub3:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1_sub2);
                    break;

                case MySolution_PageName.MySolution_P1_sub2:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1_sub1);
                    break;

                case MySolution_PageName.MySolution_P1_sub1:
                    SetMySolution_PageUI(MySolution_PageName.MySolution_P1);
                    break;
            }
        }



        public MySolution_PageName GetMySolution_PageName()
        {
            MySolution_PageName result = MySolution_PageName.MySolution_P1; //초기값

            if (hs_MySolution_P1.Visibility == Visibility)
            {
                result = MySolution_PageName.MySolution_P1;
            }

            else if (hs_MySolution_P1_sub1.Visibility == Visibility.Visible)
            {
                result = MySolution_PageName.MySolution_P1_sub1;
            }

            else if (hs_MySolution_P1_sub2.Visibility == Visibility.Visible)
            {
                result = MySolution_PageName.MySolution_P1_sub2;
            }

            else if (hs_MySolution_P1_sub3.Visibility == Visibility.Visible)
            {
                result = MySolution_PageName.MySolution_P1_sub3;
            }

            else if (hs_MySolution_P1_sub4.Visibility == Visibility.Visible)
            {
                result = MySolution_PageName.MySolution_P1_sub4;
            }

            else if (hs_MySolution_P1_sub5.Visibility == Visibility.Visible)
            {
                result = MySolution_PageName.MySolution_P1_sub5;
            }

            else if (hs_MySolution_P2.Visibility == Visibility.Visible)
            {
                result = MySolution_PageName.MySolution_P2;
            }

            return result;
        }


        public void SetMySolution_PageUI(MySolution_PageName MySolution_pagename)
        {
            switch (MySolution_pagename)
            {
                case MySolution_PageName.MySolution_P1: //페이지 보이기 (1페이지)
                    hs_MySolution_P1.Visibility = Visibility.Visible;
                    hs_MySolution_P1_sub1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub2.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub3.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub4.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub5.Visibility = Visibility.Collapsed;
                    hs_MySolution_P2.Visibility = Visibility.Collapsed;

                    btn_Next.Visibility = Visibility.Visible; // 버튼 구분
                    btn_Back.Visibility = Visibility.Collapsed;
                    btn_Print.Visibility = Visibility.Collapsed;
                    break;

                case MySolution_PageName.MySolution_P1_sub1: // 1-2페이지
                    hs_MySolution_P1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub1.Visibility = Visibility.Visible;
                    hs_MySolution_P1_sub2.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub3.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub4.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub5.Visibility = Visibility.Collapsed;
                    hs_MySolution_P2.Visibility = Visibility.Collapsed;

                    btn_Next.Visibility = Visibility.Visible;
                    btn_Back.Visibility = Visibility.Visible;
                    btn_Print.Visibility = Visibility.Collapsed;
                    break;

                case MySolution_PageName.MySolution_P1_sub2: // 1-3페이지
                    hs_MySolution_P1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub2.Visibility = Visibility.Visible;
                    hs_MySolution_P1_sub3.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub4.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub5.Visibility = Visibility.Collapsed;
                    hs_MySolution_P2.Visibility = Visibility.Collapsed;

                    btn_Next.Visibility = Visibility.Visible;
                    btn_Back.Visibility = Visibility.Visible;
                    btn_Print.Visibility = Visibility.Collapsed;
                    break;


                case MySolution_PageName.MySolution_P1_sub3: // 1-4페이지
                    hs_MySolution_P1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub2.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub3.Visibility = Visibility.Visible;
                    hs_MySolution_P1_sub4.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub5.Visibility = Visibility.Collapsed;
                    hs_MySolution_P2.Visibility = Visibility.Collapsed;

                    btn_Next.Visibility = Visibility.Visible;
                    btn_Back.Visibility = Visibility.Visible;
                    btn_Print.Visibility = Visibility.Collapsed;
                    break;

                case MySolution_PageName.MySolution_P1_sub4: // 1-5페이지
                    hs_MySolution_P1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub2.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub3.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub4.Visibility = Visibility.Visible;
                    hs_MySolution_P1_sub5.Visibility = Visibility.Collapsed;
                    hs_MySolution_P2.Visibility = Visibility.Collapsed;

                    btn_Next.Visibility = Visibility.Visible;
                    btn_Back.Visibility = Visibility.Visible;
                    btn_Print.Visibility = Visibility.Collapsed;
                    break;


                case MySolution_PageName.MySolution_P1_sub5: // 1-6페이지
                    hs_MySolution_P1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub2.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub3.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub4.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub5.Visibility = Visibility.Visible;
                    hs_MySolution_P2.Visibility = Visibility.Collapsed;

                    My_Skin.Visibility = Visibility.Visible;
                    My_Skin1.Visibility = Visibility.Visible;
                    My_Skin2.Visibility = Visibility.Visible;

                    My_Skin_copy.Visibility = Visibility.Collapsed;
                    My_Skin1_copy.Visibility = Visibility.Collapsed;
                    My_Skin2_copy.Visibility = Visibility.Collapsed;


                    btn_Next.Visibility = Visibility.Visible;
                    btn_Back.Visibility = Visibility.Visible;
                    btn_Print.Visibility = Visibility.Collapsed;

                    rec1.Visibility = Visibility.Visible;
                    My_Prof1.Visibility = Visibility.Visible;

                    rec2.Visibility = Visibility.Collapsed;
                    My_Prof2.Visibility = Visibility.Collapsed;

                    break;


                case MySolution_PageName.MySolution_P2:
                    hs_MySolution_P1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub1.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub2.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub3.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub4.Visibility = Visibility.Collapsed;
                    hs_MySolution_P1_sub5.Visibility = Visibility.Collapsed;
                    hs_MySolution_P2.Visibility = Visibility.Visible;

                    My_Skin.Visibility = Visibility.Collapsed;
                    My_Skin1.Visibility = Visibility.Collapsed;
                    My_Skin2.Visibility = Visibility.Collapsed;

                    My_Skin_copy.Visibility = Visibility.Visible;
                    My_Skin1_copy.Visibility = Visibility.Visible;
                    My_Skin2_copy.Visibility = Visibility.Visible;

                    btn_Next.Visibility = Visibility.Collapsed;
                    btn_Back.Visibility = Visibility.Visible;
                    btn_Print.Visibility = Visibility.Visible;

                    rec1.Visibility = Visibility.Collapsed;
                    My_Prof1.Visibility = Visibility.Collapsed;

                    rec2.Visibility = Visibility.Visible;
                    My_Prof2.Visibility = Visibility.Visible;

                    break;

            }
        }

     
    }
}
