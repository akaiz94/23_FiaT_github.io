﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Media;
using System.Collections.ObjectModel;


namespace IOPE_LAB.Contents.SkinSolution
{
    public class MySolution_ViewModel : INotifyPropertyChanged
    {
        /*****
        마이스킨 솔루션 1페이지
        *****/



        // 고객 이름 (client name)
        private string _c_Name;
        public string C_Name
        {
            get { return _c_Name; }
            set
            {
                if (_c_Name != value)
                {
                    _c_Name = value;
                    OnPropertyChanged();
                }
            }
        }

        // 연구원 이름
        private string _resercherName;
        public string ResercherName
        {
            get { return _resercherName; }
            set
            {
                if (_resercherName != value)
                {
                    _resercherName = value;
                    OnPropertyChanged();
                }
            }
        }


        // 항목 별 (왼쪽 탭)

        private string _item1;
        public string Item1
        {
            get { return _item1; }
            set
            {
                if (_item1 != value)
                {
                    _item1 = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _item2;
        public string Item2
        {
            get { return _item2; }
            set
            {
                if (_item2 != value)
                {
                    _item2 = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _item3;
        public string Item3
        {
            get { return _item3; }
            set
            {
                if (_item3 != value)
                {
                    _item3 = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _item4;
        public string Item4
        {
            get { return _item4; }
            set
            {
                if (_item4 != value)
                {
                    _item4 = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _item5;
        public string Item5
        {
            get { return _item5; }
            set
            {
                if (_item5 != value)
                {
                    _item5 = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _item6;
        public string Item6
        {
            get { return _item6; }
            set
            {
                if (_item6 != value)
                {
                    _item6 = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _item7;
        public string Item7
        {
            get { return _item7; }
            set
            {
                if (_item7 != value)
                {
                    _item7 = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _item8;
        public string Item8
        {
            get { return _item8; }
            set
            {
                if (_item8 != value)
                {
                    _item8 = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _item9;
        public string Item9
        {
            get { return _item9; }
            set
            {
                if (_item9 != value)
                {
                    _item9 = value;
                    OnPropertyChanged();
                }
            }
        }
        private string _item10;
        public string Item10
        {
            get { return _item10; }
            set
            {
                if (_item10 != value)
                {
                    _item10 = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _item11;
        public string Item11
        {
            get { return _item11; }
            set
            {
                if (_item11 != value)
                {
                    _item11 = value;
                    OnPropertyChanged();
                }
            }
        }



        private string _item12;
        public string Item12
        {
            get { return _item12; }
            set
            {
                if (_item12 != value)
                {
                    _item12 = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _item13;
        public string Item13
        {
            get { return _item13; }
            set
            {
                if (_item13 != value)
                {
                    _item13 = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _item14;
        public string Item14
        {
            get { return _item14; }
            set
            {
                if (_item14 != value)
                {
                    _item14 = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _item15;
        public string Item15
        {
            get { return _item15; }
            set
            {
                if (_item15 != value)
                {
                    _item15 = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _item16;
        public string Item16
        {
            get { return _item16; }
            set
            {
                if (_item16 != value)
                {
                    _item16 = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _item17;
        public string Item17
        {
            get { return _item17; }
            set
            {
                if (_item17 != value)
                {
                    _item17 = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _item18;
        public string Item18
        {
            get { return _item18; }
            set
            {
                if (_item18 != value)
                {
                    _item18 = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _item19;
        public string Item19
        {
            get { return _item19; }
            set
            {
                if (_item19 != value)
                {
                    _item19 = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _item20;
        public string Item20
        {
            get { return _item20; }
            set
            {
                if (_item20 != value)
                {
                    _item20 = value;
                    OnPropertyChanged();
                }
            }
        }



        // GradeValue 값 : 등수, 
        // GradeValue_Bar 값 : 해당 ProgressBar 값           

        // 1번째 항목에 관한 등수, 동그라미 색, Bar 값
        private int _gradeValue;

        public int GradeValue
        {
            get { return _gradeValue; }
            set
            {
                if (_gradeValue != value)
                {
                    _gradeValue = value;
                    OnPropertyChanged();
                    GradeValueChanged();
                }
            }
        }
        private void GradeValueChanged()
        {
            if (GradeValue > 70)
            {
                Circle_Image1_Source = "./images/red_circle.png";
            }
            else if (GradeValue >= 30)
            {
                Circle_Image1_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image1_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }

        private string _circle_Image1_Source;
        public string Circle_Image1_Source
        {
            get { return _circle_Image1_Source; }
            set
            {
                if (_circle_Image1_Source != value)
                {
                    _circle_Image1_Source = value;
                    OnPropertyChanged();
                }
            }
        }




        private int _gradeValue_Bar;
        public int GradeValue_Bar
        {
            get { return _gradeValue_Bar; }
            set
            {
                if (_gradeValue_Bar != value)
                {
                    _gradeValue_Bar = value;
                    OnPropertyChanged();
                }
            }
        }


        // 2번째 항목에 관한 등수, 동그라미 색, Bar 값
        private int _gradeValue2;
        public int GradeValue2
        {
            get { return _gradeValue2; }
            set
            {
                if (_gradeValue2 != value)
                {
                    _gradeValue2 = value;
                    OnPropertyChanged(nameof(GradeValue2));
                    GradeValue2Changed();

                }
            }
        }

        private void GradeValue2Changed()
        {
            if (GradeValue2 > 70)
            {
                Circle_Image2_Source = "./images/red_circle.png";
            }
            else if (GradeValue2 >= 30)
            {
                Circle_Image2_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image2_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }

        private string _circle_Image2_Source;
        public string Circle_Image2_Source
        {
            get { return _circle_Image2_Source; }
            set
            {
                if (_circle_Image2_Source != value)
                {
                    _circle_Image2_Source = value;
                    OnPropertyChanged();
                }
            }
        }


        private int _gradeValue2_Bar;
        public int GradeValue2_Bar
        {
            get { return _gradeValue2_Bar; }
            set
            {
                if (_gradeValue2_Bar != value)
                {
                    _gradeValue2_Bar = value;
                    OnPropertyChanged(nameof(GradeValue2_Bar));

                }
            }
        }





        // 3번째 항목에 관한 등수, 동그라미 색, Bar 값
        private int _gradeValue3;
        public int GradeValue3
        {
            get { return _gradeValue3; }
            set
            {
                if (_gradeValue3 != value)
                {
                    _gradeValue3 = value;
                    OnPropertyChanged(nameof(GradeValue3));
                    GradeValue3Changed();

                }
            }
        }

        private void GradeValue3Changed()
        {
            if (GradeValue3 > 70)
            {
                Circle_Image3_Source = "./images/red_circle.png";
            }
            else if (GradeValue3 >= 30)
            {
                Circle_Image3_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image3_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }

        private string _circle_Image3_Source;
        public string Circle_Image3_Source
        {
            get { return _circle_Image3_Source; }
            set
            {
                if (_circle_Image3_Source != value)
                {
                    _circle_Image3_Source = value;
                    OnPropertyChanged();
                }
            }
        }


        private int _gradeValue3_Bar;
        public int GradeValue3_Bar
        {
            get { return _gradeValue3_Bar; }
            set
            {
                if (_gradeValue3_Bar != value)
                {
                    _gradeValue3_Bar = value;
                    OnPropertyChanged();
                }
            }
        }


        // 4번째 항목에 관한 등수, 동그라미 색, Bar 값
        private int _gradeValue4;
        public int GradeValue4
        {
            get { return _gradeValue4; }
            set
            {
                if (_gradeValue4 != value)
                {
                    _gradeValue4 = value;
                    OnPropertyChanged(nameof(GradeValue4));
                    GradeValue4Changed();

                }
            }
        }

        private void GradeValue4Changed()
        {
            if (GradeValue4 > 70)
            {
                Circle_Image4_Source = "./images/red_circle.png";
            }
            else if (GradeValue4 >= 30)
            {
                Circle_Image4_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image4_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }

        private string _circle_Image4_Source;
        public string Circle_Image4_Source
        {
            get { return _circle_Image4_Source; }
            set
            {
                if (_circle_Image4_Source != value)
                {
                    _circle_Image4_Source = value;
                    OnPropertyChanged();
                }
            }

        }

        private int _gradeValue4_Bar;
        public int GradeValue4_Bar
        {
            get { return _gradeValue4_Bar; }
            set
            {
                if (_gradeValue4_Bar != value)
                {
                    _gradeValue4_Bar = value;
                    OnPropertyChanged();
                }
            }
        }

        // 5번째 항목에 관한 등수, 동그라미 색, Bar 값
        private int _gradeValue5;
        public int GradeValue5
        {
            get { return _gradeValue5; }
            set
            {
                if (_gradeValue5 != value)
                {
                    _gradeValue5 = value;
                    OnPropertyChanged(nameof(GradeValue5));
                    GradeValue5Changed();

                }
            }
        }

        private void GradeValue5Changed()
        {
            if (GradeValue5 > 70)
            {
                Circle_Image5_Source = "./images/red_circle.png";
            }
            else if (GradeValue5 >= 30)
            {
                Circle_Image5_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image5_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }

        private string _circle_Image5_Source;
        public string Circle_Image5_Source
        {
            get { return _circle_Image5_Source; }
            set
            {
                if (_circle_Image5_Source != value)
                {
                    _circle_Image5_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue5_Bar;
        public int GradeValue5_Bar
        {
            get { return _gradeValue5_Bar; }
            set
            {
                if (_gradeValue5_Bar != value)
                {
                    _gradeValue5_Bar = value;
                    OnPropertyChanged();
                }
            }
        }




        // 6번째 항목에 관한 등수, 동그라미 색, Bar 값
        private int _gradeValue6;
        public int GradeValue6
        {
            get { return _gradeValue6; }
            set
            {
                if (_gradeValue6 != value)
                {
                    _gradeValue6 = value;
                    OnPropertyChanged(nameof(GradeValue6));
                    GradeValue6Changed();

                }
            }
        }

        private void GradeValue6Changed()
        {
            if (GradeValue6 > 70)
            {
                Circle_Image6_Source = "./images/red_circle.png";
            }
            else if (GradeValue6 >= 30)
            {
                Circle_Image6_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image6_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }

        private string _circle_Image6_Source;
        public string Circle_Image6_Source
        {
            get { return _circle_Image6_Source; }
            set
            {
                if (_circle_Image6_Source != value)
                {
                    _circle_Image6_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue6_Bar;
        public int GradeValue6_Bar
        {
            get { return _gradeValue6_Bar; }
            set
            {
                if (_gradeValue6_Bar != value)
                {
                    _gradeValue6_Bar = value;
                    OnPropertyChanged();
                }
            }
        }




        // 7번째 항목에 관한 등수, 동그라미 색, Bar 값
        private int _gradeValue7;
        public int GradeValue7
        {
            get { return _gradeValue7; }
            set
            {
                if (_gradeValue7 != value)
                {
                    _gradeValue7 = value;
                    OnPropertyChanged(nameof(GradeValue7));
                    GradeValue7Changed();

                }
            }
        }

        private void GradeValue7Changed()
        {
            if (GradeValue7 > 70)
            {
                Circle_Image7_Source = "./images/red_circle.png";
            }
            else if (GradeValue7 >= 30)
            {
                Circle_Image7_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image7_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }

        private string _circle_Image7_Source;
        public string Circle_Image7_Source
        {
            get { return _circle_Image7_Source; }
            set
            {
                if (_circle_Image7_Source != value)
                {
                    _circle_Image7_Source = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _gradeValue7_Bar;
        public int GradeValue7_Bar
        {
            get { return _gradeValue7_Bar; }
            set
            {
                if (_gradeValue7_Bar != value)
                {
                    _gradeValue7_Bar = value;
                    OnPropertyChanged();
                }
            }
        }



        // 8번째 항목에 관한 등수, 동그라미 색, Bar 값
        private int _gradeValue8;
        public int GradeValue8
        {
            get { return _gradeValue8; }
            set
            {
                if (_gradeValue8 != value)
                {
                    _gradeValue8 = value;
                    OnPropertyChanged(nameof(GradeValue8));
                    GradeValue8Changed();

                }
            }
        }

        private void GradeValue8Changed()
        {
            if (GradeValue8 > 70)
            {
                Circle_Image8_Source = "./images/red_circle.png";
            }
            else if (GradeValue8 >= 30)
            {
                Circle_Image8_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image8_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }

        private string _circle_Image8_Source;
        public string Circle_Image8_Source
        {
            get { return _circle_Image8_Source; }
            set
            {
                if (_circle_Image8_Source != value)
                {
                    _circle_Image8_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue8_Bar;
        public int GradeValue8_Bar
        {
            get { return _gradeValue8_Bar; }
            set
            {
                if (_gradeValue8_Bar != value)
                {
                    _gradeValue8_Bar = value;
                    OnPropertyChanged();
                }
            }
        }



        // 9번째 항목에 관한 등수, 동그라미 색, Bar 값
        private int _gradeValue9;
        public int GradeValue9
        {
            get { return _gradeValue9; }
            set
            {
                if (_gradeValue9 != value)
                {
                    _gradeValue9 = value;
                    OnPropertyChanged(nameof(GradeValue9));
                    GradeValue9Changed();

                }
            }
        }

        private void GradeValue9Changed()
        {
            if (GradeValue9 > 70)
            {
                Circle_Image9_Source = "./images/red_circle.png";
            }
            else if (GradeValue9 >= 30)
            {
                Circle_Image9_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image9_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }

        private string _circle_Image9_Source;
        public string Circle_Image9_Source
        {
            get { return _circle_Image9_Source; }
            set
            {
                if (_circle_Image9_Source != value)
                {
                    _circle_Image9_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue9_Bar;
        public int GradeValue9_Bar
        {
            get { return _gradeValue9_Bar; }
            set
            {
                if (_gradeValue9_Bar != value)
                {
                    _gradeValue9_Bar = value;
                    OnPropertyChanged();
                }
            }
        }


        // 10번째 항목에 관한 등수, 동그라미 색, Bar 값
        private int _gradeValue10;
        public int GradeValue10
        {
            get { return _gradeValue10; }
            set
            {
                if (_gradeValue10 != value)
                {
                    _gradeValue10 = value;
                    OnPropertyChanged(nameof(GradeValue10));
                    GradeValue10Changed();

                }
            }
        }

        private void GradeValue10Changed()
        {
            if (GradeValue10 > 70)
            {
                Circle_Image10_Source = "./images/red_circle.png";
            }
            else if (GradeValue10 >= 30)
            {
                Circle_Image10_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image10_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }

        private string _circle_Image10_Source;
        public string Circle_Image10_Source
        {
            get { return _circle_Image10_Source; }
            set
            {
                if (_circle_Image10_Source != value)
                {
                    _circle_Image10_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue10_Bar;
        public int GradeValue10_Bar
        {
            get { return _gradeValue10_Bar; }
            set
            {
                if (_gradeValue10_Bar != value)
                {
                    _gradeValue10_Bar = value;
                    OnPropertyChanged();
                }
            }
        }


        // 11번째 항목에 관한 등수, 동그라미 색, Bar 값

        private int _gradeValue11;
        public int GradeValue11
        {
            get { return _gradeValue11; }
            set
            {
                if (_gradeValue11 != value)
                {
                    _gradeValue11 = value;
                    OnPropertyChanged(nameof(GradeValue11));
                    GradeValue11Changed();

                }
            }
        }

        private void GradeValue11Changed()
        {
            if (GradeValue11 > 70)
            {
                Circle_Image11_Source = "./images/red_circle.png";
            }
            else if (GradeValue11 >= 30)
            {
                Circle_Image11_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image11_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }


        


        private string _circle_Image11_Source;
        public string Circle_Image11_Source
        {
            get { return _circle_Image11_Source; }
            set
            {
                if (_circle_Image11_Source != value)
                {
                    _circle_Image11_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue11_Bar;
        public int GradeValue11_Bar
        {
            get { return _gradeValue11_Bar; }
            set
            {
                if (_gradeValue11_Bar != value)
                {
                    _gradeValue11_Bar = value;
                    OnPropertyChanged();
                }
            }
        }

        // 12번째 항목에 관한 등수, 동그라미 색, Bar 값

        private int _gradeValue12;
        public int GradeValue12
        {
            get { return _gradeValue12; }
            set
            {
                if (_gradeValue12 != value)
                {
                    _gradeValue12 = value;
                    OnPropertyChanged(nameof(GradeValue12));
                    GradeValue12Changed();

                }
            }
        }

        private void GradeValue12Changed()
        {
            if (GradeValue12 > 70)
            {
                Circle_Image12_Source = "./images/red_circle.png";
            }
            else if (GradeValue12 >= 30)
            {
                Circle_Image12_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image12_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }





        private string _circle_Image12_Source;
        public string Circle_Image12_Source
        {
            get { return _circle_Image12_Source; }
            set
            {
                if (_circle_Image12_Source != value)
                {
                    _circle_Image12_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue12_Bar;
        public int GradeValue12_Bar
        {
            get { return _gradeValue12_Bar; }
            set
            {
                if (_gradeValue12_Bar != value)
                {
                    _gradeValue12_Bar = value;
                    OnPropertyChanged();
                }
            }
        }


        // 13번째 항목에 관한 등수, 동그라미 색, Bar 값

        private int _gradeValue13;
        public int GradeValue13
        {
            get { return _gradeValue13; }
            set
            {
                if (_gradeValue13 != value)
                {
                    _gradeValue13 = value;
                    OnPropertyChanged(nameof(GradeValue13));
                    GradeValue13Changed();

                }
            }
        }

        private void GradeValue13Changed()
        {
            if (GradeValue13 > 70)
            {
                Circle_Image13_Source = "./images/red_circle.png";
            }
            else if (GradeValue13 >= 30)
            {
                Circle_Image13_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image13_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }





        private string _circle_Image13_Source;
        public string Circle_Image13_Source
        {
            get { return _circle_Image13_Source; }
            set
            {
                if (_circle_Image13_Source != value)
                {
                    _circle_Image13_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue13_Bar;
        public int GradeValue13_Bar
        {
            get { return _gradeValue13_Bar; }
            set
            {
                if (_gradeValue13_Bar != value)
                {
                    _gradeValue13_Bar = value;
                    OnPropertyChanged();
                }
            }
        }


        // 14번째 항목에 관한 등수, 동그라미 색, Bar 값

        private int _gradeValue14;
        public int GradeValue14
        {
            get { return _gradeValue14; }
            set
            {
                if (_gradeValue14 != value)
                {
                    _gradeValue14 = value;
                    OnPropertyChanged(nameof(GradeValue14));
                    GradeValue14Changed();

                }
            }
        }

        private void GradeValue14Changed()
        {
            if (GradeValue14 > 70)
            {
                Circle_Image14_Source = "./images/red_circle.png";
            }
            else if (GradeValue14 >= 30)
            {
                Circle_Image14_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image14_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }





        private string _circle_Image14_Source;
        public string Circle_Image14_Source
        {
            get { return _circle_Image14_Source; }
            set
            {
                if (_circle_Image14_Source != value)
                {
                    _circle_Image14_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue14_Bar;
        public int GradeValue14_Bar
        {
            get { return _gradeValue14_Bar; }
            set
            {
                if (_gradeValue14_Bar != value)
                {
                    _gradeValue14_Bar = value;
                    OnPropertyChanged();
                }
            }
        }



        // 15번째 항목에 관한 등수, 동그라미 색, Bar 값

        private int _gradeValue15;
        public int GradeValue15
        {
            get { return _gradeValue15; }
            set
            {
                if (_gradeValue15 != value)
                {
                    _gradeValue15 = value;
                    OnPropertyChanged(nameof(GradeValue15));
                    GradeValue15Changed();

                }
            }
        }

        private void GradeValue15Changed()
        {
            if (GradeValue15 > 70)
            {
                Circle_Image15_Source = "./images/red_circle.png";
            }
            else if (GradeValue15 >= 30)
            {
                Circle_Image15_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image15_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }





        private string _circle_Image15_Source;
        public string Circle_Image15_Source
        {
            get { return _circle_Image15_Source; }
            set
            {
                if (_circle_Image15_Source != value)
                {
                    _circle_Image15_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue15_Bar;
        public int GradeValue15_Bar
        {
            get { return _gradeValue15_Bar; }
            set
            {
                if (_gradeValue15_Bar != value)
                {
                    _gradeValue15_Bar = value;
                    OnPropertyChanged();
                }
            }
        }

        // 16번째 항목에 관한 등수, 동그라미 색, Bar 값

        private int _gradeValue16;
        public int GradeValue16
        {
            get { return _gradeValue16; }
            set
            {
                if (_gradeValue16 != value)
                {
                    _gradeValue16 = value;
                    OnPropertyChanged(nameof(GradeValue16));
                    GradeValue16Changed();

                }
            }
        }

        private void GradeValue16Changed()
        {
            if (GradeValue16 > 70)
            {
                Circle_Image16_Source = "./images/red_circle.png";
            }
            else if (GradeValue16 >= 30)
            {
                Circle_Image16_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image16_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }





        private string _circle_Image16_Source;
        public string Circle_Image16_Source
        {
            get { return _circle_Image16_Source; }
            set
            {
                if (_circle_Image16_Source != value)
                {
                    _circle_Image16_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue16_Bar;
        public int GradeValue16_Bar
        {
            get { return _gradeValue16_Bar; }
            set
            {
                if (_gradeValue16_Bar != value)
                {
                    _gradeValue16_Bar = value;
                    OnPropertyChanged();
                }
            }
        }


        // 17번째 항목에 관한 등수, 동그라미 색, Bar 값

        private int _gradeValue17;
        public int GradeValue17
        {
            get { return _gradeValue17; }
            set
            {
                if (_gradeValue17 != value)
                {
                    _gradeValue17 = value;
                    OnPropertyChanged(nameof(GradeValue17));
                    GradeValue17Changed();

                }
            }
        }

        private void GradeValue17Changed()
        {
            if (GradeValue17 > 70)
            {
                Circle_Image17_Source = "./images/red_circle.png";
            }
            else if (GradeValue17 >= 30)
            {
                Circle_Image17_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image17_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }





        private string _circle_Image17_Source;
        public string Circle_Image17_Source
        {
            get { return _circle_Image17_Source; }
            set
            {
                if (_circle_Image17_Source != value)
                {
                    _circle_Image17_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue17_Bar;
        public int GradeValue17_Bar
        {
            get { return _gradeValue17_Bar; }
            set
            {
                if (_gradeValue17_Bar != value)
                {
                    _gradeValue17_Bar = value;
                    OnPropertyChanged();
                }
            }
        }
        // 18번째 항목에 관한 등수, 동그라미 색, Bar 값

        private int _gradeValue18;
        public int GradeValue18
        {
            get { return _gradeValue18; }
            set
            {
                if (_gradeValue18 != value)
                {
                    _gradeValue18 = value;
                    OnPropertyChanged(nameof(GradeValue18));
                    GradeValue18Changed();

                }
            }
        }

        private void GradeValue18Changed()
        {
            if (GradeValue18 > 70)
            {
                Circle_Image18_Source = "./images/red_circle.png";
            }
            else if (GradeValue18 >= 30)
            {
                Circle_Image18_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image18_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }





        private string _circle_Image18_Source;
        public string Circle_Image18_Source
        {
            get { return _circle_Image18_Source; }
            set
            {
                if (_circle_Image18_Source != value)
                {
                    _circle_Image18_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue18_Bar;
        public int GradeValue18_Bar
        {
            get { return _gradeValue18_Bar; }
            set
            {
                if (_gradeValue18_Bar != value)
                {
                    _gradeValue18_Bar = value;
                    OnPropertyChanged();
                }
            }
        }



        // 19번째 항목에 관한 등수, 동그라미 색, Bar 값

        private int _gradeValue19;
        public int GradeValue19
        {
            get { return _gradeValue19; }
            set
            {
                if (_gradeValue19 != value)
                {
                    _gradeValue19 = value;
                    OnPropertyChanged(nameof(GradeValue19));
                    GradeValue19Changed();

                }
            }
        }

        private void GradeValue19Changed()
        {
            if (GradeValue19 > 70)
            {
                Circle_Image19_Source = "./images/red_circle.png";
            }
            else if (GradeValue19 >= 30)
            {
                Circle_Image19_Source = "./images/yellow_circle.png";
            }
            else
            {
                Circle_Image19_Source = "./images/green_circle.png";
            }
            OnPropertyChanged();
        }





        private string _circle_Image19_Source;
        public string Circle_Image19_Source
        {
            get { return _circle_Image19_Source; }
            set
            {
                if (_circle_Image19_Source != value)
                {
                    _circle_Image19_Source = value;
                    OnPropertyChanged();
                }
            }

        }


        private int _gradeValue19_Bar;
        public int GradeValue19_Bar
        {
            get { return _gradeValue19_Bar; }
            set
            {
                if (_gradeValue19_Bar != value)
                {
                    _gradeValue19_Bar = value;
                    OnPropertyChanged();
                }
            }
        }








        /*****
       마이스킨 솔루션 2페이지
       *****/
        // 고객 나이 (client age)
        private int _c_Age;
        public int C_Age
        {
            get { return _c_Age; }
            set
            {
                if (_c_Age != value)
                {
                    _c_Age = value;
                    OnPropertyChanged();
                }
            }
        }


        // 생활 습관 조사 슬라이더 값
        private int _research_Bar;
        public int Research_Bar
        {
            get { return _research_Bar; }
            set
            {
                if (_research_Bar != value)
                {
                    _research_Bar = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _research_Bar2;
        public int Research_Bar2
        {
            get { return _research_Bar2; }
            set
            {
                if (_research_Bar2 != value)
                {
                    _research_Bar2 = value;
                    OnPropertyChanged();
                }
            }
        }


        private int _research_Bar3;
        public int Research_Bar3
        {
            get { return _research_Bar3; }
            set
            {
                if (_research_Bar3 != value)
                {
                    _research_Bar3 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _research_Bar4;
        public int Research_Bar4
        {
            get { return _research_Bar4; }
            set
            {
                if (_research_Bar4 != value)
                {
                    _research_Bar4 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _research_Bar5;
        public int Research_Bar5
        {
            get { return _research_Bar5; }
            set
            {
                if (_research_Bar5 != value)
                {
                    _research_Bar5 = value;
                    OnPropertyChanged();
                }
            }
        }



        //영역별 나(현재) 점수 (분홍 프로그레스 바 밑)
        /* string값 가져올때!
         private string _me_Score;
        public string Me_Score
        {
            get { return _me_Score; }
            set
            {
                if (_me_Score != value)
                {
                    _me_Score = value;
                    OnPropertyChanged();
                }
            }
        }




        */



        private int _me_Score;
        public int Me_Score
        {
            get { return _me_Score; }
            set
            {
                if (_me_Score != value)
                {
                    _me_Score = value;
                    OnPropertyChanged();
                }
            }
        }


        private int _me_Score2;
        public int Me_Score2
        {
            get { return _me_Score2; }
            set
            {
                if (_me_Score2 != value)
                {
                    _me_Score2 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _me_Score3;
        public int Me_Score3
        {
            get { return _me_Score3; }
            set
            {
                if (_me_Score3 != value)
                {
                    _me_Score3 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _me_Score4;
        public int Me_Score4
        {
            get { return _me_Score4; }
            set
            {
                if (_me_Score4 != value)
                {
                    _me_Score4 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _me_Score5;
        public int Me_Score5
        {
            get { return _me_Score5; }
            set
            {
                if (_me_Score5 != value)
                {
                    _me_Score5 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _worst_Score;
        public int Worst_Score
        {
            get { return _worst_Score; }
            set
            {
                if (_worst_Score != value)
                {
                    _worst_Score = value;
                    OnPropertyChanged();
                }
            }
        }


        private int _worst_Score2;
        public int Worst_Score2
        {
            get { return _worst_Score2; }
            set
            {
                if (_worst_Score2 != value)
                {
                    _worst_Score2 = value;
                    OnPropertyChanged();
                }
            }
        }



        private string _worst_Score_Text;
        public string Worst_Score_Text
        {
            get { return _worst_Score_Text; }
            set
            {
                if (_worst_Score_Text != value)
                {
                    _worst_Score_Text = value;
                    OnPropertyChanged();
                }
            }
        }


        private string _worst_Score2_Text;
        public string Worst_Score2_Text
        {
            get { return _worst_Score2_Text; }
            set
            {
                if (_worst_Score2_Text != value)
                {
                    _worst_Score2_Text = value;
                    OnPropertyChanged();
                }
            }
        }


        //영역별 나(현재) 점수 (회색 동그라이 슬라이드)
        private int _me_Slider;
        public int Me_Slider
        {
            get { return _me_Slider; }
            set
            {
                if (_me_Slider != value)
                {
                    _me_Slider = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _me_Slider2;
        public int Me_Slider2
        {
            get { return _me_Slider2; }
            set
            {
                if (_me_Slider2 != value)
                {
                    _me_Slider2 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _me_Slider3;
        public int Me_Slider3
        {
            get { return _me_Slider3; }
            set
            {
                if (_me_Slider3 != value)
                {
                    _me_Slider3 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _me_Slider4;
        public int Me_Slider4
        {
            get { return _me_Slider4; }
            set
            {
                if (_me_Slider4 != value)
                {
                    _me_Slider4 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _me_Slider5;
        public int Me_Slider5
        {
            get { return _me_Slider5; }
            set
            {
                if (_me_Slider5 != value)
                {
                    _me_Slider5 = value;
                    OnPropertyChanged();
                }
            }
        }




        //영역별 미래 점수 (분홍 프로그레스 바 밑)
        private int _future_Score;
        public int Future_Score
        {
            get { return _future_Score; }
            set
            {
                if (_future_Score != value)
                {
                    _future_Score = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _future_Score2;
        public int Future_Score2
        {
            get { return _future_Score2; }
            set
            {
                if (_future_Score2 != value)
                {
                    _future_Score2 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _future_Score3;
        public int Future_Score3
        {
            get { return _future_Score3; }
            set
            {
                if (_future_Score3 != value)
                {
                    _future_Score3 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _future_Score4;
        public int Future_Score4
        {
            get { return _future_Score4; }
            set
            {
                if (_future_Score4 != value)
                {
                    _future_Score4 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _future_Score5;
        public int Future_Score5
        {
            get { return _future_Score5; }
            set
            {
                if (_future_Score5 != value)
                {
                    _future_Score5 = value;
                    OnPropertyChanged();
                }
            }
        }




        //분홍색 프로그레스 바 (미래 점수)
        private int _skin_Future_Bar;
        public int Skin_Future_Bar
        {
            get { return _skin_Future_Bar; }
            set
            {
                if (_skin_Future_Bar != value)
                {
                    _skin_Future_Bar = value;
                    OnPropertyChanged();
                }
            }
        }


        private int _skin_Future_Bar2;
        public int Skin_Future_Bar2
        {
            get { return _skin_Future_Bar2; }
            set
            {
                if (_skin_Future_Bar2 != value)
                {
                    _skin_Future_Bar2 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _skin_Future_Bar3;
        public int Skin_Future_Bar3
        {
            get { return _skin_Future_Bar3; }
            set
            {
                if (_skin_Future_Bar3 != value)
                {
                    _skin_Future_Bar3 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _skin_Future_Bar4;
        public int Skin_Future_Bar4
        {
            get { return _skin_Future_Bar4; }
            set
            {
                if (_skin_Future_Bar4 != value)
                {
                    _skin_Future_Bar4 = value;
                    OnPropertyChanged();
                }
            }
        }

        private int _skin_Future_Bar5;
        public int Skin_Future_Bar5
        {
            get { return _skin_Future_Bar5; }
            set
            {
                if (_skin_Future_Bar5 != value)
                {
                    _skin_Future_Bar5 = value;
                    OnPropertyChanged();
                }
            }
        }


        // 5개의 점수를 저장하는 PointCollection

        public PointCollection polygonPoints = new PointCollection();
        public PointCollection PolygonPoints
        {
            get { return polygonPoints; }
            set { polygonPoints = value;
                OnPropertyChanged();
            }
        }


       
        private PointCollection polygonPoints2 = new PointCollection();
        public PointCollection PolygonPoints2
        {
            get { return polygonPoints2; }
            set { polygonPoints2 = value;
                OnPropertyChanged();
            }
        }


        private PointCollection polygonPoints3 = new PointCollection();
        public PointCollection PolygonPoints3
        {
            get { return polygonPoints3; }
            set
            {
                polygonPoints3 = value;
                OnPropertyChanged();
            }
        }


        private PointCollection polygonPoints4 = new PointCollection();
        public PointCollection PolygonPoints4
        {
            get { return polygonPoints4; }
            set
            {
                polygonPoints4 = value;
                OnPropertyChanged();
            }
        }


        private PointCollection polygonPoints5 = new PointCollection();
        public PointCollection PolygonPoints5
        {
            get { return polygonPoints5; }
            set
            {
                polygonPoints5 = value;
                OnPropertyChanged();
            }
        }



        private PointCollection polygonPoints6 = new PointCollection();
        public PointCollection PolygonPoints6
        {
            get { return polygonPoints6; }
            set
            {
                polygonPoints6 = value;
                OnPropertyChanged();
            }
        }


        private PointCollection polygonPoints7 = new PointCollection();
        public PointCollection PolygonPoints7
        {
            get { return polygonPoints7; }
            set
            {
                polygonPoints7 = value;
                OnPropertyChanged();
            }
        }

        private PointCollection polygonPoints8 = new PointCollection();
        public PointCollection PolygonPoints8
        {
            get { return polygonPoints8; }
            set
            {
                polygonPoints8 = value;
                OnPropertyChanged();
            }
        }


        private PointCollection polygonPoints9 = new PointCollection();
        public PointCollection PolygonPoints9
        {
            get { return polygonPoints9; }
            set
            {
                polygonPoints9 = value;
                OnPropertyChanged();
            }
        }


        private PointCollection polygonPoints10 = new PointCollection();
        public PointCollection PolygonPoints10
        {
            get { return polygonPoints10; }
            set
            {
                polygonPoints10 = value;
                OnPropertyChanged();
            }
        }


        private PointCollection polygonPoints11 = new PointCollection();
        public PointCollection PolygonPoints11
        {
            get { return polygonPoints11; }
            set
            {
                polygonPoints11 = value;
                OnPropertyChanged();
            }
        }

        private PointCollection polygonPoints12 = new PointCollection();
        public PointCollection PolygonPoints12
        {
            get { return polygonPoints12; }
            set
            {
                polygonPoints12 = value;
                OnPropertyChanged();
            }
        }



        /*
        public PointCollection polygonPoints2 = new PointCollection();
        public PointCollection PolygonPoints2
        {
            get { return polygonPoints2; }
            set
            {
                if (polygonPoints2 != value)
                {
                    polygonPoints2 = value;
                    OnPropertyChanged();
                }
            }
        }
        */



        //마이스킨 솔루션 3페이지 (프린트 페이지)



        // 측정 날짜 
        private string _c_Date;
        public string C_Date
        {
            get { return _c_Date; }
            set
            {
                if (_c_Date != value)
                {
                    _c_Date = value;
                    OnPropertyChanged();
                }
            }
        }


        private int _c_Visit_Number;
        public int C_Visit_Number
        {
            get { return _c_Visit_Number; }
            set
            {
                if (_c_Visit_Number != value)
                {
                    _c_Visit_Number = value;
                    OnPropertyChanged();
                }
            }
        }




        private int _research_Bar_Value;
        public int Research_Bar_Value
        {
            get { return _research_Bar_Value; }
            set
            {

                if (_research_Bar_Value != value)
                {
                    _research_Bar_Value = value;
                    OnPropertyChanged();
                }

            }
        }



        private int _research_Bar_Value1;
        public int Research_Bar_Value1
        {
            get { return _research_Bar_Value1; }
            set
            {

                if (_research_Bar_Value1 != value)
                {
                    _research_Bar_Value1 = value;
                    OnPropertyChanged();
                }

            }
        }


        private int _research_Bar_Value2;
        public int Research_Bar_Value2
        {
            get { return _research_Bar_Value2; }
            set
            {

                if (_research_Bar_Value2 != value)
                {
                    _research_Bar_Value2 = value;
                    OnPropertyChanged();
                }

            }
        }



        private int _research_Bar_Value3;
        public int Research_Bar_Value3
        {
            get { return _research_Bar_Value3; }
            set
            {

                if (_research_Bar_Value3 != value)
                {
                    _research_Bar_Value3 = value;
                    OnPropertyChanged();
                }

            }
        }



        private int _research_Bar_Value4;
        public int Research_Bar_Value4
        {
            get { return _research_Bar_Value4; }
            set
            {

                if (_research_Bar_Value4 != value)
                {
                    _research_Bar_Value4 = value;
                    OnPropertyChanged();
                }

            }
        }



        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
