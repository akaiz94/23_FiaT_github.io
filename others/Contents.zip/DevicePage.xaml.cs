﻿using IOPE_LAB.Common;
using IOPE_LAB.Popup;
using IOPE_LAB.Popup.TEST;
using IOPE_LAB_CONTROLS.Base;
using IOPE_LAB_CONTROLS.Entity;
using IOPE_LAB_CONTROLS.Entity.MarkVu;
using System.Security.Cryptography;
using IOPE_LAB_DEVICE;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.ComponentModel;
using System.Windows.Threading;

namespace IOPE_LAB.Contents
{
    /// <summary>
    /// DevicePage.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class DevicePage : Page
    {
        private Boolean result = false;
        private BackgroundWorker worker = null;
        private int getCount = 0;

        public DevicePage()
        {
            InitializeComponent();

            //마크뷰 프로세스바 미 표시
            this.pbStatus.Visibility = Visibility.Collapsed;
            this.tbMsg.Visibility = Visibility.Collapsed;

            //두피측정 프로세스바 미 표시
            this.pb_Scalp_Status.Visibility = Visibility.Collapsed;
            this.tb_Scalp_Msg.Visibility = Visibility.Collapsed;

            if (LoginSession.SelectedMember != null)
            {
                if (LoginSession.SelectedMember.PCCD_NAME.Equals("SCALP PROGRAM"))
                {
                    txt_ProgramName.Text = "두피 측정 프로그램";
                }
                else if (LoginSession.SelectedMember.PCCD_NAME.Equals("SKIN COUNSELING PROGRAM"))
                {
                    txt_ProgramName.Text = "피부측정 프로그램";
                }
                else if (LoginSession.SelectedMember.PCCD_NAME.Equals("SKIN FUTURE PROGRAM"))
                {
                    txt_ProgramName.Text = "MY SKIN SOLUTION";
                    //txt_ProgramName.Text = "유전자 분석 피부미래 솔루션 프로그램";
                }
                else if (LoginSession.SelectedMember.PCCD_NAME.Equals("Innisfree"))
                {
                    txt_ProgramName.Text = "이니스프리";
                }

                if (LoginSession.ProgramCourseflg == "I")
                {
                    btn_device03.Visibility = Visibility.Visible;
                    Scalp_layer.Visibility = Visibility.Visible;

                    //btn_CNK_Cutometer.Visibility = Visibility.Visible;
                    //btn_CNK_Sebumeter.Visibility = Visibility.Visible;
                }
                else
                {
                    if (LoginSession.Background_PCCD.Equals("PC001010"))
                    {
                        layer.Visibility = Visibility.Collapsed;
                        Scalp_layer.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        btn_device03.Visibility = Visibility.Collapsed;
                        btn_CNK_Cutometer.Visibility = Visibility.Collapsed;
                        btn_CNK_Sebumeter.Visibility = Visibility.Collapsed;
                        layer.ColumnDefinitions.RemoveAt(2);
                    }
                }
            }
            else
            {
                if (LoginSession.Background_PCCD.Equals("PC001010"))
                {
                    layer.Visibility = Visibility.Collapsed;
                    Scalp_layer.Visibility = Visibility.Visible;
                }
                else
                {
                    btn_device03.Visibility = Visibility.Collapsed;
                    btn_CNK_Cutometer.Visibility = Visibility.Collapsed;
                    btn_CNK_Sebumeter.Visibility = Visibility.Collapsed;
                    layer.ColumnDefinitions.RemoveAt(2);
                    Scalp_layer.Visibility = Visibility.Visible;
                }

                //btn_device03.Visibility = Visibility.Collapsed;
                //btn_CNK_Cutometer.Visibility = Visibility.Collapsed;
                //btn_CNK_Sebumeter.Visibility = Visibility.Collapsed;

                //layer.ColumnDefinitions.RemoveAt(2);
            }

            this.btn_device01.MouseLeftButtonUp += Btn_device01_MouseLeftButtonUp;
            this.btn_device01.MouseRightButtonUp += Btn_device01_MouseRightButtonUp;

            this.btn_device02.MouseLeftButtonUp += Btn_device02_MouseLeftButtonUp;
            this.btn_device02.MouseRightButtonUp += Btn_device02_MouseRightButtonUp;

            this.btn_device03.MouseLeftButtonUp += Btn_device03_MouseLeftButtonUp;
            this.btn_device03.MouseRightButtonUp += Btn_device03_MouseRightButtonUp;

            this.btn_device04.MouseLeftButtonUp += Btn_device04_MouseLeftButtonUp;
            this.btn_device04.MouseRightButtonUp += Btn_device04_MouseRightButtonUp;

            this.btn_device05.MouseLeftButtonUp += Btn_device05_MouseLeftButtonUp;
            this.btn_device05.MouseRightButtonUp += Btn_device05_MouseRightButtonUp;


            this.btn_Antera.Click += Btn_Antera_Click;
            this.btn_CNK_Cutometer.Click += Btn_CNK_Cutometer_Click;
            this.btn_CNK_Sebumeter.Click += Btn_CNK_Sebumeter_Click;
        }

        private void Btn_device05_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            string msg = "";
            try
            {
                msg = string.Format("{0} 님에 대한 두피기기 측정을 진행완료 하셨습니까?", LoginSession.SelectedMember.name);

                if (CommonMessageBox.ShowAlertMessage(msg, true))
                {
                    //두피측정기기 경우 측정 완료 후 DB에 적재여부 판단 해야함
                    LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 두피측정기기 시작");

                    //pb_Scalp_Grid , pb_Scalp_Status , tb_Scalp_Msg
                    this.pb_Scalp_Status.Visibility = Visibility.Visible;
                    this.tb_Scalp_Msg.Visibility = Visibility.Visible;
                    this.tb_Scalp_Msg.Text = "두피측정 데이터 확인 중";

                    if (LoginSession.ProgramCourseflg == "B")
                    {
                        //MyButton.SetValue(Grid.ColumnSpanProperty, 2); Margin="-67,0,325,0" 
                        this.pb_Scalp_Grid.SetValue(Grid.ColumnSpanProperty, 2);
                        //this.tbMsg.TextAlignment = TextAlignment.Center;
                    }

                    worker = new BackgroundWorker();
                    worker.WorkerReportsProgress = true;
                    worker.DoWork += Worker_Scalp_DoWork; //프로세스 바 실행 함수
                    worker.RunWorkerAsync();
                }
                else
                {
                    msg = string.Format("{0} 님에 두피측정 데이터 저장을 진행 해주세요.", LoginSession.SelectedMember.name);
                    CommonMessageBox.ShowAlertMessage(msg);
                    LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 고객 두피측정기기 미완료");
                }

            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        private void Btn_device05_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            string msg = "";
            try
            {
                msg = string.Format("{0} 님에 대한 두피기기 측정을 진행완료 하셨습니까?", LoginSession.SelectedMember.name);

                if (CommonMessageBox.ShowAlertMessage(msg, true))
                {
                    //두피측정기기 경우 측정 완료 후 DB에 적재여부 판단 해야함
                    LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 두피측정기기 시작");

                    //pb_Scalp_Grid , pb_Scalp_Status , tb_Scalp_Msg
                    this.pb_Scalp_Status.Visibility = Visibility.Visible;
                    this.tb_Scalp_Msg.Visibility = Visibility.Visible;
                    this.tb_Scalp_Msg.Text = "두피측정 데이터 확인 중";

                    if (LoginSession.ProgramCourseflg == "B")
                    {
                        //MyButton.SetValue(Grid.ColumnSpanProperty, 2); Margin="-67,0,325,0" 
                        this.pb_Scalp_Grid.SetValue(Grid.ColumnSpanProperty, 2);
                        //this.tbMsg.TextAlignment = TextAlignment.Center;
                    }

                    worker = new BackgroundWorker();
                    worker.WorkerReportsProgress = true;
                    worker.DoWork += Worker_Scalp_DoWork; //프로세스 바 실행 함수
                    worker.RunWorkerAsync();
                }
                else
                {
                    msg = string.Format("{0} 님에 대한 두피기기 측정을 진행 후 저장 해주세요.", LoginSession.SelectedMember.name);
                    CommonMessageBox.ShowAlertMessage(msg);
                    LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 고객 두피측정기기 미완료");
                }

            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        private void Worker_Scalp_DoWork(object sender, DoWorkEventArgs e)
        {
            /*
             - WCF 구현 시 필요한 요건
             1. 고객 데이터 저장( [Name],[Age],[Birthday],[Gender] | 고객 정보 각 두피측정 테이블에 저장 해야됨 )
             2. 고객 데이터 저장 조회 (두피측정 테이블 조회 필요)
            */
            try
            {
                if (ScalpDataSave() == true)
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {                
                        CommonMessageBox.ShowAlertMessage("두피측정 데이터가 정상적으로 저장 되었습니다.");
                        this.pb_Scalp_Status.Visibility = Visibility.Collapsed;
                        this.tb_Scalp_Msg.Visibility = Visibility.Collapsed;
                    }));
                }
                else
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        CommonMessageBox.ShowAlertMessage("두피측정 데이터를 저장 실패 하였습니다.\n\n재시도 바랍니다.");
                        this.pbStatus.Visibility = Visibility.Collapsed;
                        this.tbMsg.Visibility = Visibility.Collapsed;
                    }));
                }
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                LogRecord($"{this.GetType().FullName}: Worker_Scalp_DoWork 에러 발생 => ${ex.Message}");
            }
        }

        private bool ScalpDataSave()
        {
            bool scalpUserUpdate;
            bool result = true;
            
            /**/
            ScalpService.ScalpServiceClient scalpsc = new ScalpService.ScalpServiceClient();
            DataTable dt = scalpsc.ScalpType_Main(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
            DataTable Rdt = scalpsc.ScalpType_RightHairLine(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
            DataTable Ldt = scalpsc.ScalpType_LeftHairLine(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
            DataTable Fdt = scalpsc.ScalpType_FrontHairLine(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
            DataTable FCdt = scalpsc.ScalpType_FrontCenter(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
            DataTable Bdt = scalpsc.ScalpType_Back(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
            DataTable Cdt = scalpsc.ScalpType_Center(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
            DataTable Idt = scalpsc.ScalpType_Images(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey);
            scalpUserUpdate = scalpsc.ScalpUpdateData(LoginSession.SelectedMember.surveyNo, LoginSession.SelectedSurvey_M.userkey, LoginSession.SelectedMember.name, LoginSession.SelectedMember.AgeReal, LoginSession.SelectedMember.birthdate, LoginSession.SelectedMember.sex);

            try
            {
                if (dt.Rows.Count == 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        //LogRecord($"{this.GetType().FullName}: 두피 측정 ScalpType_Main 데이터 저장시작");
                        this.tb_Scalp_Msg.FontSize = 15;
                        this.tb_Scalp_Msg.Text = "두피 측정 ScalpType_Main 데이터 저장완료";
                    }));
                }

                if (Rdt.Rows.Count == 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        //LogRecord($"{this.GetType().FullName}: 두피 측정 ScalpType_RightHairLine 데이터 저장시작");
                        this.tb_Scalp_Msg.FontSize = 15;
                        this.tb_Scalp_Msg.Text = "두피 측정 ScalpType_RightHairLine 데이터 저장완료";
                    }));
                }

                if (Ldt.Rows.Count == 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        //LogRecord($"{this.GetType().FullName}: 두피 측정 ScalpType_LeftHairLine 데이터 저장시작");
                        this.tb_Scalp_Msg.FontSize = 15;
                        this.tb_Scalp_Msg.Text = "두피 측정 ScalpType_LeftHairLine 데이터 저장완료";
                    }));
                }

                if (Fdt.Rows.Count == 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        //LogRecord($"{this.GetType().FullName}: 두피 측정 ScalpType_FrontHairLine 데이터 저장시작");
                        this.tb_Scalp_Msg.FontSize = 15;
                        this.tb_Scalp_Msg.Text = "두피 측정 ScalpType_FrontHairLine 데이터 저장완료";
                    }));
                }

                if (FCdt.Rows.Count == 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        //LogRecord($"{this.GetType().FullName}: 두피 측정 ScalpType_FrontCenter 데이터 저장시작");
                        this.tb_Scalp_Msg.FontSize = 15;
                        this.tb_Scalp_Msg.Text = "두피 측정 ScalpType_FrontCenter 데이터 저장완료";
                    }));
                }

                if (Bdt.Rows.Count == 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        //LogRecord($"{this.GetType().FullName}: 두피 측정 ScalpType_Back 데이터 저장시작");
                        this.tb_Scalp_Msg.FontSize = 15;
                        this.tb_Scalp_Msg.Text = "두피 측정 ScalpType_Back 데이터 저장완료";
                    }));
                }

                if (Cdt.Rows.Count == 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        //LogRecord($"{this.GetType().FullName}: 두피 측정 ScalpType_Center 데이터 저장시작");    
                        this.tb_Scalp_Msg.FontSize = 15;
                        this.tb_Scalp_Msg.Text = "두피 측정 ScalpType_Center 데이터 저장완료";
                    }));
                }

                if (Idt.Rows.Count == 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        //LogRecord($"{this.GetType().FullName}: 두피 측정 ScalpType_Images 데이터 저장시작");
                        this.tb_Scalp_Msg.FontSize = 15;
                        this.tb_Scalp_Msg.Text = "두피 측정 ScalpType_Images 데이터 저장완료";
                    }));
                }

                if (scalpUserUpdate == false)
                {
                    LogRecord($"두피 데이터 업데이트 실패");
                }
                else
                {
                    LogRecord($"두피 데이터 업데이트 성공");
                }
                return result;

            }
            catch (Exception ex)
            {
                LogRecord($"{this.GetType().FullName}: 저장중 에러 발생 => ${ex.Message}");
                return false;
            }
        }

        private void Btn_device04_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 바포미터 오른쪽 클릭");
                Popup_DeviceValue pdv = new Popup_DeviceValue(Popup.Popup_DeviceValue.DeviceDataConnectorType.VapoMeter, LoginSession.SelectedMember);
                pdv.Topmost = true;
                pdv.ShowDialog();
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }          
        }

        private void Btn_device04_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 바포미터 왼쪽 클릭");
                //기기 실행 구역
                //DeviceManager dm = new DeviceManager();
                //string path = DeviceManager.GetDevicePath("tb_device_VapoMeter_program");
                //DeviceManager.ProcessStart(path);
                //if (LoginSession.ProgramCourseflg == "I")
                //{
                //    Popup_DeviceValue pdv = new Popup_DeviceValue(Popup.Popup_DeviceValue.DeviceDataConnectorType.VapoMeter, LoginSession.SelectedMember);
                //    pdv.Topmost = true;
                //    pdv.ShowDialog();
                //}

                Popup_DeviceValue pdv = new Popup_DeviceValue(Popup.Popup_DeviceValue.DeviceDataConnectorType.VapoMeter, LoginSession.SelectedMember);
                pdv.Topmost = true;
                pdv.ShowDialog();
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        private void Btn_device01_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            this.pbStatus.Visibility = Visibility.Visible;
            this.tbMsg.Visibility = Visibility.Visible;
            this.tbMsg.Text = "마크뷰 로드 중";

            if (LoginSession.ProgramCourseflg == "I")
            {
                //MyButton.SetValue(Grid.ColumnSpanProperty, 2); Margin="-67,0,325,0" 
                this.pbGrid.SetValue(Grid.ColumnSpanProperty, 2);
                //this.tbMsg.TextAlignment = TextAlignment.Center;
            }

            worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.DoWork += Worker_DoWork;
            worker.RunWorkerAsync();

            //result = CommonMessageBox.ShowAlertMessage("마크뷰 데이터를 저장 하시겠습니까?\n\n최대 1분 정도 소요 됩니다.", true);

            

            //if (result)
            //{
            //    CommonMessageBox.ShowAlertMessage("마크뷰 데이터를 저장 하였습니다.");
            //    this.pbStatus.Visibility = Visibility.Collapsed;
            //    this.tbMsg.Visibility = Visibility.Collapsed;
            //}

            //if (MarkVuDataLoad() == true)
            //{

            //    result = CommonMessageBox.ShowAlertMessage("마크뷰 데이터를 저장 하시겠습니까? 최대 1분 정도 소요 됩니다.", true);

            //    if (result)
            //    {
            //        CommonMessageBox.ShowAlertMessage("마크뷰 데이터를 저장 하였습니다.");
            //    }

            //}
        }

        private void Worker_DoWork(object sender, DoWorkEventArgs e)
        {
            if (MarkVuDataLoad() == true)
            {
                if (MarkVuDataSave() == true)
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        CommonMessageBox.ShowAlertMessage("마크뷰 데이터를 저장 하였습니다.");
                        this.pbStatus.Visibility = Visibility.Collapsed;
                        this.tbMsg.Visibility = Visibility.Collapsed;
                    }));
                }
                else
                {
                    if (getCount < 20 || getCount == 20)
                    {
                        Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                        {                         
                            this.pbStatus.Visibility = Visibility.Collapsed;
                            this.tbMsg.Visibility = Visibility.Collapsed;
                        }));
                    }
                    else
                    {
                        Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                        {
                            CommonMessageBox.ShowAlertMessage("마크뷰 데이터를 저장 실패 하였습니다.\n\n재시도 바랍니다.");
                            this.pbStatus.Visibility = Visibility.Collapsed;
                            this.tbMsg.Visibility = Visibility.Collapsed;
                        }));
                    }                  
                }

            }
        }

        CustInfo c_info = null;
        List<Analyze> c_analyze = null;
        List<Capture> c_capture = null;
        List<Complete> c_complete = null;
        ResultMarkVu rmv = null;      

        public bool MarkVuDataSave()
        {
            //try
            //{
            //    //this.tbMsg.Text = "마크뷰 저장 중";
            //    bool result = true;
            //    /**/
            //    DeviceService.DeviceServiceClient dsc = new DeviceService.DeviceServiceClient();

            //    DataTable dt = dsc.Get_DataCountMarkvu(c_info.surveyNo, c_info.userkey);
            //    getCount = (int) dt.Rows[0].ItemArray[0];


            //        if (dsc.Insert_MarkVu_CustInfo(c_info) < 0)
            //        {
            //            result = false;
            //        }
            //        else
            //        {
            //            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
            //            {
            //                this.tbMsg.FontSize = 15;
            //                this.tbMsg.Text = "마크뷰 고객 정보 저장완료 및 분석 정보 저장 중";
            //            }));
            //        }

            //        if (dsc.Insert_MarkVu_Analyze(c_analyze.ToArray()) < 0)
            //        {
            //            result = false;
            //        }
            //        else
            //        {
            //            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
            //            {
            //                this.tbMsg.FontSize = 15;
            //                this.tbMsg.Text = "마크뷰 고객 분석 정보 저장완료 및 이미지 정보 저장 중";
            //            }));
            //        }

            //        if (dsc.Insert_MarkVu_Capture(c_capture.ToArray()) < 0)
            //        {
            //            result = false;
            //        }
            //        else
            //        {
            //            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
            //            {
            //                this.tbMsg.FontSize = 15;
            //                this.tbMsg.Text = "마크뷰 고객 이미지 정보 저장완료 및 최종 저장확인 중";
            //            }));
            //        }

            //        if (dsc.Insert_MarkVu_Complete(c_complete.ToArray()) < 0)
            //        {
            //            result = false;
            //        }

            //        if (dsc.Insert_C_ResultMarkVu(LoginSession.SelectedMember.surveyNo) < 0)
            //        {
            //            result = false;
            //        }

            //        rmv = dsc.Get_C_ResultMarkVu(LoginSession.SelectedMember.surveyNo);
            //        if (rmv == null)
            //        {
            //            result = false;
            //        }
            //        else
            //        {
            //            LoginSession.SelectedM_Markvu_ResultData = rmv;
            //        }

            //        if (dsc.State != System.ServiceModel.CommunicationState.Closed)
            //        {
            //            dsc.Close();
            //        }

            //    return result;
            //}
            //catch (Exception ex)
            //{
            //    Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            //    return false;
            //}
            bool result = true;
            bool check = false;
            /**/
            DeviceService.DeviceServiceClient dsc = new DeviceService.DeviceServiceClient();
            try
            {
                //this.tbMsg.Text = "마크뷰 저장 중";            

                DataTable dt = dsc.Get_DataCountMarkvu(c_info.surveyNo, c_info.userkey);
                getCount = (int)dt.Rows[0].ItemArray[0];

                if (dsc.Insert_MarkVu_CustInfo(c_info) < 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, "이미지 저장 시작");                 
                        this.tbMsg.FontSize = 15;
                        this.tbMsg.Text = "마크뷰 고객 정보 저장완료 및 분석 정보 저장 중";
                        check = true;
                    }));
                }

                if (dsc.Insert_MarkVu_Analyze(c_analyze.ToArray()) < 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        this.tbMsg.FontSize = 15;
                        this.tbMsg.Text = "마크뷰 고객 분석 정보 저장완료 및 이미지 정보 저장 중";
                        check = true;
                    }));
                }
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, "이미지 저장 중");
                if (dsc.Insert_MarkVu_Capture(c_capture.ToArray()) < 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        
                        this.tbMsg.FontSize = 15;
                        this.tbMsg.Text = "마크뷰 고객 이미지 정보 저장완료 및 최종 저장확인 중";
                        check = true;
                    }));
                }

                if (dsc.Insert_MarkVu_Complete(c_complete.ToArray()) < 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        this.tbMsg.FontSize = 15;
                        this.tbMsg.Text = "마크뷰 고객 정보 확인 중";
                        check = true;
                    }));
                }

                if (dsc.Insert_C_ResultMarkVu(LoginSession.SelectedMember.surveyNo) < 0)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        this.tbMsg.FontSize = 15;
                        this.tbMsg.Text = "마크뷰 데이터 서버 전송 중";
                        check = true;
                    }));
                }

                rmv = dsc.Get_C_ResultMarkVu(LoginSession.SelectedMember.surveyNo);
                if (rmv == null)
                {
                    result = false;
                }
                else
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        this.tbMsg.FontSize = 15;
                        this.tbMsg.Text = "마크뷰 데이터 서버 전송 완료 및 최종 데이터 확인 중";
                        LoginSession.SelectedM_Markvu_ResultData = rmv;
                    }));
                }

                if (dsc.State != System.ServiceModel.CommunicationState.Closed)
                {
                    Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, "이미지 저장 완료");
                    dsc.Close();
                    check = false;
                }
                return result;
            }
            catch (Exception ex)
            {
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
                return false;
            }
            finally
            {
                if (check)
                {
                    if (dsc.Insert_MarkVu_Complete(c_complete.ToArray()) < 0)
                    {
                        result = false;
                    }
                    else
                    {
                        Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                        {
                            this.tbMsg.FontSize = 15;
                            this.tbMsg.Text = "마크뷰 고객 정보 확인 중";
                        }));
                    }

                    if (dsc.Insert_C_ResultMarkVu(LoginSession.SelectedMember.surveyNo) < 0)
                    {
                        result = false;
                    }
                    else
                    {
                        Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                        {
                            this.tbMsg.FontSize = 15;
                            this.tbMsg.Text = "마크뷰 데이터 서버 전송 중";
                        }));
                    }

                    rmv = dsc.Get_C_ResultMarkVu(LoginSession.SelectedMember.surveyNo);
                    if (rmv == null)
                    {
                        result = false;
                    }
                    else
                    {
                        Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                        {
                            this.tbMsg.FontSize = 15;
                            this.tbMsg.Text = "마크뷰 데이터 서버 전송 완료 및 최종 데이터 확인 중";
                            LoginSession.SelectedM_Markvu_ResultData = rmv;
                        }));
                    }

                    if (dsc.State != System.ServiceModel.CommunicationState.Closed)
                    {
                        dsc.Close();
                        Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                        {
                            CommonMessageBox.ShowAlertMessage("마크뷰 데이터를 저장 하였습니다.");
                            this.pbStatus.Visibility = Visibility.Collapsed;
                            this.tbMsg.Visibility = Visibility.Collapsed;
                        }));
                        //return result;
                    }
                }
            }
        }

        public byte[] Dec(String FileName)
        {
            /*====암/복호화 코드====*/
            AESEncrypt aes = new AESEncrypt();
            String password = "psi6915~";
            var byteArray = File.ReadAllBytes(FileName);
            //AES256으로 인크립트
            byte[] decryptedArray = aes.AESDecrypt256(byteArray, password);
            MemoryStream ms = new MemoryStream(decryptedArray);
            return decryptedArray;
            //System.Drawing.Image.FromStream(ms).Save(FileName.Replace(".psi", ".jpg"));
            //File.WriteAllBytes(FileName.Replace(".psi", ".jpg"), decryptedArray);
        }

        public void MarkVuNotAndInData(string type, string data)
        {
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
            {
                if (data != null)
                {                   
                    switch (type)
                    {
                        case "CustInfo":
                            this.tbMsg.Text = "마크뷰 고객 정보 로드 중";
                            break;

                        case "Analyze":
                            this.tbMsg.Text = "마크뷰 고객 분석정보 로드 중";
                            break;

                        case "Capture":
                            this.tbMsg.Text = "마크뷰 고객 이미지정보 로드 중";
                            break;
                            
                        case "duplicate":
                            CommonMessageBox.ShowAlertMessage("이미 저장된 고객 정보 입니다.\n\n결과 페이지로 이동 해주세요.");
                            break;

                        case "error":
                            CommonMessageBox.ShowAlertMessage("저장에 실패 했습니다.\n\n 다시 시도 해주세요.");
                            break;

                        default:
                            break;
                    }
                }
                else
                {
                    CommonMessageBox.ShowAlertMessage("요청하신 고객정보는 없는 고객정보 입니다.\n\n설문 프로그램 고객정보와 마크뷰측정기기 고객정보를 확인 해주세요.");
                    this.pbStatus.Visibility = Visibility.Collapsed;
                    this.tbMsg.Visibility = Visibility.Collapsed;
                }
            }));
        }

        public bool MarkVuDataLoad()
        {
            try
            {
                //마크뷰 프로그램 종료
                //Process[] p_list = Process.GetProcessesByName("MarkVu|antera|AONE-LITE|notepad");
                Process[] p_list = Process.GetProcessesByName("MarkVu");
                if (p_list != null && p_list.Length > 0)
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        if (CommonMessageBox.ShowConfirmMessage("마크뷰 프로그램을 실행중 입니다.\n\r종료 하시겠습니까?") == MessageBoxResult.Yes)
                        {
                            DeviceManager.ProcessKill();
                        }
                    }));
                   
                }

                //마크뷰 접속
                string markvu_data_path = DeviceManager.GetDevicePath("tb_device_MarkVu_DataPath");
                MarkVu mv = new MarkVu(markvu_data_path);

                //마크뷰 데이터 조회 
                //1. CustInfo Data 
                c_info = mv.GetCustInfo(LoginSession.SelectedMember.name, LoginSession.SelectedMember.sex, LoginSession.SelectedMember.birthdate);
                //c_info = mv.GetCustInfo("심유석", "M", "1994-05-05");
                //c_info.DBID = 1;
                if (c_info != null)
                {
                    c_info.surveyNo = LoginSession.SelectedMember.surveyNo;
                    c_info.userkey = LoginSession.SelectedMember.userkey;
                    MarkVuNotAndInData("CustInfo", "getData");
                }          
                else
                {
                    MarkVuNotAndInData("CustInfo",null);
                    return false;
                }

                DateTime capture_time;

                //마크뷰 데이터 조회 
                //2. Analyze Data
                c_analyze = mv.GetAnalyze(c_info.DBID);
                if (c_analyze != null && c_analyze.Count > 0)
                {
                    foreach (Analyze item in c_analyze)
                    {
                        item.surveyNo = LoginSession.SelectedMember.surveyNo;
                        item.userkey = LoginSession.SelectedMember.userkey;
                        capture_time = item.CaptureDate;
                    }
                    MarkVuNotAndInData("Analyze", "getData");
                }
                else
                {
                    MarkVuNotAndInData("Analyze",null);
                    return false;
                }

                //마크뷰 데이터 조회 
                //3. Capture Data
                c_capture = mv.GetCapture(c_info.DBID);
                if (c_capture != null && c_capture.Count > 0)
                {
                    foreach (Capture item in c_capture)
                    {
                        item.surveyNo = LoginSession.SelectedMember.surveyNo;
                        item.userkey = LoginSession.SelectedMember.userkey;

                        BitmapImage image = new BitmapImage();

                        try
                        {
                            //image.BeginInit();
                            //image.UriSource = new Uri(item.FilePath, UriKind.RelativeOrAbsolute);
                            //image.CacheOption = BitmapCacheOption.None;
                            item.ImageData = Dec(item.FilePath);
                            //image.EndInit();

                            //double current_width = image.PixelWidth;
                            //double current_height = image.PixelHeight;
                            //double affer_height = 1080;
                            //double affter_width = current_width * affer_height / current_height;

                            //using (MemoryStream memStream = new MemoryStream())
                            //{
                            //    ScaleTransform scale = new ScaleTransform(affter_width / current_width, affer_height / current_height);
                            //    TransformedBitmap scaledBitMap = new TransformedBitmap(image, scale);
                            //    JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                            //    encoder.Frames.Add(BitmapFrame.Create(scaledBitMap));
                            //    encoder.Save(memStream);
                            //    //item.ImageData = memStream.ToArray();
                            //}
                        }
                        catch (Exception ex)
                        {
                            Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
                        }
                    }
                    LoginSession.SelectedM_Markvu_Capture = c_capture;
                    MarkVuNotAndInData("Capture", "getData");
                }
                else
                {
                    MarkVuNotAndInData("Capture", null);
                    return false;
                }

                //마크뷰 데이터 조회 
                //4. Capture Data
                c_complete = mv.GetComplete(c_info.DBID);

                if (c_complete != null && c_complete.Count > 0)
                {
                    foreach (Complete item in c_complete)
                    {
                        item.surveyNo = LoginSession.SelectedMember.surveyNo;
                        item.userkey = LoginSession.SelectedMember.userkey;
                    }
                    MarkVuNotAndInData("Capture", "getData");
                }
                else
                {
                    MarkVuNotAndInData("Capture", null);
                    return false;
                }

                //마크뷰 데이터 조회
                //5. RefData Data
                //if (LoginSession.SelectedM_Markvu_RefData == null)
                //    LoginSession.SelectedM_Markvu_RefData = mv.GetRefData_All();           

                if (!result)
                {
                    Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                    {
                        CommonMessageBox.ShowAlertMessage("마크뷰 데이터를 정상적으로 가져왔습니다.\n\n마크뷰 데이터를 저장 하도록 하겠습니다.");
                        this.tbMsg.Text = "마크뷰 저장 진행 중";
                    }));
                }
                

                return true;
            }
            catch (Exception ex)
            {
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
                return false;
            }
        }

        private void Btn_device01_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                DeviceManager dm = new DeviceManager();

                string path = DeviceManager.GetDevicePath("tb_device_MarkVu_program");

                DeviceManager.ProcessStart(path);
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }
        }

        private void Btn_device02_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 안테라 오른쪽 마우스 클릭");
            Popup_DeviceValue pdv = new Popup_DeviceValue(Popup.Popup_DeviceValue.DeviceDataConnectorType.Antera, LoginSession.SelectedMember);
            pdv.Topmost = true;
            pdv.ShowDialog();
        }
        private void Btn_device02_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

            try
            {
                LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 안테라 왼쪽 마우스 클릭");
                DeviceManager dm = new DeviceManager();
                string path = DeviceManager.GetDevicePath("tb_device_Antera_program");
                DeviceManager.ProcessStart(path);
                   Popup_DeviceValue pdv = new Popup_DeviceValue(Popup.Popup_DeviceValue.DeviceDataConnectorType.Antera, LoginSession.SelectedMember);
                    pdv.Topmost = true;
                    pdv.ShowDialog();
                
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }

        }


        private void Btn_CNK_Sebumeter_Click(object sender, RoutedEventArgs e)
        {
            //Cutometer 프로그램 종료
            //Process[] p_list = Process.GetProcessesByName("MarkVu|antera|AONE-LITE|notepad");
            Process[] p_list = Process.GetProcessesByName("Sebumeter");
            if (p_list != null && p_list.Length > 0)
            {
                if (CommonMessageBox.ShowConfirmMessage("Sebumeter 프로그램이 실행중 입니다.\n\r종료 하시겠습니까?") == MessageBoxResult.Yes)
                {
                    DeviceManager.ProcessKill();
                }
            }

            Popup_DeviceValue pdv = new Popup_DeviceValue(Popup.Popup_DeviceValue.DeviceDataConnectorType.Sebumeter, LoginSession.SelectedMember);
            pdv.Topmost = true;
            pdv.ShowDialog();
        }

        private void Btn_CNK_Cutometer_Click(object sender, RoutedEventArgs e)
        {
            //Cutometer 프로그램 종료
            //Process[] p_list = Process.GetProcessesByName("MarkVu|antera|AONE-LITE|notepad");
            Process[] p_list = Process.GetProcessesByName("Cutometer");
            if (p_list != null && p_list.Length > 0)
            {
                if (CommonMessageBox.ShowConfirmMessage("Cutometer 프로그램이 실행중 입니다.\n\r종료 하시겠습니까?") == MessageBoxResult.Yes)
                {
                    DeviceManager.ProcessKill();
                }
            }

            Popup_DeviceValue pdv = new Popup_DeviceValue(Popup.Popup_DeviceValue.DeviceDataConnectorType.Cutometer, LoginSession.SelectedMember);
            pdv.Topmost = true;
            pdv.ShowDialog();
        }

        private void Btn_Antera_Click(object sender, RoutedEventArgs e)
        {
            //안테라 프로그램 종료
            //Process[] p_list = Process.GetProcessesByName("MarkVu|antera|AONE-LITE|notepad");
            Process[] p_list = Process.GetProcessesByName("antera");
            if (p_list != null && p_list.Length > 0)
            {
                if (CommonMessageBox.ShowConfirmMessage("안테라 프로그램이 실행중 입니다.\n\r종료 하시겠습니까?") == MessageBoxResult.Yes)
                {
                    DeviceManager.ProcessKill();
                }
            }

            Popup_DeviceValue pdv = new Popup_DeviceValue(Popup.Popup_DeviceValue.DeviceDataConnectorType.Antera, LoginSession.SelectedMember);
            pdv.Topmost = true;
            pdv.ShowDialog();
        }

        public byte[] GetImageFileData(string filepath)
        {
            byte[] result = new byte[0];

            //Initialize a file stream to read the image file
            FileStream fs = new FileStream(filepath, FileMode.Open, FileAccess.ReadWrite);

            //Initialize a byte array with size of stream
            result = new byte[fs.Length];

            //Read data from the file stream and put into the byte array
            fs.Read(result, 0, Convert.ToInt32(fs.Length));

            //Close a file stream
            fs.Close();

            return result;
        }

        private void Btn_device02_Click(object sender, RoutedEventArgs e)
        {
            DeviceManager dm = new DeviceManager();

            string path = DeviceManager.GetDevicePath("tb_device_Antera_program");

            DeviceManager.ProcessStart(path);
        }

        private void Btn_device03_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 큐토미터 왼쪽 마우스 클릭");

                DeviceManager dm = new DeviceManager();

                string path = DeviceManager.GetDevicePath("tb_device_CNK01_program");

                DeviceManager.ProcessStart(path);

                Popup_DeviceValue pdv = new Popup_DeviceValue(Popup.Popup_DeviceValue.DeviceDataConnectorType.Cutometer, LoginSession.SelectedMember);
                pdv.Topmost = true;
                pdv.ShowDialog();
            }
            catch (Exception ex)
            {
                Common.CommonMessageBox.ShowErrorMessage(Common.CommonBiz.CommonErrorMessage);
                Common.CommonBiz.ErrorLogWrite(this.GetType().FullName, ex.Message);
            }

        }

        private void Btn_device03_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            LogRecord($"{LoginSession.LoginManagerInfo.ManagerID}: 큐토미터 오른쪽 마우스 클릭");

            DeviceManager dm = new DeviceManager();

            string path = DeviceManager.GetDevicePath("tb_device_CNK02_program");

            DeviceManager.ProcessStart(path);

            Popup_DeviceValue pdv = new Popup_DeviceValue(Popup.Popup_DeviceValue.DeviceDataConnectorType.Sebumeter, LoginSession.SelectedMember);
            pdv.Topmost = true;
            pdv.ShowDialog();
        }

        public static void LogRecord(string _logMsg)
        {
            try
            {
                LogRecord logR = new LogRecord();
                logR.userkey = LoginSession.SelectedMember.userkey;
                logR.surveyNo = LoginSession.SelectedMember.surveyNo;
                logR.logMsg = _logMsg;
              
                DeviceService.DeviceServiceClient dsc = new DeviceService.DeviceServiceClient();

                dsc.InsertLogRecord(logR);

                if (dsc.State != System.ServiceModel.CommunicationState.Closed)
                {
                    dsc.Close();
                }

            }
            catch (Exception)
            { 
               throw;
            }
        }
    }
}
